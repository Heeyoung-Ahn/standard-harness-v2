# PLN-00 Deep Interview

## Purpose
Close implementation-critical discovery before requirements freeze.

## Status
- Starter template. Not approved.

## Interview Checklist
| Area | Question | Answer | Status |
|---|---|---|---|
| Goal | What decision or workflow must the product improve? | TBD | open |
| Users | Who uses it and who approves it? | TBD | open |
| Scope | What is in scope for MVP? | TBD | open |
| Data / integration | What systems, files, APIs, or manual inputs are authoritative? | TBD | open |
| Operations | Where will it run and who maintains it? | TBD | open |
| Risk | What can fail, leak, corrupt, or mislead users? | TBD | open |
| Approval | What exact approval opens the first implementation packet? | TBD | open |

## Output Rule
Promote only stable answers into `.agents/artifacts/REQUIREMENTS.md`. Keep uncertainty visible as open questions or deferred items.
