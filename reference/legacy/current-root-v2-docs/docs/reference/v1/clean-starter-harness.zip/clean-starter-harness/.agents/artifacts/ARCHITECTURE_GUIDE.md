# Architecture Guide

> AUTHORITATIVE after requirements freeze. Starter placeholder until PLN-01 is approved.

## Purpose
This file records product architecture decisions after planning approval. It remains a generic stub until the copied project defines component names, module boundaries, data flow, integrations, constraints, tradeoffs, and open technical questions.

## Status
- Starter placeholder. Not approved.

## Authoring Flow
- Draft architecture only after requirements, scope, active profiles, and approval boundaries are sufficiently clear.
- Record assumptions explicitly.
- Stop before downstream baselines, packet drafting, or `Ready For Code` when architecture decisions are not closed enough.
- Use `.agents/skills/architecture_design/SKILL.md` when drafting, rebasing, or structurally updating this artifact.

## System Boundary
- Product-specific runtime topology is not selected yet.
- Product code paths are not reserved by the harness. Choose product layout during planning.

## Integration Boundary
- List external systems, data sources, APIs, deployment targets, and credential boundaries here after kickoff.

## Data Boundary
- List authoritative data sources, storage ownership, migration rules, retention rules, and reconciliation requirements here if applicable.

## Security And Operations Boundary
- Define authentication, authorization, audit, secrets, backup, monitoring, and rollback boundaries before implementation.

## Architecture Memory Boundary
- Architecture decisions live here and in approved packet decisions; do not create a separate ADR document in the first long-memory wave.
- This file is canonical for project architecture, not workflow governance, current route state, packet approval status, or generated re-entry summaries.
- Copied starters use this file as a generic architecture stub for their own project decisions; root maintainer architecture history must not be pasted here.
- Active Context and generated docs may point here as source trace or fallback read guidance, but they do not become write authority for architecture memory.

## Starter Health Customization Boundary
- Preserve this section, `Purpose`, `Authoring Flow`, and `Architecture Memory Boundary` when customizing a copied starter.
- Safe to customize: component names, module boundaries, data flow, integrations, constraints, tradeoffs, and open technical questions for the actual product.
- Do not replace reusable starter-health guidance with product-only prose; add product architecture details in project sections.
- If a product packet needs different architecture memory behavior, record that as a packet decision before changing these reusable guardrails.

## Decisions Needed
| Decision | Owner | Status | Source |
|---|---|---|---|
| Architecture baseline | Planner / Architect | open | PLN-00 / PLN-01 |
