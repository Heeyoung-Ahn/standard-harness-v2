# Active Profiles

## Purpose
This artifact declares optional profiles that are active for the current project or packet set. Profiles are explicit-only; a profile file existing under `reference/profiles/` does not activate it.

## Active Profile Table
| Profile ID | Activation reason | Required evidence artifacts | Evidence status | Activated by | Activated at | Applies to |
|---|---|---|---|---|---|---|
| - | None currently active | - | not-needed | - | - | - |

## Rules
- Profiles are selected during `harness:init` or through an approved planning packet.
- A packet that cites an active profile must provide the required profile evidence before `Ready For Code`.
- Do not infer profile activation from file existence alone.
