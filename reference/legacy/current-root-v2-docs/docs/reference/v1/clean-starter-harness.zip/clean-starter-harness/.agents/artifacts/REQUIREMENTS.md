# Requirements

> AUTHORITATIVE. Governance requirements SSOT. Edit only through an approved planning boundary or packet.

## Status
- Starter placeholder. Not approved.

## Summary
이 문서는 새 프로젝트가 standard harness baseline 위에서 시작할 때 사용하는 사용자 친화적 요구사항 기준 문서다. 프로젝트별 요구, 승인 경계, active profile, 핵심 acceptance를 닫는 기준 문서로 유지한다.

## Authoring Trigger
- 이 문서를 처음 작성하거나 크게 리베이스할 때는 `reference/manuals/REQUIREMENTS_AUTHORING_GUIDE.md`를 함께 읽는다.
- 일반적인 requirements 참조 read에서는 authoring guide를 기본 입력으로 읽지 않는다.

## Starter Health Customization Boundary
- Preserve this section and reusable starter-health guidance when customizing a copied starter.
- Preserve initializer-required reusable sections such as `## Summary`, `## Authoring Trigger`, approval boundary, open questions, and deferred items unless a packet decision explicitly changes the template contract.
- Safe to customize: project goal, users and roles, active profiles, scope, workflows, functional/data requirements, and product-specific approval details.
- Do not replace reusable requirements structure with product-only prose; put product-only content inside the existing sections or cite an approved project packet.

## Goals

### 사용자 목표
- Replace this placeholder with the user-facing project goal.

### 운영 목표
- Replace this placeholder with the operator and AI re-entry goal.

### 승인 목표
- Replace this placeholder with the first explicit approval target.

## Active Profile Selection
- none

## Scope
- In scope: define during PLN-00 and freeze during PLN-01.
- Out of scope: define during PLN-00 and freeze during PLN-01.

## Acceptance Baseline
- No implementation starts until requirements freeze and an approved work packet exist.
- Required evidence, owner, and verification paths must be explicit before `Ready For Code`.

## Open Questions
- Replace starter placeholders using `PROJECT_STARTER_DOC_PACK` and close implementation-critical discovery questions before PLN-01 approval.

## Deferred Items
- none yet
