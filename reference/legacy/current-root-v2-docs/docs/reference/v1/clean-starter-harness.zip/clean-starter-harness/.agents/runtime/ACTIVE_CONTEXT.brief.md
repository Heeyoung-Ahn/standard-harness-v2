---
doc_id: ACTIVE_CONTEXT_BRIEF
audience: agent
authority: generated-runtime
language: en
llm_read_policy: default
default_context: true
token_budget: 900
---
# Active Context Brief

- Current lane: standard
- Current phase: day-start
- Risk overlays: none
- Active packet: none selected
- Current owner: planner
- Next action: use risk-adaptive route, confirm reproduction/evidence gates, then proceed
- Blocking gate: none declared
- Required evidence: digest first; raw logs only on fail/unknown/mismatch
- No-op success: allowed when Reproduction Gate says abstain or close-no-op
- Required docs: .agents/runtime/ACTIVE_CONTEXT.brief.md, .agents/runtime/DOC_ROUTE.json, .agents/ssot/AI_OPERATING_CONTRACT.md
- Do not read: START_HERE.md, reference/manuals/human/**, reference/manuals/full/**, reference/manuals/*GUIDE*.md, reference/manuals/*PLAYBOOK*.md, reference/manuals/CLOUD_LOCAL_MERGE_PLAYBOOK.md, reference/manuals/AUTOMATION_CATALOG.md
