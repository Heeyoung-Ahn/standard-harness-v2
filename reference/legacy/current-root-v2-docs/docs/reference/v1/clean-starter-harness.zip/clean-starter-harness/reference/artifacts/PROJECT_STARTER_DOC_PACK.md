# Project Starter Doc Pack

## Purpose
Use this document as the kickoff intake checklist before PLN-00 and PLN-01 are closed.

## Product Baseline
| Field | Value | Status |
|---|---|---|
| Project name | TBD | open |
| Primary users | TBD | open |
| Main goal | TBD | open |
| MVP scope | TBD | open |
| Out of scope | TBD | open |
| Operating environment | TBD | open |
| Data / integration sources | TBD | open |
| Security / permission baseline | TBD | open |
| Approval owner | TBD | open |

## Handoff To Requirements
- Promote stable answers into `.agents/artifacts/REQUIREMENTS.md`.
- Keep unresolved items in `## Open Questions` or `## Deferred Items`.
- Do not open implementation packets until requirements freeze is approved.
