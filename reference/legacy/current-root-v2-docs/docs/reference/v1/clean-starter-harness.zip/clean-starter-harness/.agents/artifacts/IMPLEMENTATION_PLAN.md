# Implementation Plan

> AUTHORITATIVE after planning approval. Starter placeholder until requirements and architecture baselines are closed.

## Status
- Starter placeholder. Not approved for implementation.

## Optional Profile Activation
- Selected profiles at bootstrap: none.
- `PRF-01`: dense administrative grid application.
- `PRF-02`: authoritative spreadsheet source.
- `PRF-03`: airgapped or manual-transfer delivery.
- `PRF-04`: legacy Excel/VBA/MariaDB replacement.
- `PRF-05`: Python/Django backoffice.
- `PRF-06`: workflow approval application.
- `PRF-07`: lightweight web/app.
- `PRF-08`: Android native app.
- `PRF-09`: Node or frontend web app.
- `PRF-10`: BI/analytics platform.

## Current Plan Summary
- Keep this file focused on the current and next implementation direction for the copied project.
- Do not turn this file into a long history log, closed packet catalog, or reusable rulebook.
- Durable history belongs in `PROJECT_HISTORY.md`; preventive rules belong in `PREVENTIVE_MEMORY.md`; architecture decisions belong in `ARCHITECTURE_GUIDE.md` plus approved packet decisions.
- Do not ship root maintainer packet history, review evidence, walkthrough evidence, progress history, or changelog history into copied projects.

## Current Iteration
- Initialize the clean starter and complete PLN-00 / PLN-01 before opening implementation work.

## Work Breakdown
| Work item | Scope | Status | Required approval | Evidence |
|---|---|---|---|---|
| PLN-00 | kickoff interview | open | planner/user confirmation | starter doc pack |
| PLN-01 | requirements freeze | blocked until PLN-00 | explicit freeze approval | requirements baseline |
| PKT-01 | first implementation packet | blocked until PLN-01 | Ready For Code | packet verification manifest |

## Operator Next Action
- Start PLN-00 deep interview.
- Fill `reference/artifacts/PROJECT_STARTER_DOC_PACK.md` before treating the kickoff baseline as concrete.
- Approve PLN-01 requirements freeze before syncing architecture, implementation, and UI.
- Open the first project packet only after requirements freeze, architecture baseline, and profile selection are aligned.


## Dependency Order And Blocking Conditions
- Do not start code without an active approved packet.
- Do not treat downstream sync or mockup review as `Ready For Code`.
- Keep generated-doc immutability, packet-before-code, Active Context derived authority, and root/starter sync guidance visible in implementation planning.

## Root / Standard-Template Sync Requirements
- For copied downstream projects, this section is usually informational only.
- If you are maintaining the reusable harness itself, keep root and standard-template reusable contracts aligned in the same lane.
- Product-only implementation details must not overwrite reusable harness operating guidance without an approved packet decision.

## Starter Health Customization Boundary
- Preserve this section, `Current Plan Summary`, `Dependency Order And Blocking Conditions`, `Root / Standard-Template Sync Requirements`, `Operator Next Action`, and `Pointers` when customizing a copied starter.
- Safe to customize: current implementation focus, active/next work, implementation sequence, open implementation decisions, packet evidence requirements, profile activation, and operator next action for the actual product.
- Keep generated-doc immutability, packet-before-code, Active Context derived authority, and root/starter sync guidance visible instead of replacing them with product-only planning notes.
- Do not replace reusable starter-health guidance with product-only prose; add product implementation details in the plan sections that describe current work and packet evidence.
- If product work requires a different guardrail, capture that as a packet decision first.
