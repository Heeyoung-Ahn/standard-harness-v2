# Standard Harness Clean Starter

이 저장소는 제품 코드가 들어가지 않은 standard harness clean starter 후보입니다.

## 가장 먼저
- `START_HERE.md`
- `reference/manuals/human/HARNESS_MANUAL.md`
- `INIT_STANDARD_HARNESS.cmd`
- `npm run harness:init`

## Harness Bootstrap
- Project slug: `standard-harness-clean-starter`
- Active optional profiles: none
- Next step: initialize the copied starter, fill `PROJECT_STARTER_DOC_PACK`, close PLN-00 and PLN-01, then sync architecture before opening implementation.

## Entry Authority
- README는 저장소 개요이고 START_HERE.md는 사람용 시작 정본이다.
- 운영 기준과 smoke 해석의 primary authority는 `reference/manuals/human/HARNESS_MANUAL.md`다.
- `START_HERE.md`는 사람용 시작 정본이고, 세부 운영 기준은 `reference/manuals/human/HARNESS_MANUAL.md`를 따른다.

## First Commands
- `npm test`
- `npm run harness:validate`
- `npm run harness:doctor`
- `npm run harness:status`
- `npm run harness:next`
- `npm run harness:context`
- `npm run harness:promote-starter -- --dry-run --to <new-clean-starter-path>` (`reference/manuals/human/starter-promotion.md`)

## Harness Philosophy
- Context Window 한계 대응: Active Context와 packet evidence로 재진입 안정성을 유지한다.
- 승인 경계 보존: Human plans, harnessed AI executes.
- 범위 오염 방지: Starter payload는 clean reusable operating payload다.
- Lean by default, strict where risk demands.
- Context economy is a product feature.
- Friction is observed, recorded, and improved.
- Compound Engineering and reusable learning are captured through approved memory and evidence routes.
- Active Context, packet, evidence, starter payload, and generated runtime state are separate surfaces.

## README Traceability
| README 핵심 주장 | 구현 파일 | 테스트 | 운영 명령 |
|---|---|---|---|
| Context Window 한계 대응 | `.agents/runtime/ACTIVE_CONTEXT.json` | `.harness/test/active-context.test.js` | `npm run harness:context` |
| 재진입 안정성 | `.harness/runtime/state/generate-state-docs.js` | `.harness/test/generated-state-docs.test.js` | `npm run harness:sync-state` |
| 승인 경계 보존 | `.agents/rules/HARNESS_OPERATING_CONTRACT.md` | `.harness/test/workflow-governance.test.js` | `npm run harness:codex-ready` |
| Friction is observed, recorded, and improved | `.agents/skills/retrospective/SKILL.md` | `.harness/test/retrospective-skill.test.js` | `npm run harness:validation-report` |
| Compound Engineering and reusable learning | `.harness/runtime/state/learning-commands.js` | `.harness/test/learning.test.js` | `npm run harness:learning` |
| Starter payload는 clean reusable operating payload다 | `.harness/runtime/state/promote-starter.js` | `.harness/test/promote-starter.test.js` | `npm run harness:payload-boundary` |
| Codex 지향 표면 | `.codex-plugin/plugin.json` | `.harness/test/codex-plugin-manifest.test.js` | `npm run harness:codex-ready` |
| Packet evidence gate | `.harness/runtime/state/packet-preflight.js` | `.harness/test/packet-preflight.test.js` | `npm run harness:packet-preflight` |

## Reference Pointers
- Human manual index: `reference/manuals/human/index.md`
- Human command chapter: `reference/manuals/human/commands.md`
- Command taxonomy: `reference/commands/COMMAND_TAXONOMY.md`
- Compatibility command policy: `reference/commands/COMPATIBILITY_COMMAND_POLICY.md`
- Starter seed and generated runtime state: `reference/runtime/STARTER_SEED_AND_GENERATED_STATE.md`
- Before initialization, `starter_bootstrap_pending` is the expected pre-init hold.
- After initialization, post-init state is tracked by the operating DB, Active Context, validation report, and packet evidence.

## Truth Contract
- `.agents/artifacts/*` is governance Markdown truth.
- `.harness/operating_state.sqlite` is hot operational DB state after initialization.
- `.agents/runtime/generated-state-docs/*` is derived output after initialization.
- `.agents/runtime/ACTIVE_CONTEXT.json` is compact AI-facing state after initialization.
- `.agents/runtime/ACTIVE_CONTEXT.md` is Korean human-facing state after initialization.
- `reference/*` is optional reference material.

## Product Code
- Harness runtime is isolated under `.harness/runtime/`.
- Harness tests are isolated under `.harness/test/`.
- Product code may use `src/`, `app/`, `backend/`, `frontend/`, `server/`, `apps/`, `packages/`, or another project-selected path after kickoff.
