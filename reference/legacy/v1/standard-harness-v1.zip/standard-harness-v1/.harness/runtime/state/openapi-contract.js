import fs from "node:fs";
import path from "node:path";

const METHODS = new Set(["GET", "POST", "PUT", "PATCH", "DELETE"]);
const HTTP_METHODS = new Set(["get", "post", "put", "patch", "delete"]);
const DEFAULT_CATALOG_PATH = path.join("reference", "artifacts", "API_CATALOG.md");
const DEFAULT_SOURCE_PATH = path.join("apps", "api", "src", "server.ts");
const DEFAULT_OPENAPI_PATH = path.join("reference", "api", "openapi.json");

export function extractCatalogRoutes({ repoRoot, catalogPath = DEFAULT_CATALOG_PATH } = {}) {
  const absolutePath = path.resolve(repoRoot, catalogPath);
  const markdown = fs.readFileSync(absolutePath, "utf8");
  return markdown
    .split(/\r?\n/)
    .filter((line) => line.trim().startsWith("|"))
    .map(parseMarkdownRow)
    .filter((cells) => cells.length >= 2)
    .filter((cells) => METHODS.has(cells[0].toUpperCase()) && stripMarkdown(cells[1]).startsWith("/"))
    .map((cells) => ({
      method: cells[0].toUpperCase(),
      path: normalizeRoutePath(stripMarkdown(cells[1])),
      purpose: stripMarkdown(cells[2] ?? ""),
      request: stripMarkdown(cells[3] ?? ""),
      response: stripMarkdown(cells[4] ?? ""),
      auth: stripMarkdown(cells[5] ?? ""),
      errors: stripMarkdown(cells[6] ?? ""),
      audit: stripMarkdown(cells[7] ?? ""),
      ownerPacket: stripMarkdown(cells[8] ?? ""),
      testPath: stripMarkdown(cells[9] ?? ""),
      source: catalogPath
    }));
}

export function extractSourceRoutes({ repoRoot, sourcePath = DEFAULT_SOURCE_PATH } = {}) {
  const absolutePath = path.resolve(repoRoot, sourcePath);
  const source = fs.readFileSync(absolutePath, "utf8");
  const routes = [];
  const routeRegex = /\bapp\.(get|post|put|patch|delete)\(\s*["'`]([^"'`]+)["'`]/g;
  let match;
  while ((match = routeRegex.exec(source)) !== null) {
    const method = match[1].toLowerCase();
    if (!HTTP_METHODS.has(method)) {
      continue;
    }
    routes.push({
      method: method.toUpperCase(),
      path: normalizeRoutePath(match[2]),
      source: sourcePath
    });
  }
  return routes;
}

export function buildOpenApiContract({
  repoRoot,
  catalogPath = DEFAULT_CATALOG_PATH,
  sourcePath = DEFAULT_SOURCE_PATH,
  openapiPath = DEFAULT_OPENAPI_PATH,
  write = false
} = {}) {
  const catalogRoutes = extractCatalogRoutes({ repoRoot, catalogPath });
  const sourceRoutes = extractSourceRoutes({ repoRoot, sourcePath });
  const packageVersion = readPackageVersion(repoRoot);
  const openapi = {
    openapi: "3.1.0",
    info: {
      title: "Standard Harness API",
      version: packageVersion
    },
    "x-generated-by": "harness:openapi-contract",
    "x-authority-boundary":
      "Generated machine-readable evidence from API_CATALOG.md and direct Fastify route inventory. Runtime behavior remains owned by apps/api/src/server.ts.",
    paths: {}
  };

  for (const route of catalogRoutes) {
    const openapiRoutePath = toOpenApiPath(route.path);
    if (!openapi.paths[openapiRoutePath]) {
      openapi.paths[openapiRoutePath] = {};
    }
    openapi.paths[openapiRoutePath][route.method.toLowerCase()] = buildOperation(route);
  }

  const validation = compareRouteInventories({
    sourceRoutes,
    catalogRoutes,
    openapiRoutes: extractOpenApiRoutes({ openapi })
  });
  const security = scanOpenApiForSecrets({ openapi });
  const result = {
    command: "openapi-contract",
    subcommand: "generate",
    ok: validation.ok && security.ok,
    outputPath: openapiPath,
    routeCounts: {
      source: sourceRoutes.length,
      catalog: catalogRoutes.length,
      openapi: extractOpenApiRoutes({ openapi }).length
    },
    diagnostics: [...validation.diagnostics, ...security.diagnostics],
    nextAction: validation.ok && security.ok ? "OpenAPI contract generated cleanly." : "Resolve OpenAPI contract diagnostics.",
    openapi
  };

  if (write) {
    const absolutePath = path.resolve(repoRoot, openapiPath);
    fs.mkdirSync(path.dirname(absolutePath), { recursive: true });
    fs.writeFileSync(absolutePath, `${JSON.stringify(openapi, null, 2)}\n`, "utf8");
  }

  return result;
}

export function validateOpenApiParity({
  repoRoot,
  catalogPath = DEFAULT_CATALOG_PATH,
  sourcePath = DEFAULT_SOURCE_PATH,
  openapiPath = DEFAULT_OPENAPI_PATH
} = {}) {
  const catalogRoutes = extractCatalogRoutes({ repoRoot, catalogPath });
  const sourceRoutes = extractSourceRoutes({ repoRoot, sourcePath });
  const openapi = readJson(path.resolve(repoRoot, openapiPath));
  const openapiRoutes = extractOpenApiRoutes({ openapi });
  const validation = compareRouteInventories({ sourceRoutes, catalogRoutes, openapiRoutes });
  const security = scanOpenApiForSecrets({ openapi });
  return {
    command: "openapi-contract",
    subcommand: "validate",
    ok: validation.ok && security.ok,
    routeCounts: {
      source: sourceRoutes.length,
      catalog: catalogRoutes.length,
      openapi: openapiRoutes.length
    },
    diagnostics: [...validation.diagnostics, ...security.diagnostics],
    nextAction: validation.ok && security.ok ? "OpenAPI contract parity is clean." : "Resolve OpenAPI contract diagnostics."
  };
}

export function scanOpenApiForSecrets({ openapi } = {}) {
  const diagnostics = [];
  visit(openapi, [], (value, keyPath) => {
    if (!isExampleLikePath(keyPath) || typeof value !== "string") {
      return;
    }
    if (isSecretLikeValue(value)) {
      diagnostics.push({
        code: "openapi_secret_like_example_value",
        message: "OpenAPI example/default value looks like a live credential or secret.",
        location: keyPath.join("."),
        severity: "blocker"
      });
    }
  });

  return {
    ok: diagnostics.length === 0,
    diagnostics
  };
}

export function runOpenApiContractCommand({ repoRoot, args = [] } = {}) {
  const subcommand = args[0] && !args[0].startsWith("--") ? args[0] : "validate";
  const write = args.includes("--write");

  if (subcommand === "generate") {
    const result = buildOpenApiContract({ repoRoot, write });
    return {
      ...omitOpenApi(result),
      written: write
    };
  }

  if (subcommand === "scan") {
    const openapi = readJson(path.resolve(repoRoot, DEFAULT_OPENAPI_PATH));
    const scan = scanOpenApiForSecrets({ openapi });
    return {
      command: "openapi-contract",
      subcommand,
      ok: scan.ok,
      diagnostics: scan.diagnostics,
      nextAction: scan.ok ? "No secret-like OpenAPI examples found." : "Remove secret-like OpenAPI examples."
    };
  }

  if (subcommand === "validate") {
    return validateOpenApiParity({ repoRoot });
  }

  return {
    command: "openapi-contract",
    subcommand,
    ok: false,
    diagnostics: [
      {
        code: "unknown_openapi_contract_subcommand",
        message: `Unsupported OpenAPI contract subcommand: ${subcommand}`,
        severity: "blocker"
      }
    ],
    nextAction: "Use generate, validate, or scan."
  };
}

function compareRouteInventories({ sourceRoutes, catalogRoutes, openapiRoutes }) {
  const diagnostics = [];
  const sourceByKey = keyedRoutes(sourceRoutes);
  const catalogByKey = keyedRoutes(catalogRoutes);
  const openapiByKey = keyedRoutes(openapiRoutes);

  for (const route of sourceRoutes) {
    const key = routeKey(route);
    if (!catalogByKey.has(key)) {
      diagnostics.push(routeDiagnostic("source_route_missing_from_catalog", route, "Source route is absent from API_CATALOG.md."));
    }
    if (!openapiByKey.has(key)) {
      diagnostics.push(routeDiagnostic("source_route_missing_from_openapi", route, "Source route is absent from generated OpenAPI."));
    }
  }

  for (const route of catalogRoutes) {
    const key = routeKey(route);
    if (!openapiByKey.has(key)) {
      diagnostics.push(routeDiagnostic("catalog_route_missing_from_openapi", route, "Catalog route is absent from OpenAPI."));
    }
    if (!sourceByKey.has(key)) {
      diagnostics.push(routeDiagnostic("catalog_route_absent_from_source", route, "Catalog route is absent from source route inventory."));
    }
  }

  for (const route of openapiRoutes) {
    const key = routeKey(route);
    if (!catalogByKey.has(key)) {
      diagnostics.push(routeDiagnostic("openapi_extra_route", route, "OpenAPI route is absent from API_CATALOG.md."));
    }
  }

  diagnostics.push(...methodMismatchDiagnostics({ sourceRoutes, catalogRoutes, openapiRoutes }));
  diagnostics.push(...pathParameterMismatchDiagnostics({ sourceRoutes, catalogRoutes, openapiRoutes }));

  return {
    ok: diagnostics.length === 0,
    diagnostics: uniqueDiagnostics(diagnostics)
  };
}

function buildOperation(route) {
  const responses = {};
  const successCode = route.method === "POST" ? "200" : "200";
  responses[successCode] = {
    description: route.response || "OK"
  };
  for (const errorCode of parseErrorCodes(route.errors)) {
    responses[errorCode] = {
      description: `Catalogued error ${errorCode}`
    };
  }

  return {
    tags: [deriveTag(route.path)],
    summary: route.purpose || `${route.method} ${route.path}`,
    description: [
      route.request ? `Request: ${route.request}` : null,
      route.auth ? `Auth / permission: ${route.auth}` : null,
      route.audit ? `Audit event: ${route.audit}` : null,
      route.ownerPacket ? `Owner packet: ${route.ownerPacket}` : null,
      route.testPath ? `Test path: ${route.testPath}` : null
    ]
      .filter(Boolean)
      .join("\n"),
    responses,
    "x-auth-boundary": route.auth || "not-specified",
    "x-audit-event": route.audit || "none",
    "x-owner-packet": route.ownerPacket || "not-specified",
    "x-test-path": route.testPath || "not-specified"
  };
}

function extractOpenApiRoutes({ openapi }) {
  const routes = [];
  for (const [routePath, pathItem] of Object.entries(openapi.paths ?? {})) {
    if (!pathItem || typeof pathItem !== "object") {
      continue;
    }
    for (const [method, operation] of Object.entries(pathItem)) {
      if (!HTTP_METHODS.has(method.toLowerCase())) {
        continue;
      }
      routes.push({
        method: method.toUpperCase(),
        path: normalizeRoutePath(routePath),
        rawPath: routePath,
        operation,
        source: DEFAULT_OPENAPI_PATH
      });
    }
  }
  return routes.sort(compareRoutes);
}

function methodMismatchDiagnostics({ sourceRoutes, catalogRoutes, openapiRoutes }) {
  const diagnostics = [];
  const collections = [
    ["source", sourceRoutes],
    ["catalog", catalogRoutes],
    ["openapi", openapiRoutes]
  ];
  const byStaticPath = new Map();
  for (const [label, routes] of collections) {
    for (const route of routes) {
      const staticKey = staticPathSignature(route.path);
      const item = byStaticPath.get(staticKey) ?? { staticKey, methodsBySource: {} };
      item.methodsBySource[label] = item.methodsBySource[label] ?? new Set();
      item.methodsBySource[label].add(route.method);
      byStaticPath.set(staticKey, item);
    }
  }
  for (const item of byStaticPath.values()) {
    const populated = Object.entries(item.methodsBySource);
    if (populated.length < 2) {
      continue;
    }
    const methodSets = populated.map(([, methods]) => [...methods].sort().join(","));
    if (new Set(methodSets).size > 1) {
      diagnostics.push({
        code: "method_mismatch",
        message: "Same path shape has different method inventory across source/catalog/OpenAPI.",
        path: item.staticKey,
        methods: Object.fromEntries(populated.map(([label, methods]) => [label, [...methods].sort()])),
        severity: "blocker"
      });
    }
  }
  return diagnostics;
}

function pathParameterMismatchDiagnostics({ sourceRoutes, catalogRoutes, openapiRoutes }) {
  const diagnostics = [];
  const referenceRoutes = [...sourceRoutes, ...catalogRoutes];
  for (const openapiRoute of openapiRoutes) {
    const matchingShape = referenceRoutes.find(
      (route) =>
        route.method === openapiRoute.method &&
        staticPathSignature(route.path) === staticPathSignature(openapiRoute.path) &&
        route.path !== openapiRoute.path
    );
    if (matchingShape) {
      diagnostics.push({
        code: "path_parameter_normalization_mismatch",
        message: "OpenAPI route parameter names differ from source/catalog path parameter names.",
        path: openapiRoute.rawPath ?? openapiRoute.path,
        expectedPath: matchingShape.path,
        severity: "blocker"
      });
    }
  }
  return diagnostics;
}

function keyedRoutes(routes) {
  return new Map(routes.map((route) => [routeKey(route), route]));
}

function routeKey(route) {
  return `${route.method.toUpperCase()} ${normalizeRoutePath(route.path)}`;
}

function compareRoutes(left, right) {
  return routeKey(left).localeCompare(routeKey(right));
}

function normalizeRoutePath(routePath) {
  const trimmed = stripMarkdown(routePath).trim();
  const withLeadingSlash = trimmed.startsWith("/") ? trimmed : `/${trimmed}`;
  return withLeadingSlash.replace(/\{([^}/]+)\}/g, ":$1").replace(/\/+/g, "/");
}

function toOpenApiPath(routePath) {
  return normalizeRoutePath(routePath).replace(/:([A-Za-z0-9_]+)/g, "{$1}");
}

function parseMarkdownRow(line) {
  return line
    .trim()
    .replace(/^\|/, "")
    .replace(/\|$/, "")
    .split("|")
    .map((cell) => cell.trim());
}

function stripMarkdown(value) {
  return String(value ?? "")
    .trim()
    .replace(/^`+|`+$/g, "")
    .trim();
}

function parseErrorCodes(value) {
  return [...String(value ?? "").matchAll(/\b(4\d\d|5\d\d)\b/g)].map((match) => match[1]);
}

function deriveTag(routePath) {
  const segments = normalizeRoutePath(routePath).split("/").filter(Boolean);
  if (segments[0] === "api" && segments[1]) {
    return segments[1];
  }
  return segments[0] ?? "root";
}

function staticPathSignature(routePath) {
  return normalizeRoutePath(routePath)
    .split("/")
    .map((segment) => (segment.startsWith(":") ? ":" : segment))
    .join("/");
}

function routeDiagnostic(code, route, message) {
  return {
    code,
    message,
    method: route.method,
    path: route.rawPath ?? route.path,
    normalizedPath: route.path,
    source: route.source,
    severity: "blocker"
  };
}

function uniqueDiagnostics(diagnostics) {
  const seen = new Set();
  const unique = [];
  for (const diagnostic of diagnostics) {
    const key = `${diagnostic.code}|${diagnostic.method ?? ""}|${diagnostic.normalizedPath ?? diagnostic.path ?? ""}|${diagnostic.expectedPath ?? ""}`;
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(diagnostic);
    }
  }
  return unique.sort((left, right) => `${left.code}${left.path ?? ""}`.localeCompare(`${right.code}${right.path ?? ""}`));
}

function readPackageVersion(repoRoot) {
  try {
    const packageJson = readJson(path.resolve(repoRoot, "package.json"));
    return packageJson.version ?? "0.0.0";
  } catch {
    return "0.0.0";
  }
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function omitOpenApi(result) {
  const { openapi, ...rest } = result;
  return rest;
}

function visit(value, keyPath, callback) {
  if (Array.isArray(value)) {
    value.forEach((item, index) => visit(item, [...keyPath, String(index)], callback));
    return;
  }
  if (value && typeof value === "object") {
    for (const [key, child] of Object.entries(value)) {
      visit(child, [...keyPath, key], callback);
    }
    return;
  }
  callback(value, keyPath);
}

function isExampleLikePath(keyPath) {
  return keyPath.some((key) => ["example", "examples", "default", "value"].includes(String(key ?? "").toLowerCase()));
}

function isSecretLikeValue(value) {
  return /(tmp|temp|temporary|password|passwd|secret|token|session|cookie)[-_A-Za-z0-9]*[-_][A-Za-z0-9]{6,}/i.test(value);
}
