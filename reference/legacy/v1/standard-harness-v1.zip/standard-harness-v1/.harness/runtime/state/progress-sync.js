import fs from "node:fs";
import path from "node:path";

import { createOperatingStateStore, DEFAULT_DB_PATH } from "./operating-state-store.js";
import { parseTableCells } from "./lib/packet-markdown.js";

const PROJECT_PROGRESS_PATH = ".agents/artifacts/PROJECT_PROGRESS.md";
const ACTIVE_CONTEXT_PATH = ".agents/runtime/ACTIVE_CONTEXT.json";

export function runProgressSyncCommand({ repoRoot, dbPath = DEFAULT_DB_PATH, args = [] } = {}) {
  const write = args.includes("--write");
  const resolvedDbPath = path.isAbsolute(dbPath) ? dbPath : path.resolve(repoRoot, dbPath);
  const progressPath = path.resolve(repoRoot, PROJECT_PROGRESS_PATH);
  const diagnostics = [];
  const changes = [];

  if (!fs.existsSync(progressPath)) {
    return {
      ok: false,
      command: "progress-sync",
      write,
      written: false,
      diagnostics: [{ code: "project-progress-missing", message: `${PROJECT_PROGRESS_PATH} does not exist.` }],
      suggestedPatch: ""
    };
  }

  const store = createOperatingStateStore({ dbPath: resolvedDbPath });
  let workItems;
  try {
    workItems = store.listWorkItems();
  } finally {
    store.close();
  }

  const currentContent = fs.readFileSync(progressPath, "utf8");
  let nextContent = currentContent;
  const activeItem = workItems.find((item) => !isClosedStatus(item.status));
  const reportedMissingCompletionEvidence = new Set();

  if (activeItem) {
    const currentLane = readTableRow(currentContent, "## Current Lane", "Field", "Active packet");
    const actual = normalizeProgressCell(currentLane?.Value);
    const expected = activeItem.workItemId;
    if (actual !== expected) {
      diagnostics.push({
        code: "current-lane-active-packet-stale",
        message: `Current Lane Active packet is ${actual || "(missing)"}, expected ${expected}.`,
        expected,
        actual
      });
      changes.push(`Current Lane Active packet -> \`${expected}\``);
      nextContent = updateTableRow(nextContent, "## Current Lane", "Field", "Active packet", {
        Value: `\`${expected}\``
      });
    }
    const activeContextStatus = readActiveContextStatus(repoRoot);
    if (activeContextStatus.workItemId && activeContextStatus.workItemId !== expected) {
      diagnostics.push({
        code: "active-context-stale",
        message: `Active Context points to ${activeContextStatus.workItemId}, expected ${expected}. Run npm run harness:sync-state.`,
        expected,
        actual: activeContextStatus.workItemId,
        nextAction: "npm run harness:sync-state"
      });
    }
  }

  for (const item of workItems) {
    const expected = normalizeWbsStatus(item.status);
    const wbsRow = readTableRow(currentContent, "## WBS Board", "Task ID", item.workItemId);
    if (wbsRow && normalizeStatus(wbsRow.Status) !== expected) {
      if (
        expected === "completed" &&
        shouldBlockCompletedSync({ repoRoot, item, diagnostics, reportedMissingCompletionEvidence })
      ) {
        continue;
      }
      diagnostics.push({
        code: "wbs-status-stale",
        message: `WBS row ${item.workItemId} is ${wbsRow.Status}, expected ${expected}.`,
        workItemId: item.workItemId,
        expected,
        actual: wbsRow.Status
      });
      changes.push(`WBS ${item.workItemId} status -> ${expected}`);
      nextContent = updateTableRow(nextContent, "## WBS Board", "Task ID", item.workItemId, {
        Status: expected
      });
    }

    const followUpRow = readTableRow(currentContent, "## Follow-Up Register", "Follow-up", item.workItemId);
    if (followUpRow && normalizeStatus(followUpRow.Status) !== expected) {
      if (
        expected === "completed" &&
        shouldBlockCompletedSync({ repoRoot, item, diagnostics, reportedMissingCompletionEvidence })
      ) {
        continue;
      }
      diagnostics.push({
        code: "followup-status-stale",
        message: `Follow-Up Register row ${item.workItemId} is ${followUpRow.Status}, expected ${expected}.`,
        workItemId: item.workItemId,
        expected,
        actual: followUpRow.Status
      });
      changes.push(`Follow-Up Register ${item.workItemId} status -> ${expected}`);
      nextContent = updateTableRow(nextContent, "## Follow-Up Register", "Follow-up", item.workItemId, {
        Status: expected
      });
    }
  }

  const contentChanged = nextContent !== currentContent;
  if (write && contentChanged) {
    fs.writeFileSync(progressPath, nextContent, "utf8");
  }
  let finalDiagnostics = diagnostics;
  let status;
  if (write && contentChanged) {
    const postWrite = runProgressSyncCommand({ repoRoot, dbPath: resolvedDbPath, args: [] });
    finalDiagnostics = postWrite.diagnostics ?? [];
    status = finalDiagnostics.length === 0 ? "write-fixed" : "write-applied-with-remaining-diagnostics";
  } else if (write) {
    status = diagnostics.length === 0 ? "write-noop" : "write-noop-with-remaining-diagnostics";
  } else {
    status = diagnostics.length === 0 ? "valid" : "diagnostics";
  }

  return {
    ok: finalDiagnostics.length === 0,
    command: "progress-sync",
    write,
    written: write && contentChanged,
    status,
    resultSummary: summarizeProgressSyncResult({ write, written: write && contentChanged, status, diagnostics: finalDiagnostics }),
    diagnostics: finalDiagnostics,
    changes,
    suggestedPatch: changes.length > 0 ? changes.map((change) => `- ${change}`).join("\n") : "No PROJECT_PROGRESS.md changes suggested."
  };
}

function summarizeProgressSyncResult({ write, written, status, diagnostics }) {
  if (!write) {
    return diagnostics.length === 0
      ? "Progress state is in sync."
      : "Progress state has diagnostics; rerun with --write only for deterministic PROJECT_PROGRESS.md fixes.";
  }
  if (status === "write-fixed") {
    return "Write applied deterministic changes and cleared progress-sync diagnostics.";
  }
  if (status === "write-applied-with-remaining-diagnostics") {
    return "Write applied deterministic changes, but unrelated diagnostics remain.";
  }
  if (status === "write-noop") {
    return "Write mode found no deterministic changes to apply and no diagnostics remain.";
  }
  if (written) {
    return "Write applied deterministic changes; review remaining diagnostics.";
  }
  return "Write mode found no deterministic changes to apply; diagnostics remain.";
}

function readActiveContextStatus(repoRoot) {
  const activeContextPath = path.resolve(repoRoot, ACTIVE_CONTEXT_PATH);
  if (!fs.existsSync(activeContextPath)) {
    return {};
  }
  try {
    const parsed = JSON.parse(fs.readFileSync(activeContextPath, "utf8"));
    return {
      workItemId:
        parsed?.activeTask?.workItemId ??
        parsed?.activeTask?.id ??
        parsed?.status?.assignment?.workItemId ??
        parsed?.assignment?.workItemId ??
        null
    };
  } catch {
    return {};
  }
}

function normalizeWbsStatus(status) {
  const normalized = normalizeStatus(status);
  if (["closed", "complete", "completed", "done"].includes(normalized)) {
    return "completed";
  }
  if (["planning", "planned", "planning-open", "pending"].includes(normalized)) {
    return "pending";
  }
  if (["ready-for-code", "approved"].includes(normalized)) {
    return "approved";
  }
  if (["implementation", "verification", "review", "active", "in-progress", "in_progress"].includes(normalized)) {
    return "in_progress";
  }
  return normalized || "pending";
}

function getCompletionEvidenceStatus(repoRoot, item) {
  const expectedPaths = getExpectedCompletionEvidencePaths(item);
  const missingPaths = expectedPaths.filter((evidencePath) => !fs.existsSync(path.resolve(repoRoot, evidencePath)));
  return {
    ok: missingPaths.length === 0,
    expectedPaths,
    missingPaths
  };
}

function shouldBlockCompletedSync({ repoRoot, item, diagnostics, reportedMissingCompletionEvidence }) {
  const completionEvidence = getCompletionEvidenceStatus(repoRoot, item);
  if (completionEvidence.ok) {
    return false;
  }
  if (!reportedMissingCompletionEvidence.has(item.workItemId)) {
    diagnostics.push({
      code: "closed-work-item-missing-closeout-evidence",
      message: `Work item ${item.workItemId} is closed in operating state, but closeout evidence is missing: ${completionEvidence.missingPaths.join(", ")}.`,
      workItemId: item.workItemId,
      expected: "completed-evidence",
      actual: "missing-closeout-evidence",
      missingPaths: completionEvidence.missingPaths
    });
    reportedMissingCompletionEvidence.add(item.workItemId);
  }
  return true;
}

function getExpectedCompletionEvidencePaths(item) {
  const workItemId = item.workItemId;
  return [
    `reference/packets/${workItemId}/03_implementation`,
    `reference/packets/${workItemId}/04_testing`,
    `reference/packets/${workItemId}/05_review`,
    `reference/packets/${workItemId}/07_closeout`
  ];
}

function isClosedStatus(status) {
  return ["closed", "complete", "completed", "done"].includes(normalizeStatus(status));
}

function normalizeStatus(status) {
  return String(status ?? "")
    .trim()
    .toLowerCase()
    .replace(/[`*]/g, "")
    .replace(/\s+/g, "-");
}

function normalizeProgressCell(value) {
  return String(value ?? "")
    .trim()
    .replace(/^`|`$/g, "");
}

function readTableRow(content, sectionHeading, keyColumn, keyValue) {
  const table = readSectionTable(content, sectionHeading);
  if (!table) {
    return null;
  }
  const target = normalizeProgressCell(keyValue);
  return table.rows.find((row) => normalizeProgressCell(row[keyColumn]) === target) ?? null;
}

function readSectionTable(content, sectionHeading) {
  const range = findSectionRange(content, sectionHeading);
  if (!range) {
    return null;
  }
  const lines = content.slice(range.start, range.end).split(/\r?\n/);
  const tableStart = lines.findIndex((line) => line.trim().startsWith("|"));
  if (tableStart === -1 || !lines[tableStart + 1]?.includes("---")) {
    return null;
  }
  const headers = parseTableCells(lines[tableStart]);
  const rows = [];
  for (let index = tableStart + 2; index < lines.length; index += 1) {
    if (!lines[index].trim().startsWith("|")) {
      break;
    }
    const cells = parseTableCells(lines[index]);
    rows.push(Object.fromEntries(headers.map((header, cellIndex) => [header, cells[cellIndex] ?? ""])));
  }
  return { headers, rows };
}

function updateTableRow(content, sectionHeading, keyColumn, keyValue, updates) {
  const range = findSectionRange(content, sectionHeading);
  if (!range) {
    return content;
  }
  const section = content.slice(range.start, range.end);
  const lines = section.split(/\r?\n/);
  const tableStart = lines.findIndex((line) => line.trim().startsWith("|"));
  if (tableStart === -1 || !lines[tableStart + 1]?.includes("---")) {
    return content;
  }
  const headers = parseTableCells(lines[tableStart]);
  const keyIndex = headers.indexOf(keyColumn);
  if (keyIndex === -1) {
    return content;
  }
  const target = normalizeProgressCell(keyValue);
  for (let index = tableStart + 2; index < lines.length; index += 1) {
    if (!lines[index].trim().startsWith("|")) {
      break;
    }
    const cells = parseTableCells(lines[index]);
    if (normalizeProgressCell(cells[keyIndex]) !== target) {
      continue;
    }
    const nextCells = headers.map((header, cellIndex) => updates[header] ?? cells[cellIndex] ?? "");
    lines[index] = `| ${nextCells.map(escapeMarkdownCell).join(" | ")} |`;
    const nextSection = lines.join("\n");
    return `${content.slice(0, range.start)}${nextSection}${content.slice(range.end)}`;
  }
  return content;
}

function findSectionRange(content, sectionHeading) {
  const start = content.indexOf(sectionHeading);
  if (start === -1) {
    return null;
  }
  const after = content.slice(start + sectionHeading.length);
  const next = after.match(/\n##\s+/);
  return {
    start,
    end: next ? start + sectionHeading.length + next.index : content.length
  };
}

function escapeMarkdownCell(value) {
  return String(value ?? "").replaceAll("|", "\\|");
}
