import fs from "node:fs";
import path from "node:path";

import { parseDelimitedList } from "../lib/packet-markdown.js";
import { readPacketSecurityReviewContract } from "../packet-contract.js";
import { selectActiveWorkItem } from "../workflow-routing.js";

const SECURITY_REVIEW_PACKAGE_MANIFEST_PATHS = [
  "package.json",
  "standard-template/package.json"
];

const SECURITY_REVIEW_RELEASE_ARTIFACT_PATHS = [
  "installer/install-harness.js",
  "installer/INSTALL_HARNESS.cmd",
  "packaging/build-release-package.js",
  "packaging/build-windows-exe-installers.js",
  "reference/manuals/human/HARNESS_MANUAL.md",
  "standard-template/AGENTS.md",
  "standard-template/README.md",
  "standard-template/START_HERE.md",
  "standard-template/reference/manuals/human/HARNESS_MANUAL.md",
  "standard-template/INIT_STANDARD_HARNESS.cmd"
];

const SECURITY_REVIEW_RELEASE_SCRIPTS = ["package:release", "package:windows-exe"];

const SECURITY_REVIEW_SECRET_RULES = [
  {
    code: "secret_scan_private_key_detected",
    severity: "error",
    pattern: /-----BEGIN [A-Z ]*PRIVATE KEY-----/,
    message: "Private key material was detected in a release-facing file.",
    recovery: "Remove the private key material from the release-facing file before internal review."
  },
  {
    code: "secret_scan_aws_access_key_detected",
    severity: "error",
    pattern: /\bAKIA[0-9A-Z]{16}\b/,
    message: "An AWS access-key-like token was detected in a release-facing file.",
    recovery: "Remove the AWS access-key-like token from the release-facing file before internal review."
  },
  {
    code: "secret_scan_github_token_detected",
    severity: "error",
    pattern: /\bgh[pousr]_[A-Za-z0-9]{20,}\b/,
    message: "A GitHub token-like string was detected in a release-facing file.",
    recovery: "Remove the GitHub token-like string from the release-facing file before internal review."
  },
  {
    code: "secret_scan_slack_token_detected",
    severity: "error",
    pattern: /\bxox[baprs]-[A-Za-z0-9-]{10,}\b/,
    message: "A Slack token-like string was detected in a release-facing file.",
    recovery: "Remove the Slack token-like string from the release-facing file before internal review."
  }
];

const SECURITY_REVIEW_ARTIFACT_AUDIT_RULES = [
  {
    code: "release_artifact_deprecated_operator_console_reference",
    severity: "warning",
    pattern: /\bdeprecated operator console\b|\blegacy operator console\b/i,
    message: "A release-facing artifact still contains deprecated operator-console wording.",
    recovery: "Remove deprecated operator-console wording from shipped release-facing artifacts before internal review."
  },
  {
    code: "release_artifact_security_approval_claim",
    severity: "warning",
    pattern: /\bsecurity approval(?: granted| complete| completed| passed)?\b/i,
    message: "A release-facing artifact appears to overstate local automation as security approval.",
    recovery: "Reword the release-facing artifact so it does not imply that local automation equals final security approval."
  }
];

const SECURITY_REVIEW_REQUIRED_CATEGORIES = [
  {
    id: "secret/credential",
    label: "Secret / credential exposure risk",
    reviewNote: "Local scanning helps, but final sensitivity and rotation judgment remains human-reviewed."
  },
  {
    id: "third-party dependency",
    label: "Third-party dependency risk visibility",
    reviewNote: "Dependency visibility is prepared locally, but final risk acceptance remains human-reviewed."
  },
  {
    id: "shipped artifact/manual/starter payload",
    label: "Shipped artifact / manual / starter payload review",
    reviewNote: "Release-facing artifact review still needs a human check before deployment."
  },
  {
    id: "deployment/cutover evidence",
    label: "Deployment / cutover evidence completeness",
    reviewNote: "Local evidence can be checked for presence, but final operational acceptance remains human-reviewed."
  },
  {
    id: "organization-specific policy/network/environment review",
    label: "Organization-specific policy or network / environment review",
    reviewNote: "Reusable local automation does not close organization-specific policy or environment review."
  }
];

function normalizeSecurityReviewScopeEntry(value) {
  const normalized = String(value ?? "").trim().toLowerCase();
  if (!normalized) {
    return null;
  }
  if (normalized === "package manifest" || normalized === "package manifests") {
    return "package manifests";
  }
  if (normalized === "release artifact" || normalized === "release artifacts" || normalized === "release-facing artifacts") {
    return "release-facing artifacts";
  }
  if (
    normalized === "declared path" ||
    normalized === "declared paths" ||
    normalized === "declared security/release path" ||
    normalized === "declared security/release paths"
  ) {
    return "declared security/release paths";
  }
  return null;
}

function normalizeSecurityReviewStatus(value) {
  const normalized = String(value ?? "").trim().toLowerCase();
  if (!normalized) {
    return "not-requested";
  }
  if (normalized === "requested" || normalized === "request" || normalized === "enabled" || normalized === "on") {
    return "requested";
  }
  return "not-requested";
}

function normalizeSecurityReviewRuntimeContract(metadata) {
  if (!metadata || typeof metadata !== "object") {
    return {
      status: null,
      scope: [],
      declaredPaths: []
    };
  }
  return {
    status: metadata.status ?? null,
    scope: parseDelimitedList(metadata.scope),
    declaredPaths: parseDelimitedList(metadata.declaredPaths)
  };
}

function resolveSecurityReviewContract({ activeWorkItem, repoRoot }) {
  if (!activeWorkItem) {
    return null;
  }

  const runtimeContract = normalizeSecurityReviewRuntimeContract(activeWorkItem.metadata?.securityReviewEvidence);
  const packetContract = readPacketSecurityReviewContract(repoRoot, activeWorkItem.sourceRef);
  const requested = normalizeSecurityReviewStatus(runtimeContract.status ?? packetContract.status) === "requested";
  const activationSource = runtimeContract.status ? "runtime metadata" : packetContract.status ? "packet metadata" : "not declared";
  const checkedScope = uniqueStringList(
    [...runtimeContract.scope, ...packetContract.scope]
      .map((entry) => normalizeSecurityReviewScopeEntry(entry))
      .filter(Boolean)
  );
  const declaredPaths = uniqueStringList([...runtimeContract.declaredPaths, ...packetContract.declaredPaths]);
  const includeDeclaredPaths = checkedScope.includes("declared security/release paths");
  const resolvedDeclaredPaths = includeDeclaredPaths
    ? declaredPaths.filter((relativePath) => fs.existsSync(path.resolve(repoRoot, relativePath)))
    : [];
  const unresolvedDeclaredPaths = includeDeclaredPaths
    ? declaredPaths.filter((relativePath) => !fs.existsSync(path.resolve(repoRoot, relativePath)))
    : [];

  return {
    requested,
    contractStatus: requested ? "requested" : "not-applicable",
    activationSource,
    checkedScope,
    declaredPaths,
    resolvedDeclaredPaths,
    unresolvedDeclaredPaths,
    includeDeclaredPaths,
    packageManifestPaths: checkedScope.includes("package manifests") ? SECURITY_REVIEW_PACKAGE_MANIFEST_PATHS : [],
    releaseArtifactPaths: checkedScope.includes("release-facing artifacts") ? SECURITY_REVIEW_RELEASE_ARTIFACT_PATHS : []
  };
}

export function buildSecurityReviewSummary({ store, repoRoot, findings = [] }) {
  const activeWorkItem = selectActiveWorkItem(store.listWorkItems(), { repoRoot });
  const contract = resolveSecurityReviewContract({ activeWorkItem, repoRoot });
  if (!contract) {
    return null;
  }

  if (!contract.requested) {
    return {
      additionalFindings: [],
      summary: {
        contractStatus: "not-applicable",
        activationSource: contract.activationSource,
        notApplicableReason: "Reusable security-review evidence is not requested by current packet/runtime metadata."
      }
    };
  }

  const contractFindings = [];
  if (contract.checkedScope.length === 0) {
    contractFindings.push({
      code: "security_review_scope_missing",
      severity: "error",
      message: "Reusable security-review evidence was requested, but no declared security-review scope was provided.",
      recovery: "Declare package manifests, release-facing artifacts, and any explicit security/release paths before rerunning validation."
    });
  }
  if (contract.includeDeclaredPaths && contract.declaredPaths.length === 0) {
    contractFindings.push({
      code: "security_review_declared_paths_missing",
      severity: "error",
      message:
        "Reusable security-review evidence requested declared security/release paths, but no explicit declared paths were provided.",
      recovery: "Add explicit declared security/release paths to the packet/runtime metadata before rerunning validation."
    });
  }
  for (const relativePath of contract.unresolvedDeclaredPaths) {
    contractFindings.push({
      code: "security_review_declared_path_missing",
      severity: "error",
      path: relativePath,
      message: `Declared security/release evidence path does not resolve locally. (${relativePath})`,
      recovery: "Fix or remove the unresolved declared security/release path before rerunning validation."
    });
  }

  const dependencyInventory = buildDependencyInventory(repoRoot, {
    packageManifestPaths: contract.packageManifestPaths
  });
  const releaseArtifactAudit = buildReleaseArtifactAudit(repoRoot, {
    checkedPaths: [...contract.releaseArtifactPaths, ...contract.resolvedDeclaredPaths]
  });
  const secretScan = buildLocalSecretScan({
    repoRoot,
    scanPaths: [
      ...dependencyInventory.scanPaths,
      ...releaseArtifactAudit.checkedArtifacts.map((artifact) => artifact.path)
    ]
  });
  const additionalFindings = [...contractFindings, ...secretScan.findings, ...releaseArtifactAudit.findings];
  const combinedFindings = [...findings, ...additionalFindings];
  const blockingErrors = combinedFindings.filter((finding) => finding?.severity === "error");
  const warnings = combinedFindings.filter((finding) => finding?.severity === "warning");

  return {
    additionalFindings,
    summary: {
      contractStatus: "requested",
      activationSource: contract.activationSource,
      summaryStatus: blockingErrors.length > 0 ? "blocking findings present" : warnings.length > 0 ? "attention needed" : "pre-review baseline checked",
      checkedScope: contract.checkedScope,
      declaredPaths: contract.declaredPaths,
      blockingErrorFindings: blockingErrors.map((finding) => summarizeSecurityFinding(finding)),
      warningFindings: warnings.map((finding) => summarizeSecurityFinding(finding)),
      reviewRequiredCategories: SECURITY_REVIEW_REQUIRED_CATEGORIES,
      operatorNextActions: buildSecurityReviewNextActions({ blockingErrors, warnings }),
      humanReviewStillRequired: [
        "Internal IT/security review is still required for the listed review-required capability categories.",
        "Local automation prepares reusable evidence only. It does not grant formal security approval."
      ],
      outOfScopeNote:
        "This summary is for internal IT/security review preparation only. It does not replace hosted CI, organization-specific approval forms, project-specific runbooks, or formal security approval.",
      dependencyInventory: dependencyInventory.summary,
      localSecretScan: secretScan.summary,
      releaseArtifactAudit: releaseArtifactAudit.summary
    }
  };
}

function buildDependencyInventory(repoRoot, { packageManifestPaths = SECURITY_REVIEW_PACKAGE_MANIFEST_PATHS } = {}) {
  const packages = packageManifestPaths
    .map((relativePath) => readPackageInventory(repoRoot, relativePath, inferPackageLabel(relativePath)))
    .filter(Boolean);

  return {
    scanPaths: packages.map((pkg) => pkg.path),
    summary: {
      packages,
      releaseScripts: packages.flatMap((pkg) =>
        pkg.releaseScripts.map((script) => ({
          packageLabel: pkg.packageLabel,
          script
        }))
      )
    }
  };
}

function inferPackageLabel(relativePath) {
  if (relativePath === "package.json") {
    return "root";
  }
  if (relativePath === "standard-template/package.json") {
    return "standard-template";
  }
  return relativePath;
}

function readPackageInventory(repoRoot, relativePath, packageLabel) {
  const absolutePath = path.resolve(repoRoot, relativePath);
  if (!fs.existsSync(absolutePath)) {
    return null;
  }

  const packageJson = JSON.parse(fs.readFileSync(absolutePath, "utf8"));
  return {
    path: relativePath,
    packageLabel,
    packageName: packageJson.name ?? "(unnamed package)",
    nodeEngine: packageJson.engines?.node ?? "not declared",
    directDependencies: Object.keys(packageJson.dependencies ?? {}),
    directDevDependencies: Object.keys(packageJson.devDependencies ?? {}),
    releaseScripts: SECURITY_REVIEW_RELEASE_SCRIPTS.filter((script) => packageJson.scripts?.[script])
  };
}

function buildReleaseArtifactAudit(repoRoot, { checkedPaths = SECURITY_REVIEW_RELEASE_ARTIFACT_PATHS } = {}) {
  const checkedArtifacts = uniqueStringList(checkedPaths).filter((relativePath) =>
    fs.existsSync(path.resolve(repoRoot, relativePath))
  ).map((relativePath) => {
    const absolutePath = path.resolve(repoRoot, relativePath);
    return {
      path: relativePath,
      exists: true,
      byteLength: fs.readFileSync(absolutePath).byteLength
    };
  });
  const findings = [];

  for (const artifact of checkedArtifacts) {
    const absolutePath = path.resolve(repoRoot, artifact.path);
    const content = readTextArtifact(absolutePath);
    if (content == null) {
      continue;
    }

    for (const rule of SECURITY_REVIEW_ARTIFACT_AUDIT_RULES) {
      if (!rule.pattern.test(content)) {
        continue;
      }
      findings.push({
        code: rule.code,
        severity: rule.severity,
        path: artifact.path,
        message: `${rule.message} (${artifact.path})`,
        recovery: rule.recovery
      });
    }
  }

  return {
    checkedArtifacts,
    findings,
    summary: {
      checkedArtifacts,
      findingCount: findings.length
    }
  };
}

function buildLocalSecretScan({ repoRoot, scanPaths }) {
  const findings = [];
  const uniquePaths = uniqueStringList(scanPaths);

  for (const relativePath of uniquePaths) {
    const absolutePath = path.resolve(repoRoot, relativePath);
    const content = readTextArtifact(absolutePath);
    if (content == null) {
      continue;
    }

    for (const rule of SECURITY_REVIEW_SECRET_RULES) {
      if (!rule.pattern.test(content)) {
        continue;
      }
      findings.push({
        code: rule.code,
        severity: rule.severity,
        path: relativePath,
        message: `${rule.message} (${relativePath})`,
        recovery: rule.recovery
      });
    }
  }

  return {
    findings,
    summary: {
      scannedPaths: uniquePaths,
      findingCount: findings.length,
      scanRuleCount: SECURITY_REVIEW_SECRET_RULES.length
    }
  };
}

function readTextArtifact(absolutePath) {
  if (!fs.existsSync(absolutePath)) {
    return null;
  }

  try {
    return fs.readFileSync(absolutePath, "utf8");
  } catch {
    return null;
  }
}

function summarizeSecurityFinding(finding) {
  return {
    code: finding.code,
    message: finding.message,
    path: finding.path ?? null
  };
}

function buildSecurityReviewNextActions({ blockingErrors, warnings }) {
  const actions = [];

  if (blockingErrors.length > 0) {
    actions.push("Resolve every blocking error finding before internal review submission.");
  } else {
    actions.push("Attach the dependency inventory, secret-scan result, and release-artifact audit to the internal review package.");
  }

  if (warnings.length > 0) {
    actions.push("Review the warning findings and clean up risky wording or stale release-facing content before submission.");
  }

  actions.push("Ask the internal IT/security reviewer to assess the review-required capability categories.");
  return actions;
}

export function recommendSecurityReviewNextAction({ findings, fallback }) {
  const firstError = findings.find((finding) => finding?.severity === "error");
  if (firstError) {
    return firstError.recovery ?? firstError.message ?? fallback;
  }
  const firstWarning = findings.find((finding) => finding?.severity === "warning");
  if (firstWarning) {
    return firstWarning.recovery ?? firstWarning.message ?? fallback;
  }
  return fallback;
}

function uniqueStringList(values) {
  return [...new Set((values ?? []).filter((value) => typeof value === "string" && value.trim()).map((value) => value.trim()))];
}
