import fs from "node:fs";
import path from "node:path";

import {
  COMPATIBILITY_CURRENT_STATE_PATH,
  COMPATIBILITY_TASK_LIST_PATH,
  CURRENT_STATE_DOC,
  TASK_LIST_DOC,
  calculateChecksum
} from "../generate-state-docs.js";
import { countTableRows, extractSummaryCount } from "./document-summary.js";

const REQUIRED_SECTIONS = {
  [CURRENT_STATE_DOC]: ["## Current Focus Summary", "## Decision Required Summary", "## Decision Required Detail"],
  [TASK_LIST_DOC]: ["## Blocked / At Risk Summary", "## Blocked / At Risk Detail"]
};

const GENERATED_PROJECTION_FRESHNESS_NAMES = [
  CURRENT_STATE_DOC,
  TASK_LIST_DOC,
  COMPATIBILITY_CURRENT_STATE_PATH,
  COMPATIBILITY_TASK_LIST_PATH
];

export function validateGeneratedMarkdownProjectionChecks({
  store,
  currentStateContent,
  taskListContent,
  findings
}) {
  if (currentStateContent != null) {
    validateRequiredSections(CURRENT_STATE_DOC, currentStateContent, findings);
    validateProjectionState(store, CURRENT_STATE_DOC, currentStateContent, findings);
    validateDecisionParity(store, currentStateContent, findings);
  }

  if (taskListContent != null) {
    validateRequiredSections(TASK_LIST_DOC, taskListContent, findings);
    validateProjectionState(store, TASK_LIST_DOC, taskListContent, findings);
    validateRiskParity(store, taskListContent, findings);
  }
}

export function validateProjectionState(store, projectionName, content, findings) {
  const projection = store.getGenerationState(projectionName);
  if (!projection) {
    findings.push({
      code: "generation_failed",
      severity: "error",
      projectionName,
      message: `${projectionName} has no generation_state row.`
    });
    return;
  }

  const checksum = calculateChecksum(content);
  if (projection.checksum !== checksum) {
    findings.push({
      code: "checksum_mismatch",
      severity: "error",
      projectionName,
      message: `${projectionName} checksum does not match generation_state.`
    });
    findings.push({
      code: "stale_generated_view",
      severity: "error",
      projectionName,
      message: `${projectionName} content no longer matches the last generated projection state.`
    });
  }
}

export function validateCompatibilityFallbackSurface({ store, repoRoot, relativePath, requiredMarkers: _requiredMarkers, findings }) {
  const absolutePath = path.resolve(repoRoot, relativePath);
  const content = readRequiredUtf8File({
    filePath: absolutePath,
    findings,
    missingCode: "generation_failed",
    missingMessage: `${relativePath} generated compatibility surface is missing.`,
    pathKey: "path"
  });
  if (content == null) {
    return;
  }

  const projection = store.getGenerationState(relativePath);
  if (!projection) {
    findings.push({
      code: "generation_failed",
      severity: "error",
      projectionName: relativePath,
      message: `${relativePath} has no generation_state row.`
    });
  }
}

export function validateGeneratedProjectionFreshness(store, findings) {
  const latestSourceChange = store.getLatestOperationalTimestamp();
  if (!latestSourceChange) {
    return;
  }

  pushFreshnessFindings({ store, findings, projectionNames: GENERATED_PROJECTION_FRESHNESS_NAMES, latestSourceChange });
}

export function pushFreshnessFindings({ store, findings, projectionNames, latestSourceChange }) {
  for (const projectionName of projectionNames) {
    const projection = store.getGenerationState(projectionName);
    if (!projection) {
      continue;
    }

    if (projection.generatedAt < latestSourceChange) {
      findings.push({
        code: "stale_generated_view",
        severity: "error",
        projectionName,
        message: `${projectionName} is stale relative to the latest DB mutation timestamp.`
      });
      findings.push({
        code: "freshness_drift_detected",
        severity: "error",
        projectionName,
        message: `${projectionName} is stale relative to the latest DB mutation timestamp.`
      });
    }
  }
}

function validateRequiredSections(projectionName, content, findings) {
  for (const section of REQUIRED_SECTIONS[projectionName] ?? []) {
    if (!content.includes(section)) {
      findings.push({
        code: "required_section_missing",
        severity: "error",
        projectionName,
        section,
        message: `${projectionName} is missing required section ${section}.`
      });
    }
  }
}

function validateDecisionParity(store, content, findings) {
  const openDecisions = store.listDecisions({ status: "open", decisionNeeded: true });
  const summaryCount = extractSummaryCount(content, "## Decision Required Summary");
  const detailCount = countTableRows(content, "## Decision Required Detail");

  if (summaryCount !== openDecisions.length) {
    findings.push({
      code: "generated_docs_parity_mismatch",
      severity: "error",
      projectionName: CURRENT_STATE_DOC,
      message: `Decision summary count ${summaryCount} does not match DB count ${openDecisions.length}.`
    });
  }

  if (summaryCount !== detailCount) {
    findings.push({
      code: "count_detail_parity_mismatch",
      severity: "error",
      projectionName: CURRENT_STATE_DOC,
      message: `Decision summary count ${summaryCount} does not match detail row count ${detailCount}.`
    });
  }
}

function validateRiskParity(store, content, findings) {
  const openRisks = store.listGateRisks({ status: "open" });
  const summaryCount = extractSummaryCount(content, "## Blocked / At Risk Summary");
  const detailCount = countTableRows(content, "## Blocked / At Risk Detail");

  if (summaryCount !== openRisks.length) {
    findings.push({
      code: "generated_docs_parity_mismatch",
      severity: "error",
      projectionName: TASK_LIST_DOC,
      message: `Blocked/risk summary count ${summaryCount} does not match DB count ${openRisks.length}.`
    });
  }

  if (summaryCount !== detailCount) {
    findings.push({
      code: "count_detail_parity_mismatch",
      severity: "error",
      projectionName: TASK_LIST_DOC,
      message: `Blocked/risk summary count ${summaryCount} does not match detail row count ${detailCount}.`
    });
  }
}

function readRequiredUtf8File({
  filePath,
  findings,
  missingCode,
  missingMessage,
  pathKey = "path"
}) {
  if (!fs.existsSync(filePath)) {
    findings.push({
      code: missingCode,
      severity: "error",
      [pathKey]: filePath,
      message: missingMessage
    });
    return null;
  }

  const buffer = fs.readFileSync(filePath);
  if (buffer[0] === 0xef && buffer[1] === 0xbb && buffer[2] === 0xbf) {
    findings.push({
      code: "utf8_bom_detected",
      severity: "error",
      path: filePath,
      message: `${path.basename(filePath)} must be UTF-8 without BOM.`
    });
  }

  const content = buffer.toString("utf8");
  if (content.includes("\uFFFD")) {
    findings.push({
      code: "mojibake_detected",
      severity: "error",
      path: filePath,
      message: `${path.basename(filePath)} contains replacement characters that indicate mojibake.`
    });
  }

  return content;
}
