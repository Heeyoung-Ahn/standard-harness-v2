export const ROUTEABLE_AGENT_ROLES = ["developer", "tester", "reviewer", "planner", "orchestrator"];
export const SCHEMA_VISIBLE_WORKFLOW_ROLES = ["pm", "deployer", "documenter", "handoff"];
export const VALID_ROLES = new Set(ROUTEABLE_AGENT_ROLES);
export const VALID_DELIVERY_ROUTE_MODES = new Set(["orchestrated-closeout", "role-by-role"]);

export const ROLE_AUTHORITY_DENYLIST = {
  developer: new Set(["tester_pass", "reviewer_pass", "reviewer_closeout", "planner_closeout", "risk_acceptance"]),
  tester: new Set(["implementation_fix", "reviewer_pass", "reviewer_closeout", "planner_closeout", "risk_acceptance"]),
  reviewer: new Set(["implementation_fix", "tester_pass", "planner_closeout", "risk_acceptance"]),
  planner: new Set(["implementation_fix", "tester_pass", "reviewer_pass", "reviewer_closeout"]),
  orchestrator: new Set(["implementation_fix", "tester_pass", "reviewer_pass", "reviewer_closeout", "planner_closeout", "risk_acceptance"])
};

export function roleAuthority(role) {
  switch (role) {
    case "developer":
      return ["Implement approved scope", "Produce implementation evidence", "Hand off through structured route"];
    case "tester":
      return ["Verify approved scope", "Report pass/fail evidence", "Do not remediate"];
    case "reviewer":
      return ["Assess conformance", "Report findings and closeout readiness", "Do not remediate"];
    case "planner":
      return ["Close packet or hold scope", "Own approval boundary", "Do not substitute Tester or Reviewer evidence"];
    case "orchestrator":
      return ["Route approved delivery", "Track bounded remediation loops", "Do not substitute Developer, Tester, Reviewer, or Planner authority"];
    default:
      return [];
  }
}

export function roleNonAuthority(role) {
  switch (role) {
    case "developer":
      return ["Tester pass", "Reviewer closeout", "Planner closeout", "Risk acceptance"];
    case "tester":
      return ["Implementation fixes", "Reviewer closeout", "Planner closeout"];
    case "reviewer":
      return ["Implementation fixes", "Tester verification rewrite", "Planner closeout"];
    case "planner":
      return ["Implementation", "Testing", "Reviewer judgment substitution"];
    case "orchestrator":
      return ["Implementation fixes", "Tester verification", "Reviewer closeout judgment", "Planner closeout approval", "Risk acceptance"];
    default:
      return [];
  }
}

export function approvalBoundaryForRole(role) {
  switch (role) {
    case "developer":
      return "Implement only the approved packet scope. Do not change approval state.";
    case "tester":
      return "Verify only the approved packet scope. Do not directly remediate.";
    case "reviewer":
      return "Assess conformance and closeout readiness. Do not implement fixes.";
    case "planner":
      return "Close scope and approval boundaries only after evidence is present.";
    case "orchestrator":
      return "Route only approved packet execution. Continue bounded loops unless thresholds or authority stop conditions require human input.";
    default:
      return "Stay inside the approved packet and workflow authority.";
  }
}

export function doNotCrossForRole(role) {
  switch (role) {
    case "developer":
      return ["No approval-state changes.", "No Tester or Reviewer gate claims.", "No manual generated-doc edits."];
    case "tester":
      return ["No implementation changes.", "No Reviewer closeout claims.", "No approval-state changes."];
    case "reviewer":
      return ["No implementation changes.", "No Tester evidence rewrite.", "No Planner closeout claims."];
    case "planner":
      return ["No implementation changes.", "No Tester or Reviewer judgment substitution."];
    case "orchestrator":
      return [
        "No code remediation by Orchestrator.",
        "No Tester or Reviewer judgment substitution.",
        "No Planner closeout approval.",
        "Do not stop before bounded-loop thresholds unless an authority stop condition is present."
      ];
    default:
      return ["Do not exceed the approved packet scope."];
  }
}

export function nextRoleAfter(role) {
  switch (role) {
    case "developer":
      return "tester";
    case "tester":
      return "reviewer";
    case "reviewer":
      return "planner";
    default:
      return null;
  }
}

export function invalidRoleMessage(role) {
  const roleText = role ?? "missing";
  const schemaVisible = SCHEMA_VISIBLE_WORKFLOW_ROLES.includes(roleText);
  if (schemaVisible) {
    return (
      `Role ${roleText} is schema-visible for workflow authority but is not routeable by harness:agent. ` +
      `Expected one of ${ROUTEABLE_AGENT_ROLES.join(", ")}.`
    );
  }
  return `Invalid or missing --role. Expected one of ${ROUTEABLE_AGENT_ROLES.join(", ")}.`;
}

export function normalizeRole(value) {
  const normalized = String(value ?? "").trim().toLowerCase();
  return normalized || null;
}

export function normalizeDeliveryRouteMode(value) {
  const normalized = String(value ?? "").trim().toLowerCase();
  return VALID_DELIVERY_ROUTE_MODES.has(normalized) ? normalized : null;
}

export function validateDeliveryRouteModeForTransition({ transition, deliveryRouteMode, routeClass }) {
  const startsDelivery = transition === "planner-to-developer" || transition === "planner-to-orchestrator";
  if (!startsDelivery) {
    return [];
  }
  const normalizedRouteClass = String(routeClass ?? "").trim().toLowerCase();
  if (!["packet-path", "strict-path"].includes(normalizedRouteClass) && !deliveryRouteMode) {
    return [];
  }
  if (!deliveryRouteMode) {
    return [`${transition} requires Delivery route mode for packet-path or strict-path Ready For Code delivery.`];
  }
  if (deliveryRouteMode === "orchestrated-closeout" && transition !== "planner-to-orchestrator") {
    return ["Delivery route mode orchestrated-closeout requires first transition planner-to-orchestrator."];
  }
  if (deliveryRouteMode === "role-by-role" && transition !== "planner-to-developer") {
    return ["Delivery route mode role-by-role requires first transition planner-to-developer."];
  }
  return [];
}
