export function buildValidationReportMarkdown(report) {
  const lines = [
    "# Validation Report",
    "",
    "## Summary",
    `- Executed at: ${report.executedAt}`,
    `- Validator version: ${report.validatorVersion}`,
    `- Cutover ready: ${report.cutoverReady ? "yes" : "no"}`,
    `- Gate decision: ${report.gateDecision}`,
    `- Next action: ${report.nextAction}`,
    "- Scope: harness structural/state validation and workflow evidence consistency only; this is not product/feature verification approval.",
    "- Product evidence owner: Tester/Reviewer/product-specific acceptance evidence.",
    "- Surface role: persisted gate evidence only, not product acceptance; live re-entry should use `.agents/runtime/ACTIVE_CONTEXT.json` and CLI context/status.",
    "",
    "## Active Profiles",
    `- Source: ${report.profileSummary.path}`,
    `- Status: ${report.profileSummary.status}`
  ];

  if (report.profileSummary.profiles.length === 0) {
    lines.push("- Profiles: none");
  } else {
    for (const profile of report.profileSummary.profiles) {
      lines.push(`- ${profile.profileId}: ${profile.evidenceStatus} (${profile.reason})`);
    }
  }

  lines.push("", "## Risk Classifications");
  if (!report.riskClassifications || report.riskClassifications.length === 0) {
    lines.push("- none");
  } else {
    for (const classification of report.riskClassifications) {
      lines.push(
        `- ${classification.packetPath}: declared ${classification.declaredRiskClass ?? "not-declared"}, ` +
          `derived ${classification.derivedRiskClass}, effective ${classification.effectiveRiskClass}, ` +
          `requested route ${classification.requestedRouteClass ?? classification.routeClass ?? "not-declared"}, ` +
          `chosen route ${classification.chosenRouteClass ?? classification.routeClass ?? "not-declared"}, ` +
          `eligibility ${classification.routeEligibility ?? "not-applicable"}, gate effect ${classification.gateEffect}`
      );
      if ((classification.routeRejectionReasons?.length ?? 0) > 0) {
        lines.push(`  - rejection reasons: ${classification.routeRejectionReasons.join("; ")}`);
      }
      if (classification.modelingImpact) {
        lines.push(
          `  - modeling impact: status ${classification.modelingImpact.status}, ` +
            `required ${classification.modelingImpact.required ? "yes" : "no"}, ` +
            `diagnostics ${classification.modelingImpact.diagnosticCount}`
        );
      }
    }
  }

  lines.push("", "## Findings");
  if (report.findings.length === 0) {
    lines.push("- none");
  } else {
    for (const finding of report.findings) {
      lines.push(`- [${finding.severity}] ${finding.code}: ${finding.message}`);
    }
  }

  lines.push("", "## Context Budget");
  if (!report.contextBudget) {
    lines.push("- none");
  } else {
    lines.push(`- Status: ${report.contextBudget.status}`);
    lines.push(`- Enforcement: ${report.contextBudget.enforcement}; hard fail: ${report.contextBudget.hardFailEnabled ? "enabled" : "disabled"}`);
    lines.push(`- Severity: ${report.contextBudget.severity ?? "info"}; blocking: ${report.contextBudget.blocking ? "yes" : "no"}; gate effect: ${report.contextBudget.gateEffect ?? "advisory-only"}`);
    lines.push(`- Operator message: ${report.contextBudget.operatorMessage ?? "Context budget diagnostics are advisory unless hardFailEnabled is true."}`);
    lines.push(`- Work item: ${report.contextBudget.workItemId}`);
    lines.push(`- Role: ${report.contextBudget.role}`);
    if (report.contextBudget.defaultReadSet) {
      lines.push(
        `- Default read set: files ${report.contextBudget.defaultReadSet.fileCount}/${report.contextBudget.defaultReadSet.maxFileCount}, ` +
          `tokens ${report.contextBudget.defaultReadSet.tokenEstimate}/${report.contextBudget.defaultReadSet.maxTokenEstimate}`
      );
    }
    if (report.contextBudget.fallbackOnlyReadSet) {
      const triggers = report.contextBudget.fallbackOnlyReadSet.triggerReasons ?? [];
      lines.push(
        `- Fallback-only reads: files ${report.contextBudget.fallbackOnlyReadSet.fileCount}, ` +
          `triggers ${triggers.length === 0 ? "none" : triggers.join("; ")}`
      );
    }
    lines.push(`- Overrun rationale: ${report.contextBudget.overrunRationale ?? "none"}`);
    lines.push(`- Warning count: ${report.contextBudget.warningCount}`);
    if (report.contextBudget.outputBudget) {
      lines.push(
        `- Output budget: summary <= ${report.contextBudget.outputBudget.summaryMaxLines} lines, ` +
          `closeout <= ${report.contextBudget.outputBudget.closeoutMaxLines} lines, ` +
          `history policy ${report.contextBudget.outputBudget.repeatedHistoryPolicy}`
      );
    }
  }

  lines.push("", "## V2.5 Risk-Adaptive Gate Summary");
  if (!report.riskAdaptive) {
    lines.push("- Status: not-applicable");
  } else {
    lines.push(`- Gate effect: ${report.riskAdaptive.gateEffect}`);
    lines.push(`- Lane: ${report.riskAdaptive.lane}`);
    lines.push(`- Phase: ${report.riskAdaptive.phase}`);
    lines.push(`- Risk overlays: ${report.riskAdaptive.riskOverlays.length === 0 ? "none" : report.riskAdaptive.riskOverlays.join(", ")}`);
    lines.push(`- Read set: ${report.riskAdaptive.readCount} files, estimated ${report.riskAdaptive.estimatedTokensRead}/${report.riskAdaptive.targetTokens} tokens`);
    lines.push(`- Context budget status: ${report.riskAdaptive.contextBudgetStatus}`);
    lines.push(`- Human manual auto-read: ${report.riskAdaptive.humanManualAutoRead ? "yes" : "no"}`);
    lines.push(`- Blocking diagnostics: ${report.riskAdaptive.blocking ? "yes" : "no"}`);
    lines.push("- Overlay evidence:");
    if (report.riskAdaptive.overlayEvidence.length === 0) lines.push("  - none");
    else for (const item of report.riskAdaptive.overlayEvidence) lines.push(`  - ${item}`);
    if ((report.riskAdaptive.diagnostics ?? []).length > 0) {
      lines.push("- Diagnostics:");
      for (const item of report.riskAdaptive.diagnostics) lines.push(`  - [${item.status}] ${item.field}: ${item.message}`);
    }
    lines.push(`- Next action: ${report.riskAdaptive.nextAction}`);
  }

  lines.push("", "## LLM Judge");
  if (!report.llmJudge) {
    lines.push("- Status: not-applicable");
  } else {
    lines.push(`- Status: ${report.llmJudge.status}`);
    lines.push(`- Gate effect: ${report.llmJudge.gateEffect}`);
    lines.push(`- Work item: ${report.llmJudge.workItemId}`);
    lines.push(`- Provider invocation: ${report.llmJudge.providerInvocation}`);
    lines.push(`- Context package: ${report.llmJudge.contextPackage.status}`);
    lines.push(`- Allowed input fields: ${report.llmJudge.contextPackage.allowedInputFields.join(", ")}`);
    lines.push(`- Result status: ${report.llmJudge.result.status}`);
    lines.push(`- Result source: ${report.llmJudge.result.sourceMode} (${report.llmJudge.result.sourcePath ?? "none"})`);
    lines.push(
      `- Can claim live independent review: ${report.llmJudge.result.canClaimLiveIndependentReview ? "yes" : "no"}`
    );
    lines.push(`- Rationale: ${report.llmJudge.result.rationale}`);
    lines.push(
      `- Advisory findings: ${
        report.llmJudge.result.findings.length === 0 ? "none" : report.llmJudge.result.findings.length
      }`
    );
    for (const finding of report.llmJudge.result.findings) {
      lines.push(`  - ${finding.code}: ${finding.message}${finding.sourceRef ? ` (${finding.sourceRef})` : ""}`);
    }
    lines.push(
      `- Advisory disagreements: ${
        report.llmJudge.result.disagreements.length === 0 ? "none" : report.llmJudge.result.disagreements.length
      }`
    );
    for (const disagreement of report.llmJudge.result.disagreements) {
      lines.push(
        `  - ${disagreement.code}: ${disagreement.message}${disagreement.sourceRef ? ` (${disagreement.sourceRef})` : ""}`
      );
    }
    lines.push(`- Diagnostics: ${report.llmJudge.diagnostics.length === 0 ? "none" : report.llmJudge.diagnostics.length}`);
    for (const diagnostic of report.llmJudge.diagnostics) {
      lines.push(`  - ${diagnostic.code}: ${diagnostic.message}`);
    }
  }

  if (report.securityReview) {
    lines.push("", "## Security Review Summary");
    if (report.securityReview.contractStatus === "not-applicable") {
      lines.push("- Status: not-applicable");
      lines.push(`- Activation source: ${report.securityReview.activationSource}`);
      lines.push(`- Reason: ${report.securityReview.notApplicableReason}`);
    } else {
      lines.push(`- Activation source: ${report.securityReview.activationSource}`);
      lines.push(`- Summary status: ${report.securityReview.summaryStatus}`);
      lines.push(`- Checked scope: ${report.securityReview.checkedScope.join(", ")}`);
      lines.push(
        `- Declared security/release paths: ${
          report.securityReview.declaredPaths.length === 0 ? "none" : report.securityReview.declaredPaths.join(", ")
        }`
      );
      lines.push(
        `- Blocking error findings: ${report.securityReview.blockingErrorFindings.length === 0 ? "none" : report.securityReview.blockingErrorFindings.length}`
      );
      if (report.securityReview.blockingErrorFindings.length > 0) {
        for (const finding of report.securityReview.blockingErrorFindings) {
          lines.push(`  - ${finding.code}: ${finding.message}`);
        }
      }
      lines.push(
        `- Warning findings: ${report.securityReview.warningFindings.length === 0 ? "none" : report.securityReview.warningFindings.length}`
      );
      if (report.securityReview.warningFindings.length > 0) {
        for (const finding of report.securityReview.warningFindings) {
          lines.push(`  - ${finding.code}: ${finding.message}`);
        }
      }
      lines.push("- Review-required categories:");
      for (const category of report.securityReview.reviewRequiredCategories) {
        lines.push(`  - ${category.label}: ${category.reviewNote}`);
      }
      lines.push("- Operator next actions:");
      for (const action of report.securityReview.operatorNextActions) {
        lines.push(`  - ${action}`);
      }
      lines.push("- Human review still required:");
      for (const note of report.securityReview.humanReviewStillRequired) {
        lines.push(`  - ${note}`);
      }
      lines.push(`- Out of scope note: ${report.securityReview.outOfScopeNote}`);

      lines.push("", "## Dependency Inventory");
      for (const pkg of report.securityReview.dependencyInventory.packages) {
        lines.push(`- ${pkg.packageLabel}: ${pkg.packageName} / node ${pkg.nodeEngine}`);
        lines.push(
          `  - direct dependencies: ${pkg.directDependencies.length === 0 ? "none" : pkg.directDependencies.join(", ")}`
        );
        lines.push(
          `  - direct devDependencies: ${pkg.directDevDependencies.length === 0 ? "none" : pkg.directDevDependencies.join(", ")}`
        );
        lines.push(`  - release scripts: ${pkg.releaseScripts.length === 0 ? "none" : pkg.releaseScripts.join(", ")}`);
      }

      lines.push("", "## Local Secret Scan");
      lines.push(`- Scanned paths: ${report.securityReview.localSecretScan.scannedPaths.length}`);
      lines.push(`- Scan rules: ${report.securityReview.localSecretScan.scanRuleCount}`);
      lines.push(
        `- Findings: ${report.securityReview.localSecretScan.findingCount === 0 ? "none" : report.securityReview.localSecretScan.findingCount}`
      );

      lines.push("", "## Release Artifact Audit");
      lines.push(
        `- Checked artifacts: ${report.securityReview.releaseArtifactAudit.checkedArtifacts.length === 0 ? "none" : report.securityReview.releaseArtifactAudit.checkedArtifacts.length}`
      );
      for (const artifact of report.securityReview.releaseArtifactAudit.checkedArtifacts) {
        lines.push(`  - ${artifact.path}`);
      }
      lines.push(
        `- Audit findings: ${report.securityReview.releaseArtifactAudit.findingCount === 0 ? "none" : report.securityReview.releaseArtifactAudit.findingCount}`
      );
    }
  }

  lines.push("", "## Semantic Trace");
  if (!report.traceSummary) {
    lines.push("- none");
  } else {
    lines.push(`- Path: ${report.traceSummary.path}`);
    lines.push(`- Work item: ${report.traceSummary.workItemId}`);
    lines.push(`- Packet: ${report.traceSummary.packetId}`);
    lines.push(`- Turn closed at: ${report.traceSummary.turnClosedAt}`);
    lines.push(`- Status: ${report.traceSummary.semanticTraceStatus}`);
    lines.push(`- Warning count: ${report.traceSummary.warningCount}`);
    if (report.traceSummary.workflowDisciplineStatus) {
      lines.push(
        `- Workflow discipline: ${report.traceSummary.workflowDisciplineStatus} / warning ${report.traceSummary.workflowDisciplineWarningCount ?? 0} / closeout hold ${report.traceSummary.workflowDisciplineCloseoutHoldCount ?? 0} / hard error ${report.traceSummary.workflowDisciplineHardErrorCount ?? 0}`
      );
    }
  }

  lines.push("", "## Candidate Gates");
  for (const gate of report.candidateGates ?? []) {
    lines.push(`- ${gate.id}: ${gate.phase} / ${gate.description}`);
  }

  return `${lines.join("\n")}\n`;
}
