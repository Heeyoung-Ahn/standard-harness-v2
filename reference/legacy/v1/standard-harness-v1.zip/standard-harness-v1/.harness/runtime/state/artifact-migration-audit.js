import fs from "node:fs";
import path from "node:path";

import { canonicalPacketMarkdownPathForId } from "./packet-paths.js";

const DEFAULT_SCAN_ROOTS = [
  "reference/packets",
  // Deleted legacy roots are scanned only to detect stale leftovers during
  // migration audits. They are not active generation targets.
  "reference/reports",
  ".agents/runtime/generated-state-docs",
  ".agents/runtime/review-report-excerpts"
];

const TEXT_EXTENSIONS = new Set([".md", ".json", ".txt", ".tsv", ".csv"]);

export function runArtifactMigrationAuditCommand({
  repoRoot = process.cwd(),
  args = []
} = {}) {
  const options = parseArgs(args);
  const workItemId = options.workItem ?? options.workItemId ?? "OPS-HARNESS-16-MIGRATION-FOLLOWUP";
  const packetPath = normalizeRelativePath(options.packet ?? options.packetPath ?? canonicalPacketMarkdownPathForId(workItemId));
  const apply = Boolean(options.apply) && !options.dryRun;
  const outputRoot = normalizeRelativePath(
    options.outputRoot ?? `reference/packets/${workItemId}/08_evidence`
  );
  const scanRoots = normalizeList(options.scanRoot ?? options.scanRoots) ?? DEFAULT_SCAN_ROOTS;
  const errors = [];

  if (!workItemId) {
    errors.push("Missing --work-item.");
  }
  if (!packetPath) {
    errors.push("Missing --packet.");
  }

  const audit = buildArtifactMigrationAudit({
    repoRoot,
    workItemId,
    packetPath,
    scanRoots
  });

  const jsonPath = `${outputRoot}/ARTIFACT_MIGRATION_AUDIT.json`;
  const markdownPath = `${outputRoot}/ARTIFACT_MIGRATION_AUDIT.md`;

  if (errors.length === 0 && apply) {
    writeTextFile(repoRoot, jsonPath, `${JSON.stringify(audit, null, 2)}\n`);
    writeTextFile(repoRoot, markdownPath, renderArtifactMigrationAuditMarkdown(audit));
  }

  return {
    ok: errors.length === 0 && audit.errors.length === 0,
    command: "artifact-migration-audit",
    apply,
    workItemId,
    packetPath,
    scanRoots,
    output: {
      jsonPath,
      markdownPath,
      written: apply
    },
    artifactCount: audit.artifacts.length,
    blockingFindingCount: audit.findings.filter((finding) => finding.severity === "blocking").length,
    errors: [...errors, ...audit.errors],
    findings: audit.findings,
    nextAction: apply
      ? "Review packet-local ARTIFACT_MIGRATION_AUDIT evidence. Do not move/archive artifacts without exact-path approval."
      : "Re-run with --apply to write packet-local audit evidence."
  };
}

export function buildArtifactMigrationAudit({
  repoRoot = process.cwd(),
  workItemId = "OPS-HARNESS-16-MIGRATION-FOLLOWUP",
  packetPath = canonicalPacketMarkdownPathForId(workItemId),
  scanRoots = DEFAULT_SCAN_ROOTS
} = {}) {
  const normalizedScanRoots = scanRoots.map(normalizeRelativePath).filter(Boolean);
  const allTextFiles = collectTextFiles(repoRoot, [
    ".agents/artifacts",
    ".agents/runtime",
    "reference"
  ]);
  const scannedArtifacts = normalizedScanRoots.flatMap((scanRoot) => collectTextFiles(repoRoot, [scanRoot]));
  const uniqueArtifacts = [...new Map(scannedArtifacts.map((filePath) => [filePath, filePath])).values()]
    .sort((a, b) => a.localeCompare(b));

  const artifacts = uniqueArtifacts.map((artifactPath) => {
    const classification = classifyArtifactPath(artifactPath);
    const proposedTarget = proposeTargetPath({ artifactPath, classification, workItemId });
    const citedBy = findCitations({ repoRoot, targetPath: artifactPath, allTextFiles });
    const collision = proposedTarget ? detectCollision({ repoRoot, artifactPath, proposedTarget }) : null;
    const applyReady = classification.applyCandidate && citedBy.length === 0 && !collision?.exists;

    return {
      artifact_id: artifactIdFromPath(artifactPath),
      current_path: artifactPath,
      classification: classification.kind,
      retention_reason: classification.retentionReason,
      compatibility_action: classification.compatibilityAction,
      proposed_target_path: proposedTarget,
      cited_by: citedBy,
      collision_risk: collision?.exists ? "blocked" : "none",
      approval_state: applyReady ? "requires-exact-approval" : "blocked-or-retain",
      no_write_result: "no move"
    };
  });

  const findings = [];
  for (const artifact of artifacts) {
    if (artifact.classification === "generated_read_model" && artifact.proposed_target_path) {
      findings.push({
        severity: "blocking",
        code: "generated_read_model_has_target",
        artifact: artifact.current_path,
        message: "Generated read models must be regenerated, not moved or archived."
      });
    }
    if (artifact.collision_risk === "blocked") {
      findings.push({
        severity: "blocking",
        code: "migration_target_collision",
        artifact: artifact.current_path,
        target: artifact.proposed_target_path,
        message: "Proposed target already exists; exact-path apply is blocked."
      });
    }
  }

  return {
    schemaVersion: "standard-harness-artifact-migration-audit/v1",
    workItemId,
    packetPath: normalizeRelativePath(packetPath),
    generatedAt: new Date().toISOString(),
    mode: "no-write-audit",
    scanRoots: normalizedScanRoots,
    applySupported: false,
    destructiveApplyBoundary: "move/delete/archive apply is not implemented by this command",
    artifacts,
    findings,
    errors: []
  };
}

export function renderArtifactMigrationAuditMarkdown(audit) {
  const lines = [
    `# ${audit.workItemId} Artifact Migration Audit`,
    "",
    "## Boundary",
    "",
    "- Mode: no-write audit.",
    "- Move/delete/archive apply: not implemented by this command.",
    `- Packet: \`${audit.packetPath}\``,
    `- Generated at: ${audit.generatedAt}`,
    "",
    "## Summary",
    "",
    `- Artifact count: ${audit.artifacts.length}`,
    `- Blocking findings: ${audit.findings.filter((finding) => finding.severity === "blocking").length}`,
    "- Future apply requires exact source paths, exact target paths, rollback command, validation command, and explicit human approval.",
    "",
    "## Classification Rows",
    "",
    "| artifact_id | current_path | classification | proposed_target_path | cited_by_count | collision_risk | approval_state | no_write_result |",
    "|---|---|---|---|---:|---|---|---|"
  ];

  for (const artifact of audit.artifacts) {
    lines.push([
      artifact.artifact_id,
      code(artifact.current_path),
      artifact.classification,
      artifact.proposed_target_path ? code(artifact.proposed_target_path) : "not-needed",
      String(artifact.cited_by.length),
      artifact.collision_risk,
      artifact.approval_state,
      artifact.no_write_result
    ].join(" | ").replace(/^/, "| ").replace(/$/, " |"));
  }

  lines.push("", "## Findings", "");
  if (audit.findings.length === 0) {
    lines.push("- No blocking findings in no-write audit.");
  } else {
    for (const finding of audit.findings) {
      lines.push(`- ${finding.severity}: ${finding.code} - ${finding.message}`);
    }
  }

  lines.push("");
  return `${lines.join("\n")}\n`;
}

function classifyArtifactPath(artifactPath) {
  if (artifactPath.startsWith(".agents/runtime/generated-state-docs/") ||
    artifactPath.startsWith(".agents/runtime/review-report-excerpts/")) {
    return {
      kind: "generated_read_model",
      retentionReason: "regenerate_only",
      compatibilityAction: "exclude_from_move",
      applyCandidate: false
    };
  }
  if (/^reference\/packets\/[^/]+\.md$/u.test(artifactPath)) {
    return {
      kind: "legacy_flat_packet",
      retentionReason: "decision_trace",
      compatibilityAction: "move_to_00_packet",
      applyCandidate: true
    };
  }
  if (artifactPath.startsWith("reference/packets/")) {
    return {
      kind: "packet_local_evidence",
      retentionReason: "replay",
      compatibilityAction: "keep_packet_local",
      applyCandidate: false
    };
  }
  if (artifactPath.startsWith("reference/reports/")) {
    return {
      kind: "legacy_report_root_leftover",
      retentionReason: "compatibility",
      compatibilityAction: "move_to_packet_local_or_remove_legacy_root",
      applyCandidate: true
    };
  }
  return {
    kind: "blocked",
    retentionReason: "unknown_boundary",
    compatibilityAction: "manual_review",
    applyCandidate: false
  };
}

function proposeTargetPath({ artifactPath, classification, workItemId }) {
  if (!classification.applyCandidate) {
    return null;
  }
  if (classification.kind === "legacy_flat_packet") {
    const packetId = path.basename(artifactPath, path.extname(artifactPath));
    return canonicalPacketMarkdownPathForId(packetId);
  }
  const parts = artifactPath.split("/");
  const fileName = parts.at(-1);
  const role = parts.length >= 3 ? parts.at(-2) : "unknown";
  return `reference/packets/${workItemId}/99_superseded/reference_reports_${role}_${fileName}`;
}

function findCitations({ repoRoot, targetPath, allTextFiles }) {
  const needles = new Set([targetPath, targetPath.replaceAll("/", "\\")]);
  return allTextFiles.filter((filePath) => {
    if (filePath === targetPath) {
      return false;
    }
    const content = safeReadText(repoRoot, filePath);
    return [...needles].some((needle) => content.includes(needle));
  });
}

function detectCollision({ repoRoot, artifactPath, proposedTarget }) {
  const absoluteTarget = path.resolve(repoRoot, proposedTarget);
  const exists = fs.existsSync(absoluteTarget);
  return {
    exists,
    sameAsSource: normalizeRelativePath(artifactPath) === normalizeRelativePath(proposedTarget)
  };
}

function collectTextFiles(repoRoot, roots) {
  const collected = [];
  for (const root of roots) {
    const absoluteRoot = path.resolve(repoRoot, root);
    if (!isInside(repoRoot, absoluteRoot) || !fs.existsSync(absoluteRoot)) {
      continue;
    }
    walk(absoluteRoot, (absolutePath) => {
      const relativePath = normalizeRelativePath(path.relative(repoRoot, absolutePath));
      if (TEXT_EXTENSIONS.has(path.extname(relativePath).toLowerCase())) {
        collected.push(relativePath);
      }
    });
  }
  return collected;
}

function walk(absoluteRoot, visit) {
  const entries = fs.readdirSync(absoluteRoot, { withFileTypes: true });
  for (const entry of entries) {
    const absolutePath = path.join(absoluteRoot, entry.name);
    if (entry.isDirectory()) {
      walk(absolutePath, visit);
    } else if (entry.isFile()) {
      visit(absolutePath);
    }
  }
}

function safeReadText(repoRoot, relativePath) {
  try {
    return fs.readFileSync(path.resolve(repoRoot, relativePath), "utf8");
  } catch {
    return "";
  }
}


function writeTextFile(repoRoot, relativePath, content) {
  const absolutePath = path.resolve(repoRoot, relativePath);
  if (!isInside(repoRoot, absolutePath)) {
    throw new Error(`Refusing to write outside repo: ${relativePath}`);
  }
  fs.mkdirSync(path.dirname(absolutePath), { recursive: true });
  fs.writeFileSync(absolutePath, content, "utf8");
}

function artifactIdFromPath(artifactPath) {
  return artifactPath
    .replace(/\.[a-z0-9]+$/iu, "")
    .replace(/[^a-z0-9]+/giu, "-")
    .replace(/^-|-$/gu, "")
    .toLowerCase();
}

function normalizeList(value) {
  if (!value) {
    return null;
  }
  if (Array.isArray(value)) {
    return value;
  }
  return String(value).split(",").map((item) => item.trim()).filter(Boolean);
}

function parseArgs(args = []) {
  const options = { positionals: [] };
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    if (arg === "--apply") {
      options.apply = true;
    } else if (arg === "--dry-run") {
      options.dryRun = true;
    } else if (arg.startsWith("--")) {
      const key = arg.slice(2).replace(/-([a-z])/gu, (_, letter) => letter.toUpperCase());
      const next = args[index + 1];
      if (!next || next.startsWith("--")) {
        options[key] = true;
      } else {
        options[key] = next;
        index += 1;
      }
    } else {
      options.positionals.push(arg);
    }
  }
  return options;
}

function normalizeRelativePath(value) {
  if (!value) {
    return null;
  }
  return String(value).replaceAll("\\", "/").replace(/^\.?\//u, "");
}

function isInside(repoRoot, absolutePath) {
  const relative = path.relative(path.resolve(repoRoot), absolutePath);
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

function code(value) {
  return `\`${value}\``;
}
