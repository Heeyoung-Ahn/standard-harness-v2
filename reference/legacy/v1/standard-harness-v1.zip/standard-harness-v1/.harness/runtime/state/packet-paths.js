import fs from "node:fs";
import path from "node:path";

const PACKET_ROOT = "reference/packets";

export function normalizeRelativePath(value) {
  if (!value) {
    return null;
  }
  return String(value).replace(/\\/g, "/").replace(/^\.\//, "");
}

export function packetIdFromPacketPath(value) {
  const normalized = normalizeRelativePath(value);
  if (!normalized) {
    return null;
  }

  const lifecycleMatch = normalized.match(/^reference\/packets\/([^/]+)\/00_packet\/([^/]+)\.md$/u);
  if (lifecycleMatch) {
    return lifecycleMatch[1];
  }

  const flatMatch = normalized.match(/^reference\/packets\/([^/]+)\.md$/u);
  if (flatMatch) {
    return flatMatch[1];
  }

  return null;
}

export function canonicalPacketMarkdownPathForId(packetId) {
  if (!packetId) {
    return null;
  }
  return `${PACKET_ROOT}/${packetId}/00_packet/${packetId}.md`;
}

export function canonicalizePacketMarkdownPath(repoRoot, value) {
  const normalized = normalizeRelativePath(value);
  const packetId = packetIdFromPacketPath(normalized);
  if (!packetId) {
    return normalized;
  }

  const canonicalPath = canonicalPacketMarkdownPathForId(packetId);
  if (canonicalPath && fs.existsSync(path.resolve(repoRoot, canonicalPath))) {
    return canonicalPath;
  }
  return normalized;
}

export function resolvePacketMarkdownPath(repoRoot, value) {
  const canonical = canonicalizePacketMarkdownPath(repoRoot, value);
  if (canonical && fs.existsSync(path.resolve(repoRoot, canonical))) {
    return canonical;
  }
  return normalizeRelativePath(value);
}
