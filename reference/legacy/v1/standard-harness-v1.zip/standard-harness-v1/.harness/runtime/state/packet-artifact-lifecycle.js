import fs from "node:fs";
import path from "node:path";

import {
  normalizePacketHeaderValue,
  readPacketHeaderValueFromContent
} from "./lib/packet-markdown.js";
import { canonicalPacketMarkdownPathForId } from "./packet-paths.js";

export const PACKET_ARTIFACT_PHASES = [
  "00_packet",
  "01_planning",
  "02_design",
  "03_implementation",
  "04_testing",
  "05_review",
  "06_security",
  "07_closeout",
  "08_evidence",
  "90_interim",
  "99_superseded"
];

export const REQUIRED_PACKET_MANIFEST_FIELDS = [
  "artifact_id",
  "path",
  "phase",
  "status",
  "retention_reason",
  "owner",
  "authority_type",
  "canonical_role",
  "source_refs",
  "decision_refs",
  "implementation_refs",
  "test_refs",
  "review_refs",
  "security_refs",
  "closeout_refs",
  "source_or_superseded_by",
  "cited_by",
  "created_or_updated_by",
  "created_or_updated_at",
  "closeout_relevance"
];

const REQUIRED_COMPATIBILITY_POINTER_FIELDS = [
  "canonical_target",
  "legacy_path",
  "content_digest",
  "generation_source",
  "generated_at",
  "last_verified_at",
  "invalidation_behavior"
];

const REQUIRED_MIGRATION_APPROVAL_FIELDS = [
  "approval_ref",
  "reviewer_ref",
  "classification_decision_ref",
  "follow_up_apply_packet_id",
  "rollback_evidence_ref"
];

const DECLARED_LIFECYCLE_VALUES = new Set([
  "declared",
  "planning-declared",
  "active",
  "approved",
  "required",
  "yes"
]);

export function runPacketArtifactInitCommand({
  repoRoot = process.cwd(),
  args = []
} = {}) {
  const options = parseArgs(args);
  const packetPath = normalizeRelativePath(options.packet ?? options.packetPath ?? options.sourceRef ?? options.positionals?.[0]);
  const apply = Boolean(options.apply) && !options.dryRun;
  const errors = [];

  if (!packetPath) {
    errors.push("Missing --packet or --packet-path.");
  }

  const packetAbsolutePath = packetPath ? resolveInside(repoRoot, packetPath) : null;
  const packetExists = packetAbsolutePath ? fs.existsSync(packetAbsolutePath) : false;
  if (packetPath && !packetExists) {
    errors.push(`Packet file not found: ${packetPath}.`);
  }

  const packetContent = packetExists ? fs.readFileSync(packetAbsolutePath, "utf8") : "";
  const packetId = resolvePacketId({
    explicitWorkItemId: options.workItem ?? options.workItemId,
    packetPath,
    content: packetContent
  });
  if (!packetId) {
    errors.push("Could not resolve packet id from --work-item, packet header, or packet filename.");
  }

  const lifecycleRoot = packetId ? `reference/packets/${packetId}` : null;
  const canonicalPacketPath = packetId ? canonicalPacketMarkdownPathForId(packetId) : null;
  const manifestPath = lifecycleRoot ? `${lifecycleRoot}/PACKET_MANIFEST.md` : null;
  const phasePaths = lifecycleRoot
    ? PACKET_ARTIFACT_PHASES.map((phase) => `${lifecycleRoot}/${phase}`)
    : [];

  const createdDirectories = [];
  let manifestAction = "not-written";
  if (errors.length === 0 && apply) {
    for (const phasePath of phasePaths) {
      const absolutePhasePath = resolveInside(repoRoot, phasePath);
      if (!fs.existsSync(absolutePhasePath)) {
        fs.mkdirSync(absolutePhasePath, { recursive: true });
        createdDirectories.push(phasePath);
      }
      const readmePath = path.join(absolutePhasePath, "README.md");
      if (!fs.existsSync(readmePath)) {
        fs.writeFileSync(readmePath, renderPhaseReadme({ packetId, phase: path.basename(phasePath) }), "utf8");
      }
    }

    const absoluteManifestPath = resolveInside(repoRoot, manifestPath);
    if (fs.existsSync(absoluteManifestPath)) {
      manifestAction = "exists";
    } else {
      fs.mkdirSync(path.dirname(absoluteManifestPath), { recursive: true });
      fs.writeFileSync(
        absoluteManifestPath,
        renderPacketManifest({
          repoRoot,
          packetId,
          canonicalPacketPath
        }),
        "utf8"
      );
      manifestAction = "created";
    }
  } else if (errors.length === 0) {
    manifestAction = "preview";
  }

  return {
    ok: errors.length === 0,
    command: "packet-artifact-init",
    apply,
    packetId,
    canonicalPacketPath,
    lifecycleRoot,
    manifestPath,
    phasePaths,
    createdDirectories,
    manifestAction,
    errors,
    nextAction: errors.length > 0
      ? "Provide a valid packet path and work-item id."
      : apply
        ? "Review PACKET_MANIFEST.md and add packet-local evidence rows as artifacts are created."
        : "Re-run with --apply to create the packet lifecycle scaffold."
  };
}

export function runPacketArtifactValidateCommand({
  repoRoot = process.cwd(),
  args = [],
  stage = "planning-open"
} = {}) {
  const options = parseArgs(args);
  const packetPath = normalizeRelativePath(options.packet ?? options.packetPath ?? options.sourceRef ?? options.positionals?.[0]);
  const errors = [];
  if (!packetPath) {
    errors.push("Missing --packet or packet path.");
  }

  const resolvedPacketPath = packetPath
    ? resolvePacketInputPath({
        repoRoot,
        packetPath,
        workItemId: options.workItem ?? options.workItemId
      })
    : null;
  if (packetPath && !resolvedPacketPath) {
    errors.push(`Packet file not found: ${packetPath}.`);
  }

  const packetAbsolutePath = resolvedPacketPath ? resolveInside(repoRoot, resolvedPacketPath) : null;
  const content = packetAbsolutePath && fs.existsSync(packetAbsolutePath)
    ? fs.readFileSync(packetAbsolutePath, "utf8")
    : "";
  const result = evaluatePacketArtifactLifecycle({
    repoRoot,
    content,
    packetPath: resolvedPacketPath ?? packetPath,
    workItemId: options.workItem ?? options.workItemId,
    stage: options.stage ?? stage
  });
  return {
    ok: errors.length === 0 && result.ok,
    command: stage === "closeout" ? "packet-artifact-closeout" : "packet-artifact-validate",
    packetPath: resolvedPacketPath ?? packetPath,
    stage: options.stage ?? stage,
    result,
    errors
  };
}

export function runPacketArtifactCloseoutCommand({ repoRoot = process.cwd(), args = [] } = {}) {
  return runPacketArtifactValidateCommand({ repoRoot, args, stage: "closeout" });
}

export function evaluatePacketArtifactLifecycle({
  repoRoot = process.cwd(),
  content = "",
  packetPath = null,
  workItemId = null,
  stage = "planning-open"
} = {}) {
  const normalizedPacketPath = normalizeRelativePath(packetPath);
  const packetId = resolvePacketId({
    explicitWorkItemId: workItemId,
    packetPath: normalizedPacketPath,
    content
  });
  const manifestPath = packetId ? `reference/packets/${packetId}/PACKET_MANIFEST.md` : null;
  const manifestContent = manifestPath && fs.existsSync(resolveInside(repoRoot, manifestPath))
    ? fs.readFileSync(resolveInside(repoRoot, manifestPath), "utf8")
    : "";
  const declared = isLifecycleDeclared(content) || isLifecycleDeclared(manifestContent);
  const required = declared;
  const diagnostics = [];

  if (!required) {
    return {
      ok: true,
      required: false,
      declared: false,
      packetId,
      manifestPath,
      diagnostics,
      blocking: false
    };
  }

  if (stage !== "closeout") {
    return {
      ok: true,
      required: true,
      declared: true,
      packetId,
      manifestPath,
      diagnostics,
      blocking: false
    };
  }

  if (!manifestPath) {
    diagnostics.push({
      field: "Packet artifact lifecycle",
      code: "packet_artifact_lifecycle_manifest_path_missing",
      message: "Declared packet artifact lifecycle closeout requires a resolvable packet id and PACKET_MANIFEST path."
    });
    return closeoutResult({ required, declared, packetId, manifestPath, diagnostics });
  }

  const absoluteManifestPath = resolveInside(repoRoot, manifestPath);
  if (!fs.existsSync(absoluteManifestPath)) {
    diagnostics.push({
      field: "Packet artifact lifecycle",
      code: "packet_artifact_lifecycle_manifest_missing",
      message: `Declared packet artifact lifecycle closeout requires ${manifestPath}. Run npm run harness:packet-artifact-init -- --packet ${normalizedPacketPath ?? "<packet>"} --work-item ${packetId} --apply before closeout.`
    });
    return closeoutResult({ required, declared, packetId, manifestPath, diagnostics });
  }

  if (!/packet_artifact_lifecycle\s*:\s*declared/i.test(manifestContent)) {
    diagnostics.push({
      field: "Packet artifact lifecycle",
      code: "packet_artifact_lifecycle_declaration_missing",
      message: `${manifestPath} must record packet_artifact_lifecycle: declared.`
    });
  }

  const missingFields = REQUIRED_PACKET_MANIFEST_FIELDS.filter((field) => !manifestHasField(manifestContent, field));
  if (missingFields.length > 0) {
    diagnostics.push({
      field: "Packet manifest row fields",
      code: "packet_artifact_lifecycle_required_row_field_missing",
      message: `${manifestPath} is missing required replay row field(s): ${missingFields.join(", ")}.`
    });
  }

  const manifestRows = parseManifestRows(manifestContent);
  diagnostics.push(...evaluatePhaseReplayEdges({ manifestPath, rows: manifestRows }));
  diagnostics.push(...evaluateCompatibilityPointers({ repoRoot, manifestPath, rows: manifestRows }));
  diagnostics.push(...evaluateMigrationApprovalRefs({ manifestPath, rows: manifestRows }));
  diagnostics.push(...evaluatePmoAuthorityMisuse({ manifestPath, rows: manifestRows }));
  diagnostics.push(...evaluateDuplicateActiveArtifacts({ manifestPath, rows: manifestRows }));
  diagnostics.push(...evaluateDryRunWrites({ manifestPath, rows: manifestRows }));

  if (normalizedPacketPath && !manifestMentionsPath(manifestContent, normalizedPacketPath)) {
    diagnostics.push({
      field: "Canonical packet path",
      code: "packet_artifact_lifecycle_canonical_path_conflict",
      message: `${manifestPath} must link the first-wave canonical packet path ${normalizedPacketPath}.`
    });
  }

  const missingPhaseDirectories = PACKET_ARTIFACT_PHASES.filter((phase) => {
    const absolutePhasePath = resolveInside(repoRoot, `reference/packets/${packetId}/${phase}`);
    return !fs.existsSync(absolutePhasePath) || !fs.statSync(absolutePhasePath).isDirectory();
  });
  if (missingPhaseDirectories.length > 0) {
    diagnostics.push({
      field: "Packet lifecycle folders",
      code: "packet_artifact_lifecycle_phase_directory_missing",
      message: `${manifestPath} closeout requires lifecycle folder(s): ${missingPhaseDirectories.join(", ")}.`
    });
  }

  const uncatalogedRoleReports = findUncatalogedRoleReports({ repoRoot, packetId, manifestContent });
  if (uncatalogedRoleReports.length > 0) {
    diagnostics.push({
      field: "Packet artifact lifecycle",
      code: "packet_artifact_lifecycle_role_folder_only_output",
      message: `Declared lifecycle packet has legacy role/report artifact(s) not linked from the manifest: ${uncatalogedRoleReports.join(", ")}.`
    });
  }

  return closeoutResult({ required, declared, packetId, manifestPath, diagnostics });
}

function renderPacketManifest({ repoRoot, packetId, canonicalPacketPath }) {
  const now = new Date().toISOString();
  const rows = [
    buildManifestRow({
      artifactId: "packet-canonical",
      artifactPath: canonicalPacketPath,
      phase: "00_packet",
      status: "active",
      retentionReason: "decision_trace",
      owner: "Planner",
      authorityType: "governance_truth",
      canonicalRole: "canonical",
      sourceRefs: [canonicalPacketPath],
      decisionRefs: [canonicalPacketPath],
      closeoutRefs: [canonicalPacketPath],
      citedBy: [canonicalPacketPath],
      closeoutRelevance: "required",
      updatedAt: now
    }),
    buildManifestRow({
      artifactId: "artifact-sync-report",
      artifactPath: `reference/packets/${packetId}/07_closeout/artifact-sync.md`,
      phase: "07_closeout",
      status: fs.existsSync(resolveInside(repoRoot, `reference/packets/${packetId}/07_closeout/artifact-sync.md`)) ? "active" : "interim",
      retentionReason: "replay",
      owner: "Runtime",
      authorityType: "packet_evidence",
      canonicalRole: "generated_summary",
      sourceRefs: [canonicalPacketPath],
      decisionRefs: [canonicalPacketPath],
      closeoutRefs: [`reference/packets/${packetId}/07_closeout/artifact-sync.md`],
      citedBy: [canonicalPacketPath],
      closeoutRelevance: "supporting",
      updatedAt: now
    }),
    ...PACKET_ARTIFACT_PHASES.filter((phase) => phase !== "00_packet").map((phase) => buildManifestRow({
      artifactId: `${phase}-placeholder`,
      artifactPath: `reference/packets/${packetId}/${phase}/README.md`,
      phase,
      status: "interim",
      retentionReason: "replay",
      owner: phaseOwner(phase),
      authorityType: "packet_evidence",
      canonicalRole: "canonical",
      sourceRefs: [canonicalPacketPath],
      decisionRefs: [canonicalPacketPath],
      closeoutRefs: ["none"],
      citedBy: ["none"],
      closeoutRelevance: "not-needed",
      updatedAt: now
    }))
  ];

  return [
    `# ${packetId} Packet Manifest`,
    "",
    "packet_artifact_lifecycle: declared",
    `canonical_packet_path: ${canonicalPacketPath}`,
    "manifest_schema: standard-harness-packet-artifact-lifecycle/v1",
    "",
    "## Packet Artifact Rows",
    "",
    rows.join("\n\n"),
    "",
    "## Planning Sync",
    "",
    "- PMO documents remain linked operating aids and do not become packet approval authority.",
    "- Generated summaries remain generated read models and are not edited manually.",
    ""
  ].join("\n");
}

function renderPhaseReadme({ packetId, phase }) {
  return [
    `# ${packetId} ${phase}`,
    "",
    "This packet lifecycle folder is the canonical location for artifacts in this phase.",
    "",
    "- Empty state: no artifact has been recorded for this phase yet.",
    "- Do not place new packet artifacts in legacy role-based report folders.",
    "- Update `PACKET_MANIFEST.md` when adding, superseding, or archiving an artifact.",
    ""
  ].join("\n");
}

function buildManifestRow({
  artifactId,
  artifactPath,
  phase,
  status,
  retentionReason,
  owner,
  authorityType,
  canonicalRole,
  sourceRefs = ["none"],
  decisionRefs = ["none"],
  implementationRefs = ["none"],
  testRefs = ["none"],
  reviewRefs = ["none"],
  securityRefs = ["none"],
  closeoutRefs = ["none"],
  sourceOrSupersededBy = "none",
  citedBy = ["none"],
  closeoutRelevance,
  updatedAt,
  extraFields = []
}) {
  return [
    `- artifact_id: ${artifactId}`,
    `- path: ${artifactPath}`,
    `- phase: ${phase}`,
    `- status: ${status}`,
    `- retention_reason: ${retentionReason}`,
    `- owner: ${owner}`,
    `- authority_type: ${authorityType}`,
    `- canonical_role: ${canonicalRole}`,
    `- source_refs: [${sourceRefs.join(", ")}]`,
    `- decision_refs: [${decisionRefs.join(", ")}]`,
    `- implementation_refs: [${implementationRefs.join(", ")}]`,
    `- test_refs: [${testRefs.join(", ")}]`,
    `- review_refs: [${reviewRefs.join(", ")}]`,
    `- security_refs: [${securityRefs.join(", ")}]`,
    `- closeout_refs: [${closeoutRefs.join(", ")}]`,
    `- source_or_superseded_by: ${sourceOrSupersededBy}`,
    `- cited_by: [${citedBy.join(", ")}]`,
    "- created_or_updated_by: packet-artifact-init",
    `- created_or_updated_at: ${updatedAt}`,
    `- closeout_relevance: ${closeoutRelevance}`,
    ...extraFields.map(([field, value]) => `- ${field}: ${value}`)
  ].join("\n");
}

function phaseOwner(phase) {
  if (/implementation/.test(phase)) return "Developer";
  if (/testing/.test(phase)) return "Tester";
  if (/review/.test(phase)) return "Reviewer";
  if (/security/.test(phase)) return "Security";
  if (/closeout|planning|design/.test(phase)) return "Planner";
  return "Runtime";
}

function findUncatalogedRoleReports({ repoRoot, packetId, manifestContent }) {
  // Legacy roots are checked only as a migration guard. New generation targets
  // packet-local phase folders and must not create these report roots.
  const roots = [
    "reference/reports/developer",
    "reference/reports/tester",
    "reference/reports/reviewer",
    "reference/reports/security",
    "reference/reports/artifact-sync"
  ];
  const uncataloged = [];
  for (const root of roots) {
    const reportPath = `${root}/${packetId}.md`;
    if (fs.existsSync(resolveInside(repoRoot, reportPath)) && !manifestMentionsPath(manifestContent, reportPath)) {
      uncataloged.push(reportPath);
    }
  }
  return uncataloged;
}

function isLifecycleDeclared(content) {
  const headerValue = normalizePacketHeaderValue(readPacketHeaderValueFromContent(content, "Packet artifact lifecycle") ?? "");
  return DECLARED_LIFECYCLE_VALUES.has(headerValue) || /packet_artifact_lifecycle\s*:\s*declared/i.test(content);
}

function closeoutResult({ required, declared, packetId, manifestPath, diagnostics }) {
  return {
    ok: diagnostics.length === 0,
    required,
    declared,
    packetId,
    manifestPath,
    diagnostics,
    blocking: diagnostics.length > 0
  };
}

function manifestHasField(content, field) {
  return new RegExp(`(^|\\n)\\s*-?\\s*${escapeRegExp(field)}\\s*:`, "i").test(content);
}

function manifestMentionsPath(content, targetPath) {
  const normalizedTarget = normalizeRelativePath(targetPath);
  const normalizedContent = String(content ?? "").replace(/\\/g, "/");
  return normalizedContent.includes(normalizedTarget);
}

function parseManifestRows(content) {
  const rows = [];
  let current = null;
  for (const rawLine of String(content ?? "").split(/\r?\n/)) {
    const match = rawLine.trim().match(/^-\s*([^:]+):\s*(.*)$/);
    if (!match) {
      continue;
    }
    const field = match[1].trim();
    const value = match[2].trim();
    if (field === "artifact_id") {
      if (current) {
        rows.push(current);
      }
      current = {};
    }
    if (current) {
      current[field] = value;
    }
  }
  if (current) {
    rows.push(current);
  }
  return rows;
}

function evaluatePhaseReplayEdges({ manifestPath, rows }) {
  const diagnostics = [];
  for (const row of rows) {
    if (!isCloseoutRelevantActiveRow(row)) {
      continue;
    }
    const phase = normalizeScalar(row.phase);
    const artifact = row.artifact_id ?? row.path ?? "unknown artifact";
    const missing = [];
    if (phase === "00_packet" || phase === "01_planning") {
      if (!hasReplayRef(row, "source_refs")) missing.push("source_refs");
      if (!hasReplayRef(row, "decision_refs")) missing.push("decision_refs");
    }
    if (phase === "03_implementation") {
      if (!hasReplayRef(row, "source_refs") && !hasReplayRef(row, "decision_refs")) missing.push("source_refs or decision_refs");
      if (!hasReplayRef(row, "implementation_refs")) missing.push("implementation_refs");
    }
    if (phase === "04_testing") {
      if (!hasReplayRef(row, "implementation_refs")) missing.push("implementation_refs");
      if (!hasReplayRef(row, "test_refs")) missing.push("test_refs");
    }
    if (phase === "05_review") {
      if (!hasReplayRef(row, "test_refs")) missing.push("test_refs");
      if (!hasReplayRef(row, "review_refs")) missing.push("review_refs");
    }
    if (phase === "06_security") {
      if (!hasReplayRef(row, "security_refs")) missing.push("security_refs");
    }
    if (phase === "07_closeout") {
      if (!hasReplayRef(row, "review_refs")) missing.push("review_refs");
      if (!hasReplayRef(row, "closeout_refs")) missing.push("closeout_refs");
    }
    if (missing.length > 0) {
      diagnostics.push({
        field: "Packet manifest replay edges",
        code: "packet_artifact_lifecycle_phase_replay_edge_missing",
        message: `${manifestPath} row ${artifact} (${phase}) is missing required replay edge(s): ${missing.join(", ")}.`
      });
    }
  }
  return diagnostics;
}

function evaluateCompatibilityPointers({ repoRoot, manifestPath, rows }) {
  const diagnostics = [];
  for (const row of rows) {
    if (!isCloseoutRelevantActiveRow(row) || normalizeScalar(row.canonical_role) !== "compatibility_pointer") {
      continue;
    }
    const artifact = row.artifact_id ?? row.path ?? "unknown artifact";
    const missing = REQUIRED_COMPATIBILITY_POINTER_FIELDS.filter((field) => !hasScalarValue(row[field]));
    if (missing.length > 0) {
      diagnostics.push({
        field: "Compatibility pointer",
        code: "packet_artifact_lifecycle_compatibility_pointer_stale",
        message: `${manifestPath} compatibility pointer row ${artifact} is missing pointer field(s): ${missing.join(", ")}.`
      });
      continue;
    }
    for (const field of ["canonical_target", "legacy_path"]) {
      const target = normalizeManifestPathValue(row[field]);
      if (target && !fs.existsSync(resolveInside(repoRoot, target))) {
        diagnostics.push({
          field: "Compatibility pointer",
          code: "packet_artifact_lifecycle_compatibility_pointer_stale",
          message: `${manifestPath} compatibility pointer row ${artifact} has missing ${field}: ${target}.`
        });
      }
    }
  }
  return diagnostics;
}

function evaluateMigrationApprovalRefs({ manifestPath, rows }) {
  const diagnostics = [];
  for (const row of rows) {
    if (normalizeScalar(row.approval_state) !== "approved-to-apply") {
      continue;
    }
    const artifact = row.artifact_id ?? row.path ?? "unknown artifact";
    const missing = REQUIRED_MIGRATION_APPROVAL_FIELDS.filter((field) => !hasScalarValue(row[field]));
    if (missing.length > 0) {
      diagnostics.push({
        field: "Migration approval references",
        code: "packet_artifact_lifecycle_unapproved_migration_apply",
        message: `${manifestPath} row ${artifact} cannot be approved-to-apply without approval reference field(s): ${missing.join(", ")}.`
      });
    }
  }
  return diagnostics;
}

function evaluatePmoAuthorityMisuse({ manifestPath, rows }) {
  const diagnostics = [];
  for (const row of rows) {
    if (!isCloseoutRelevantActiveRow(row)) {
      continue;
    }
    const artifactPath = normalizeManifestPathValue(row.path);
    if (!artifactPath?.startsWith("reference/pmo/")) {
      continue;
    }
    const authorityType = normalizeScalar(row.authority_type);
    if (["governance_truth", "approval_authority", "approval", "packet_authority"].includes(authorityType)) {
      const artifact = row.artifact_id ?? row.path ?? "unknown artifact";
      diagnostics.push({
        field: "PMO authority boundary",
        code: "packet_artifact_lifecycle_pmo_authority_misuse",
        message: `${manifestPath} row ${artifact} places PMO material under approval/governance authority. PMO artifacts are operating aids and must not become packet approval authority.`
      });
    }
  }
  return diagnostics;
}

function evaluateDuplicateActiveArtifacts({ manifestPath, rows }) {
  const diagnostics = [];
  const seenByPath = new Map();
  for (const row of rows) {
    if (!isCloseoutRelevantActiveRow(row)) {
      continue;
    }
    const artifactPath = normalizeManifestPathValue(row.path);
    if (!artifactPath) {
      continue;
    }
    if (seenByPath.has(artifactPath)) {
      diagnostics.push({
        field: "Packet manifest active artifact uniqueness",
        code: "packet_artifact_lifecycle_duplicate_active_artifact",
        message: `${manifestPath} contains duplicate active closeout-relevant rows for ${artifactPath}: ${seenByPath.get(artifactPath)} and ${row.artifact_id ?? "unknown artifact"}. Supersede one row or mark it not-needed.`
      });
      continue;
    }
    seenByPath.set(artifactPath, row.artifact_id ?? "unknown artifact");
  }
  return diagnostics;
}

function evaluateDryRunWrites({ manifestPath, rows }) {
  const diagnostics = [];
  for (const row of rows) {
    if (!isCloseoutRelevantActiveRow(row)) {
      continue;
    }
    const writeMode = normalizeScalar(row.write_mode ?? row.generation_mode ?? row.apply_mode);
    const artifact = row.artifact_id ?? row.path ?? "unknown artifact";
    const markerText = [row.path, row.created_or_updated_by, row.source_or_superseded_by].map((value) => String(value ?? "")).join(" ");
    if (writeMode === "dry-run" || /\bdry[-_ ]run\b/i.test(markerText)) {
      diagnostics.push({
        field: "Dry-run artifact boundary",
        code: "packet_artifact_lifecycle_dry_run_write",
        message: `${manifestPath} row ${artifact} is closeout-relevant active output but is marked as dry-run material. Dry-run artifacts may be evidence only and must not be promoted as active packet output.`
      });
    }
  }
  return diagnostics;
}

function isCloseoutRelevantActiveRow(row) {
  const status = normalizeScalar(row.status);
  const relevance = normalizeScalar(row.closeout_relevance);
  return status === "active" && relevance !== "not-needed";
}

function hasReplayRef(row, field) {
  return normalizeListValue(row[field]).some((item) => item && item !== "none" && item !== "not-needed");
}

function hasScalarValue(value) {
  const normalized = normalizeScalar(value);
  return Boolean(normalized) && normalized !== "none" && normalized !== "not-needed";
}

function normalizeListValue(value) {
  return String(value ?? "")
    .replace(/^\[/, "")
    .replace(/\]$/, "")
    .split(",")
    .map((item) => normalizeScalar(item))
    .filter(Boolean);
}

function normalizeScalar(value) {
  return String(value ?? "")
    .replace(/^`|`$/g, "")
    .trim()
    .toLowerCase();
}

function normalizeManifestPathValue(value) {
  const raw = String(value ?? "").trim();
  if (!raw || /^none$/i.test(raw) || /^not-needed$/i.test(raw)) {
    return null;
  }
  return normalizeRelativePath(raw.replace(/^`|`$/g, ""));
}

function resolvePacketId({ explicitWorkItemId = null, packetPath = null, content = "" } = {}) {
  const explicit = cleanPacketId(explicitWorkItemId);
  if (explicit) {
    return explicit;
  }
  const header = cleanPacketId(readPacketHeaderValueFromContent(content, "Work item"));
  if (header) {
    return header;
  }
  if (packetPath) {
    return cleanPacketId(path.basename(packetPath, path.extname(packetPath)));
  }
  return null;
}

function resolvePacketInputPath({ repoRoot, packetPath, workItemId = null }) {
  const directPath = normalizeRelativePath(packetPath);
  if (!directPath) {
    return null;
  }
  if (fs.existsSync(resolveInside(repoRoot, directPath))) {
    return directPath;
  }
  const packetId = cleanPacketId(workItemId) ?? cleanPacketId(path.basename(directPath, path.extname(directPath)));
  if (!packetId) {
    return null;
  }
  const canonicalPath = canonicalPacketMarkdownPathForId(packetId);
  return fs.existsSync(resolveInside(repoRoot, canonicalPath)) ? canonicalPath : null;
}

function cleanPacketId(value) {
  const normalized = String(value ?? "")
    .replace(/[`*]/g, "")
    .trim();
  if (!normalized) {
    return null;
  }
  const match = normalized.match(/[A-Za-z]+-[A-Za-z0-9]+-\d+[A-Za-z0-9._-]*/);
  const candidate = match ? match[0] : normalized;
  const safe = candidate.replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^_+|_+$/g, "");
  return safe || null;
}

function normalizeRelativePath(value) {
  if (!value) {
    return null;
  }
  return String(value).replace(/\\/g, "/").replace(/^\.\//, "");
}

function resolveInside(repoRoot, relativePath) {
  const root = path.resolve(repoRoot);
  const target = path.resolve(root, normalizeRelativePath(relativePath));
  if (target !== root && !target.startsWith(`${root}${path.sep}`)) {
    throw new Error(`Path escapes repo root: ${relativePath}`);
  }
  return target;
}

function parseArgs(args) {
  const options = { positionals: [] };
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    if (!arg.startsWith("--")) {
      options.positionals.push(arg);
      continue;
    }
    const key = arg.slice(2).replace(/-([a-z])/g, (_, char) => char.toUpperCase());
    const next = args[index + 1];
    if (next == null || next.startsWith("--")) {
      options[key] = true;
      continue;
    }
    options[key] = next;
    index += 1;
  }
  return options;
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
