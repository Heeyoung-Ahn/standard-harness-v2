import { pathToFileURL } from "node:url";

import { createCommandTable } from "./cli-dispatch-table.js";
import { renderUsage } from "./cli-help.js";
import { formatResult } from "./cli-result-formatters.js";
import { DEFAULT_DB_PATH } from "./operating-state-store.js";

export function main({
  argv = process.argv,
  env = process.env,
  cwd = process.cwd(),
  stdout = process.stdout,
  stderr = process.stderr,
  entrypointPath = ".harness/runtime/state/harness-cli.js"
} = {}) {
  const command = argv[2];
  const repoRoot = env.REPO_ROOT ?? cwd;
  const outputDir = repoRoot;
  const dbPath = env.HARNESS_DB_PATH ?? DEFAULT_DB_PATH;
  const commands = createCommandTable({ repoRoot, outputDir, dbPath, args: argv.slice(3) });

  if (!command || !commands[command]) {
    stderr.write(renderUsage({ entrypointPath }));
    return 1;
  }

  const result = commands[command]();
  stdout.write(`${formatResult(result)}\n`);
  return result.ok === false || result.cutoverReady === false ? 1 : 0;
}

const invokedPath = process.argv[1] ? pathToFileURL(process.argv[1]).href : null;
if (invokedPath === import.meta.url) {
  process.exit(main());
}

export { formatResult } from "./cli-result-formatters.js";
