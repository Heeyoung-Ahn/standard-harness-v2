import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

import {
  AUTHORITY_DENIAL,
  classifyPromotionPath,
  normalizePromotionPath
} from "./promotion-boundary.js";

const PLACEHOLDER_DIRS = [".agents/runtime", ".agents/artifacts"];
const STARTER_REQUIRED_REFERENCE_ARTIFACTS = [
  "reference/artifacts/PROJECT_STARTER_DOC_PACK.md",
  "reference/artifacts/AUTHORITATIVE_SOURCE_WAVE_LEDGER.md",
  "reference/artifacts/DEPLOYMENT_PLAN.md",
  "reference/artifacts/PACKET_EXIT_QUALITY_GATE.md",
  "reference/artifacts/REPOSITORY_LAYOUT_OWNERSHIP.md",
  "reference/artifacts/LEGACY_SYSTEM_INTAKE.md",
  "reference/artifacts/MIGRATION_RECONCILIATION_PLAN.md",
  "reference/artifacts/DJANGO_BACKOFFICE_CONVENTIONS.md",
  "reference/artifacts/WORKFLOW_STATE_MACHINE.md",
  "reference/artifacts/APPROVAL_RULE_MATRIX.md",
  "reference/artifacts/ROLE_PERMISSION_MATRIX.md",
  "reference/artifacts/AUDIT_EVENT_SPEC.md",
  "reference/artifacts/EXCEPTION_REOPEN_ROLLBACK_RULES.md",
  "reference/artifacts/LIGHTWEIGHT_APP_BASELINE.md",
  "reference/artifacts/ANDROID_APP_BASELINE.md",
  "reference/artifacts/NODE_FRONTEND_APP_BASELINE.md",
  "reference/artifacts/BI_DATA_SOURCE_INVENTORY.md",
  "reference/artifacts/BI_METRIC_CATALOG.md",
  "reference/artifacts/BI_SEMANTIC_MODEL.md",
  "reference/artifacts/BI_REFRESH_AND_LINEAGE_PLAN.md",
  "reference/artifacts/BI_DASHBOARD_GOVERNANCE.md",
  "reference/artifacts/PRODUCT_UX_ARCHETYPE.md",
  "reference/artifacts/VERIFICATION_SCENARIO_TEMPLATE.md"
];
const PRESERVE_COPIED_REFERENCE_ARTIFACTS = new Set([
  "reference/artifacts/AUTHORITATIVE_SOURCE_WAVE_LEDGER.md",
  "reference/artifacts/PACKET_EXIT_QUALITY_GATE.md"
]);
const STARTER_PLACEHOLDER_FILES = [
  {
    path: ".agents/artifacts/CURRENT_STATE.md",
    content: `# Current State

## Snapshot
- Current Stage: not started
- Current Focus: run starter initialization and close the kickoff baseline before any implementation packet opens

## Next Recommended Agent
- Planner
`
  },
  {
    path: ".agents/artifacts/TASK_LIST.md",
    content: `# Task List

## Active Tasks
| Task ID | Title | Scope | Owner | Status | Priority | Depends On | Verification |
|---|---|---|---|---|---|---|---|
| BOOT-00 | Initialize copied starter | starter bootstrap | project operator | starter_pending | P0 | \`INIT_STANDARD_HARNESS.cmd\` or \`npm run harness:init\` | generated docs and validation guidance |
- Run \`INIT_STANDARD_HARNESS.cmd\` or \`npm run harness:init\` before real work begins.
`
  },
  {
    path: ".agents/artifacts/REQUIREMENTS.md",
    content: `# Requirements

## Summary
Starter placeholder. Replace during \`harness:init\`. Keep requirements tied to explicit user goals, approval boundary, open questions, and deferred items.

### 사용자 목표
- pending

### 운영 목표
- pending

### 승인 목표
- pending

## Active Profile Selection
- none yet

## Open Questions
- pending kickoff interview

## Deferred Items
- none yet

## Starter Health Customization Boundary

Preserve this section when customizing starter docs.

- Safe to customize: product-only goals, acceptance criteria, domain terms, and packet-specific facts.
- Preserve reusable starter-health guidance so a copied starter still explains approval boundaries, open questions, deferred items, and packet decision records.
`
  },
  {
    path: ".agents/artifacts/ARCHITECTURE_GUIDE.md",
    content: `# Architecture Guide

## Purpose
Record durable architecture context after requirements are frozen.

## Authoring Flow
- Replace this starter placeholder after requirements freeze.

## Architecture Memory Boundary
Use this as reusable starter-health guidance for component names, module boundaries, data flow, integrations, and constraints.
Do not use it as root maintainer history or current execution truth.

## Starter Health Customization Boundary

Preserve this section when customizing starter docs.

- Safe to customize: product-only architecture decisions after packet approval.
- Preserve reusable starter-health guidance and separate project architecture from root maintainer history and packet decision records.
`
  },
  {
    path: ".agents/artifacts/UI_DESIGN.md",
    content: `# UI Design

## Purpose
Starter placeholder. Replace after requirements and rough UX direction are approved.

## Scope
- No product UI is approved yet.
- Record navigation, screen structure, interaction states, accessibility, and visual/content contract when a packet requires UI evidence.
`
  },
  {
    path: ".agents/artifacts/IMPLEMENTATION_PLAN.md",
    content: `# Implementation Plan

## Current Plan Summary
- Starter initialization pending.

## Optional Profile Activation
- Selected profiles at bootstrap: none.

## Current Iteration
- Starter initialization pending.

## Dependency Order And Blocking Conditions
- Do not start implementation before packet scope, approval boundary, and verification expectations are recorded.

## Root / Standard-Template Sync Requirements
- Preserve generated-doc immutability, packet-before-code, Active Context derived authority, and explicit root maintainer review before any template sync.

## Long-Memory Boundary
- This is not root maintainer history; keep root maintainer history separate from product implementation notes.

## Starter Health Customization Boundary

Preserve this section when customizing starter docs.

- Safe to customize: product-only task order and packet-specific dependencies.
- Preserve reusable starter-health guidance for approval, validation, generated-state boundaries, and packet decision records.

## Operator Next Action
- Run \`npm run harness:init\`.
`
  },
  {
    path: ".agents/artifacts/ACTIVE_PROFILES.md",
    content: `# Active Profiles

## Active Profile Table
| Profile | Reason | Evidence status | Activated by | Activated at | Applies to packets |
|---|---|---|---|---|---|
| - | None currently active | not-needed | - | - | - |
`
  },
  {
    path: ".agents/artifacts/PROJECT_PROGRESS.md",
    content: `# Project Progress

## Summary
Starter initialization pending.
`
  },
  {
    path: ".agents/artifacts/PROJECT_HISTORY.md",
    content: `# Project History

## Long-Memory Boundary
- Use this long history log for project-specific decisions after initialization.
- Do not copy root maintainer history into product projects.
- Keep root maintainer notes in the source harness maintenance packet or release history.
`
  },
  {
    path: ".agents/artifacts/PREVENTIVE_MEMORY.md",
    content: `# Preventive Memory

No project-specific preventive memory has been recorded yet.

## Long-Memory Boundary
- Record project-specific repeated mistakes only after they are observed.
- Do not copy root maintainer history or root maintainer maintenance notes into product preventive memory.
`
  },
  {
    path: ".agents/artifacts/SYSTEM_CONTEXT.md",
    content: `# System Context

This artifact is conditional canonical for long-term system boundary only when it is explicitly maintained and cited.

Do not use it as current execution truth.

## Reusable Harness Boundary Notes

### Planner Packet Challenge Review
- Planner Packet Challenge Review evidence must identify independent review, source refs, findings disposition, and whether any finding was self-approved or resolved by self-approval.
- Reviewer may hold closeout when findings disposition is missing or challenge evidence is self-approved.

### Production-Forbidden Prototype Lane
- Prototype outputs are learning surfaces, not production implementation sources.
- Production implementation must be re-approved under Modeling Impact and product packet scope before code is merged or reused.
- Reviewer closeout may hold when a packet permits direct copy/merge into production.

### Shared Skill Marketplace Contract
- \`reference/artifacts/SKILL_MARKETPLACE_CATALOG.md\` is the compact discovery surface for reusable skills.
- Default context, default role briefs, and Planner read sets must not load all skill bodies.
- Load the selected skill body or selected active skills only when an active task, workflow, role, or user request triggers them.
- Skill output does not override packet authority, Ready For Code approval, Tester verification, Reviewer closeout, Planner closeout, or product acceptance.
- \`conflict_resolver\` remains minimum-contract-deferred until \`OPS-SKILL-01A_CONFLICT_RESOLVER_MINIMUM_CONTRACT\` or equivalent approval exists.
`
  },
  {
    path: ".agents/runtime/DOC_ROUTE.json",
    content: `{
  "schemaVersion": "standard-harness-v2.3-doc-route/v1",
  "lane": "starter-bootstrap",
  "phase": "pre-init",
  "read": [
    ".agents/ssot/AI_OPERATING_CONTRACT.md",
    ".agents/ssot/PACKET_LANE_RULES.md"
  ],
  "do_not_read": [
    "START_HERE.md",
    "reference/manuals/human/**"
  ]
}
`
  },
  {
    path: "reference/pmo/planning/PLN-00_DEEP_INTERVIEW.md",
    content: `# PLN-00 Deep Interview

Starter kickoff interview placeholder. Replace with project-specific answers during planning.
`
  },
  {
    path: "reference/pmo/planning/PLN-01_REQUIREMENTS_FREEZE.md",
    content: `# PLN-01 Requirements Freeze

Starter requirements freeze placeholder. Replace after PLN-00 discovery is closed.
`
  },
  {
    path: "reference/packets/README.md",
    content: `# Packet Artifacts

Use packet folders for fresh-start validation reports, friction notes, implementation summaries, and review evidence.

- Keep canonical current state in \`.agents/artifacts/*\`, generated state in \`.agents/runtime/*\`, and validation output in \`.agents/artifacts/VALIDATION_REPORT.*\`.
- Put packet-specific artifacts under \`reference/packets/<packet-id>/<phase>/\`.
- Do not treat an artifact as product acceptance evidence unless the active packet manifest cites it under Tester or Reviewer evidence.

## E2E Effort / Token Reporting Contract

- \`Telemetry status: measured | estimated | unavailable\`
- \`measured\`: use only when the report cites a concrete runtime, tool, log, trace, or accounting source for the value.
- \`estimated\`: use when the report infers the value; include the estimation method and do not present it as exact telemetry.
- \`unavailable\`: use when telemetry is absent; include the unavailable rationale and the non-metric evidence used instead.
- \`Measured product implementation tokens\`: record only measured product-work tokens with an evidence source.
- \`Measured harness compliance tokens\`: record only measured harness/planning/validation tokens with an evidence source.
- \`Estimated product / harness split\`: record the estimated split only with an estimation method.
- \`Estimation method\`: describe the sampling, transcript review, time-box, or other method used for an estimate.
- \`Evidence source\`: cite the concrete source for measured values or the source material used for estimates.
- \`Unavailable rationale\`: explain why token/cost telemetry is not available.
- Do not invent exact token/cost metrics when runtime telemetry does not expose them.
- Reviewer holds reports that present exact token/cost numbers without measured evidence.

No reusable fresh-start E2E packet evidence template is currently shipped.

## Sandbox / Pilot Evidence Bundle

- \`Production readiness\`: use \`not-claimed\`.
- \`Payload separation\`: confirm reusable starter payloads did not receive pilot-only files.
- Pilot evidence does not weaken strict/high production gates.
- Harness validation proves harness structure and state consistency; product acceptance still needs product-specific Tester/Reviewer evidence in the active packet.
`
  },
  {
    path: "reference/archive/legacy-reference-layout/reports/reference_reports_README.md",
    content: `# Fresh-Start Validation Reports

This directory may hold fresh-start validation reports and smoke notes.

- Reports are not canonical state.
- \`VALIDATION_REPORT\` output is harness structural/state evidence, not product acceptance evidence.

## E2E Effort / Token Reporting Contract

- \`Telemetry status: measured | estimated | unavailable\`
- \`measured\`: use only when the report cites a concrete runtime, tool, log, trace, or accounting source for the value.
- \`estimated\`: use when the report infers the value; include the estimation method and do not present it as exact telemetry.
- \`unavailable\`: use when telemetry is absent; include the unavailable rationale and the non-metric evidence used instead.
- \`Measured product implementation tokens\`: record only measured product-work tokens with an evidence source.
- \`Measured harness compliance tokens\`: record only measured harness/planning/validation tokens with an evidence source.
- \`Estimated product / harness split\`: record the estimated split only with an estimation method.
- \`Estimation method\`: describe the sampling, transcript review, time-box, or other method used for an estimate.
- \`Evidence source\`: cite the concrete source for measured values or the source material used for estimates.
- \`Unavailable rationale\`: explain why token/cost telemetry is not available.
- Do not invent exact token/cost metrics when runtime telemetry does not expose them.
- Reviewer holds reports that present exact token/cost numbers without measured evidence.

No reusable fresh-start E2E report template is currently shipped.

## Sandbox / Pilot Evidence Bundle

- \`Production readiness\`: use \`not-claimed\`.
- \`Payload separation\`: confirm reusable starter payloads did not receive pilot-only files.
- Pilot evidence does not weaken strict/high production gates.
- Harness validation proves harness structure and state consistency; product acceptance still needs product-specific Tester/Reviewer evidence in the active packet.
`
  },
  ...STARTER_REQUIRED_REFERENCE_ARTIFACTS.map((placeholderPath) => ({
    path: placeholderPath,
    content: starterReferenceArtifactPlaceholder(placeholderPath)
  }))
];

export function runPromoteStarterCommand({ repoRoot = process.cwd(), args = [] } = {}) {
  const options = parsePromotionArgs(args);
  if (!options.to) {
    return failPromotion({
      reason: "Missing required --to target path.",
      nextAction: "Run npm run harness:promote-starter -- --to <new-clean-starter-path>."
    });
  }

  const targetRoot = path.resolve(repoRoot, options.to);
  const sourceRoot = path.resolve(repoRoot);
  const targetSafety = validateTarget({ sourceRoot, targetRoot, force: options.force });
  if (!targetSafety.ok) return targetSafety;

  const plan = buildPromotionPlan({ repoRoot: sourceRoot, targetRoot });
  if (options.dryRun) {
    const report = options.report
      ? writePromotionDryRunReport({ repoRoot: sourceRoot, plan, options })
      : null;
    return {
      ok: true,
      command: "promote-starter",
      dryRun: true,
      sourceRoot,
      targetRoot,
      summary: summarizePlan(plan),
      plan,
      reportPath: report?.markdownPath ?? null,
      reportJsonPath: report?.jsonPath ?? null,
      authority: AUTHORITY_DENIAL,
      nextAction: "Review include/exclude/review lanes, then rerun without --dry-run to export."
    };
  }

  fs.mkdirSync(targetRoot, { recursive: true });
  for (const item of plan.items.filter((entry) => entry.decision === "include")) {
    copyFile(sourceRoot, targetRoot, item.path);
  }
  writeMergedPackageJson({ sourceRoot, targetRoot });
  writePlaceholders({ sourceRoot, targetRoot });
  writeExportProvenance({ sourceRoot, targetRoot, plan });
  const contaminationAudit = auditStarterCandidate({ candidateRoot: targetRoot });
  const freshVerification = options.verify
    ? verifyStarterCandidate({ candidateRoot: targetRoot })
    : buildFreshStarterVerificationPlan({ candidateRoot: targetRoot });

  return {
    ok: contaminationAudit.ok && (!options.verify || freshVerification.ok),
    command: "promote-starter",
    dryRun: false,
    sourceRoot,
    targetRoot,
    summary: summarizePlan(plan),
    contaminationAudit,
    freshVerification,
    writtenFiles: listFiles(targetRoot),
    authority: AUTHORITY_DENIAL,
    nextAction: promotionNextAction({ verify: options.verify, freshVerification })
  };
}

export function buildPromotionPlan({ repoRoot = process.cwd(), targetRoot = null } = {}) {
  const items = [];
  for (const filePath of listFiles(repoRoot)) {
    const classification = classifyPromotionPath(filePath);
    items.push({
      path: filePath,
      decision: classification.decision,
      reason: classification.reason,
      reviewKind: classification.reviewKind ?? null,
      validationKind: classification.validationKind
    });
  }

  items.sort((left, right) => left.path.localeCompare(right.path));
  return {
    sourceRoot: path.resolve(repoRoot),
    targetRoot: targetRoot ? path.resolve(targetRoot) : null,
    items,
    summary: summarizePlan({ items }),
    authority: AUTHORITY_DENIAL
  };
}

export function auditStarterCandidate({ candidateRoot = process.cwd() } = {}) {
  const findings = [];
  for (const filePath of listFiles(candidateRoot)) {
    if (isAllowedCleanPlaceholder(filePath)) continue;
    const classification = classifyPromotionPath(filePath);
    if (classification.decision === "exclude") {
      findings.push(auditFindingForPath(filePath));
    }
  }
  findings.push(...findProductContentLeakage({ candidateRoot }));

  const provenancePath = path.join(candidateRoot, ".harness/promotion/EXPORT_PROVENANCE.json");
  if (!fs.existsSync(provenancePath)) {
    findings.push({
      severity: "hold",
      lane: "provenance",
      path: ".harness/promotion/EXPORT_PROVENANCE.json",
      reason: "Export provenance marker is required before treating a candidate as promotion-generated."
    });
  }

  const summary = summarizeFindings(findings);
  return {
    ok: summary.block === 0 && summary.hold === 0,
    command: "promote-starter",
    auditKind: "starter_contamination_audit",
    decision: summary.block > 0 ? "block" : summary.hold > 0 ? "hold" : summary.warn > 0 ? "warn" : "pass",
    candidateRoot: path.resolve(candidateRoot),
    summary,
    findings,
    authority: AUTHORITY_DENIAL,
    nextAction:
      summary.block > 0
        ? "Remove blocked contamination and rerun promotion export from the source project."
        : summary.hold > 0
          ? "Regenerate the candidate through harness:promote-starter so provenance is available."
          : "Proceed to fresh starter verification."
  };
}

function isAllowedCleanPlaceholder(filePath) {
  const normalized = normalizePromotionPath(filePath);
  return (
    normalized === ".agents/runtime/.gitkeep" ||
    normalized === ".agents/artifacts/.gitkeep" ||
    STARTER_PLACEHOLDER_FILES.some((placeholder) => placeholder.path === normalized)
  );
}

function parsePromotionArgs(args) {
  const options = {
    dryRun: false,
    force: false,
    verify: false,
    report: false,
    to: null,
    workItem: "promotion-dry-run",
    packet: null,
    reportPath: null
  };
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    if (arg === "--dry-run") options.dryRun = true;
    else if (arg === "--force") options.force = true;
    else if (arg === "--verify") options.verify = true;
    else if (arg === "--report") options.report = true;
    else if (arg === "--to") {
      options.to = args[index + 1] ?? null;
      index += 1;
    } else if (arg.startsWith("--to=")) {
      options.to = arg.slice("--to=".length);
    } else if (arg === "--work-item") {
      options.workItem = args[index + 1] ?? options.workItem;
      index += 1;
    } else if (arg.startsWith("--work-item=")) {
      options.workItem = arg.slice("--work-item=".length);
    } else if (arg === "--packet") {
      options.packet = args[index + 1] ?? null;
      index += 1;
    } else if (arg.startsWith("--packet=")) {
      options.packet = arg.slice("--packet=".length);
    } else if (arg === "--report-path") {
      options.reportPath = args[index + 1] ?? null;
      index += 1;
    } else if (arg.startsWith("--report-path=")) {
      options.reportPath = arg.slice("--report-path=".length);
    }
  }
  return options;
}

export function buildFreshStarterVerificationPlan({ candidateRoot = process.cwd() } = {}) {
  return {
    ok: true,
    command: "promote-starter",
    verificationKind: "fresh_starter_verification_plan",
    candidateRoot: path.resolve(candidateRoot),
    decision: "not_run",
    lanes: verificationSteps().map((step) => ({
      lane: step.lane,
      command: step.command,
      status: "not_run",
      validationKind: step.validationKind
    })),
    authority: AUTHORITY_DENIAL,
    nextAction: "Run harness:promote-starter with --verify to execute the fresh starter verification commands."
  };
}

export function verifyStarterCandidate({
  candidateRoot = process.cwd(),
  runCommand = runVerificationCommand
} = {}) {
  const lanes = [];
  for (const step of verificationSteps()) {
    const outcome = runCommand(step, { cwd: candidateRoot });
    const exitCode = Number(outcome.exitCode ?? outcome.status ?? 1);
    const combinedOutput = `${String(outcome.stdout ?? "")}\n${String(outcome.stderr ?? "")}`;
    const expectedHold =
      step.acceptedFailureCode && exitCode !== 0 && combinedOutput.includes(step.acceptedFailureCode);
    const status = exitCode === 0 || expectedHold ? "pass" : "block";
    lanes.push({
      lane: step.lane,
      command: step.command,
      status,
      validationKind: step.validationKind,
      expectedHold,
      exitCode,
      stdout: String(outcome.stdout ?? ""),
      stderr: String(outcome.stderr ?? "")
    });
    if (status === "block") break;
  }

  const blocked = lanes.find((lane) => lane.status === "block");
  return {
    ok: !blocked && lanes.length === verificationSteps().length,
    command: "promote-starter",
    verificationKind: "fresh_starter_verification",
    candidateRoot: path.resolve(candidateRoot),
    decision: blocked ? "block" : "pass",
    lanes,
    authority: AUTHORITY_DENIAL,
    nextAction: blocked
      ? `Fix ${blocked.command} in the exported starter candidate, then rerun fresh starter verification.`
      : "Fresh starter verification evidence is available; this is not product verification or release approval."
  };
}

function verificationSteps() {
  return [
    {
      lane: "reusable_payload",
      command: "npm install",
      validationKind: "dependency_install"
    },
    {
      lane: "reusable_payload",
      command: "npm test",
      validationKind: "payload_tests"
    },
    {
      lane: "reusable_payload",
      command: "npm run harness:payload-boundary",
      validationKind: "clean_payload_boundary"
    },
    {
      lane: "reusable_payload",
      command: "npm run harness:validate",
      validationKind: "starter_pre_init_bootstrap_hold",
      acceptedFailureCode: "starter_bootstrap_pending"
    },
    {
      lane: "initialized_project",
      command:
        'npm run harness:init -- --non-interactive --project-name "Promoted Starter Smoke" --project-slug "promoted-starter-smoke" --user-goal "Verify promoted starter" --ops-goal "Verify harness promotion workflow" --approval-goal "Keep approval boundaries explicit" --profiles none',
      validationKind: "non_interactive_init"
    },
    {
      lane: "initialized_project",
      command: "npm run harness:sync-state",
      validationKind: "generated_state_convergence"
    },
    {
      lane: "initialized_project",
      command: "npm run harness:validate",
      validationKind: "post_init_harness_structural_validation"
    },
    {
      lane: "initialized_project",
      command: "npm run harness:status",
      validationKind: "initialized_project_status"
    }
  ];
}

function runVerificationCommand(step, { cwd }) {
  const tempDir = path.join(path.dirname(cwd), `${path.basename(cwd)}-verify-tmp`);
  fs.mkdirSync(tempDir, { recursive: true });
  const result = spawnSync(step.command, {
    cwd,
    env: { ...process.env, TEMP: tempDir, TMP: tempDir, TMPDIR: tempDir },
    shell: true,
    encoding: "utf8",
    windowsHide: true
  });
  return {
    exitCode: result.status ?? 1,
    stdout: result.stdout ?? "",
    stderr: result.stderr ?? result.error?.message ?? ""
  };
}

function validateTarget({ sourceRoot, targetRoot, force }) {
  if (path.resolve(sourceRoot) === path.resolve(targetRoot)) {
    return failPromotion({
      reason: "Promotion target cannot be the source product project.",
      nextAction: "Choose a separate target directory outside the source project root."
    });
  }

  if (fs.existsSync(targetRoot) && fs.readdirSync(targetRoot).length > 0 && !force) {
    return failPromotion({
      reason: "Promotion target already exists and is not empty.",
      nextAction: "Use a new empty target path or rerun with --force after reviewing the target."
    });
  }

  return { ok: true };
}

function failPromotion({ reason, nextAction }) {
  return {
    ok: false,
    command: "promote-starter",
    reason,
    nextAction,
    authority: AUTHORITY_DENIAL
  };
}

function summarizePlan(plan) {
  const items = plan.items ?? [];
  return {
    include: items.filter((item) => item.decision === "include").length,
    exclude: items.filter((item) => item.decision === "exclude").length,
    review: items.filter((item) => item.decision === "review").length
  };
}

function promotionNextAction({ verify, freshVerification }) {
  if (!verify) {
    return "Run with --verify, or manually run npm install, npm test, npm run harness:payload-boundary, pre-init validate, non-interactive init, sync-state, post-init validate, and status in the exported starter candidate.";
  }
  if (freshVerification?.ok) {
    return "Review promotion output and authority boundary; fresh starter verification evidence is available.";
  }
  return freshVerification?.nextAction ?? "Fix fresh starter verification findings, then rerun with --verify.";
}

function writePromotionDryRunReport({ repoRoot, plan, options }) {
  const workItemId = sanitizeReportName(options.workItem ?? "promotion-dry-run");
  const markdownPath = path.resolve(
    repoRoot,
    options.reportPath ?? `reference/packets/${workItemId}/08_evidence/operating-rollout.md`
  );
  const jsonPath = markdownPath.replace(/\.md$/i, ".json");
  const report = buildPromotionDryRunReport({ plan, options, markdownPath, jsonPath });
  fs.mkdirSync(path.dirname(markdownPath), { recursive: true });
  fs.writeFileSync(markdownPath, renderPromotionDryRunMarkdown(report), "utf8");
  fs.writeFileSync(jsonPath, `${JSON.stringify(report, null, 2)}\n`, "utf8");
  return { markdownPath: toRepoRelative(repoRoot, markdownPath), jsonPath: toRepoRelative(repoRoot, jsonPath) };
}

function buildPromotionDryRunReport({ plan, options, markdownPath, jsonPath }) {
  const lanes = {
    include: sampleLane(plan.items, "include"),
    exclude: sampleLane(plan.items, "exclude"),
    review: sampleLane(plan.items, "review")
  };
  return {
    schemaVersion: "standard-harness-operating-rollout/v1",
    generatedAt: new Date().toISOString(),
    command: "promote-starter",
    mode: "dry-run",
    workItemId: options.workItem ?? "promotion-dry-run",
    packetPath: options.packet ?? null,
    sourceRoot: plan.sourceRoot,
    targetRoot: plan.targetRoot,
    reportPath: normalizePromotionPath(path.relative(plan.sourceRoot, markdownPath)),
    reportJsonPath: normalizePromotionPath(path.relative(plan.sourceRoot, jsonPath)),
    summary: summarizePlan(plan),
    lanes,
    blocked: [],
    authority: AUTHORITY_DENIAL,
    nextAction:
      "Review include/exclude/review lanes and request explicit user approval before any root, clean starter, or sibling apply."
  };
}

function sampleLane(items = [], decision) {
  return items
    .filter((item) => item.decision === decision)
    .slice(0, 20)
    .map((item) => ({
      path: item.path,
      decision: item.decision,
      reason: item.reason,
      reviewKind: item.reviewKind ?? null,
      ownerAction:
        item.decision === "review"
          ? "manual review required before promotion"
          : item.decision === "exclude"
            ? "do not promote"
            : "eligible for promotion by existing boundary"
    }));
}

function renderPromotionDryRunMarkdown(report) {
  return [
    `# Operating Rollout Dry-Run Report - ${report.workItemId}`,
    "",
    "## Summary",
    "",
    `- Generated at: ${report.generatedAt}`,
    `- Mode: ${report.mode}`,
    `- Work item: ${report.workItemId}`,
    `- Packet: ${report.packetPath ?? "not provided"}`,
    `- Source root: ${report.sourceRoot}`,
    `- Target root: ${report.targetRoot}`,
    `- Include count: ${report.summary.include}`,
    `- Exclude count: ${report.summary.exclude}`,
    `- Review count: ${report.summary.review}`,
    "",
    "## Authority Boundary",
    "",
    "- This report is evidence only.",
    "- It does not grant release approval, publish approval, implementation approval, packet closeout, risk closure, product verification, or residual-risk acceptance.",
    "- It does not approve actual root, clean starter, or sibling-project apply.",
    "",
    renderLane("Include Lane", report.lanes.include),
    renderLane("Exclude Lane", report.lanes.exclude),
    renderLane("Review Lane", report.lanes.review),
    "## Next Action",
    "",
    `- ${report.nextAction}`,
    ""
  ].join("\n");
}

function renderLane(title, rows) {
  return [
    `## ${title}`,
    "",
    "| Path | Decision | Reason | Owner action |",
    "|---|---|---|---|",
    ...(rows.length > 0
      ? rows.map(
          (row) =>
            `| ${escapeMarkdownCell(row.path)} | ${escapeMarkdownCell(row.decision)} | ${escapeMarkdownCell(row.reason)} | ${escapeMarkdownCell(row.ownerAction)} |`
        )
      : ["| - | - | - | - |"]),
    ""
  ].join("\n");
}

function sanitizeReportName(value) {
  return String(value ?? "promotion-dry-run").replace(/[^A-Za-z0-9._-]/g, "-");
}

function toRepoRelative(repoRoot, absolutePath) {
  return normalizePromotionPath(path.relative(repoRoot, absolutePath));
}

function escapeMarkdownCell(value) {
  return String(value ?? "").replaceAll("|", "\\|").replace(/\r?\n/g, " ");
}

function copyFile(sourceRoot, targetRoot, relativePath) {
  const normalized = normalizePromotionPath(relativePath);
  const source = path.join(sourceRoot, normalized);
  const target = path.join(targetRoot, normalized);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.copyFileSync(source, target);
}

function writeMergedPackageJson({ sourceRoot, targetRoot }) {
  const sourcePackagePath = path.join(sourceRoot, "package.json");
  if (!fs.existsSync(sourcePackagePath)) return;

  const sourcePackage = JSON.parse(fs.readFileSync(sourcePackagePath, "utf8"));
  const harnessScripts = Object.fromEntries(
    Object.entries(sourcePackage.scripts ?? {}).filter(
      ([name]) =>
        name === "pretest" ||
        name === "test" ||
        name.startsWith("harness:") ||
        name.startsWith("docs:") ||
        name.startsWith("browser:")
    )
  );
  const starterPackage = {
    name: "standard-harness-clean-starter",
    private: true,
    type: sourcePackage.type ?? "module",
    engines: sourcePackage.engines,
    scripts: harnessScripts,
    version: sourcePackage.version,
    description: "Clean starter candidate exported from a standard-harness product project."
  };
  for (const key of Object.keys(starterPackage)) {
    if (starterPackage[key] === undefined) delete starterPackage[key];
  }
  fs.writeFileSync(path.join(targetRoot, "package.json"), `${JSON.stringify(starterPackage, null, 2)}\n`, "utf8");
}

function writePlaceholders({ sourceRoot, targetRoot }) {
  for (const relativeDir of PLACEHOLDER_DIRS) {
    const dir = path.join(targetRoot, relativeDir);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, ".gitkeep"), "", "utf8");
  }
  for (const placeholder of STARTER_PLACEHOLDER_FILES) {
    const target = path.join(targetRoot, placeholder.path);
    if (PRESERVE_COPIED_REFERENCE_ARTIFACTS.has(placeholder.path) && fs.existsSync(target)) {
      continue;
    }
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, placeholder.content, "utf8");
  }
  writeStarterReadme({ sourceRoot, targetRoot });
  writeGeneratedCommandTaxonomy({ targetRoot });
}

function writeStarterReadme({ sourceRoot, targetRoot }) {
  const sourceReadmePath = path.join(sourceRoot, "README.md");
  const fallback = `# Standard Harness Clean Starter

This repository is a clean reusable standard-harness starter.

See \`START_HERE.md\` and \`reference/manuals/human/HARNESS_MANUAL.md\`.
`;
  const sourceContent = fs.existsSync(sourceReadmePath) ? fs.readFileSync(sourceReadmePath, "utf8") : fallback;
  const content = redactProductContent(sourceContent)
    .replace(/^# .+$/m, "# Standard Harness Clean Starter")
    .replace(/- Project slug: `[^`]+`/g, "- Project slug: `starter-project`");
  fs.writeFileSync(path.join(targetRoot, "README.md"), content, "utf8");
}

function writeGeneratedCommandTaxonomy({ targetRoot }) {
  const packagePath = path.join(targetRoot, "package.json");
  const scripts = fs.existsSync(packagePath) ? Object.keys(JSON.parse(fs.readFileSync(packagePath, "utf8")).scripts ?? {}) : [];
  const groups = [
    "core starter lifecycle",
    "Codex workflow",
    "evidence/review",
    "security/risk gates",
    "learning/operator diagnostics",
    "compatibility namespaces",
    "maintenance/internal"
  ];
  const rowsByGroup = new Map(groups.map((group) => [group, []]));
  for (const script of scripts.sort()) {
    const group = commandTaxonomyGroup(script);
    rowsByGroup.get(group).push({
      script,
      description: commandTaxonomyDescription(script)
    });
  }

  const lines = ["# Standard Harness Command Taxonomy", ""];
  for (const group of groups) {
    lines.push(`### ${group}`, "", "| Script | Group | Description |", "|---|---|---|");
    const rows = rowsByGroup.get(group);
    if (rows.length === 0) {
      lines.push(`| - | ${group} | No starter script currently uses this group. |`);
    } else {
      for (const row of rows) {
        lines.push(`| \`${row.script}\` | ${group} | ${row.description} |`);
      }
    }
    lines.push("");
  }
  const targetPath = path.join(targetRoot, "reference/commands/COMMAND_TAXONOMY.md");
  fs.mkdirSync(path.dirname(targetPath), { recursive: true });
  fs.writeFileSync(targetPath, `${lines.join("\n").trim()}\n`, "utf8");
}

function commandTaxonomyGroup(script) {
  if (script === "pretest" || script === "test" || /^harness:(init|validate|sync-state|status|context|payload-boundary|promote-starter)\b/.test(script)) {
    return "core starter lifecycle";
  }
  if (/^harness:(codex|packet|transition|ready|task|orchestrate)/.test(script)) {
    return "Codex workflow";
  }
  if (/^(browser:|harness:(evidence|validation-report|packet-preflight|review|trace|walkthrough))/.test(script)) {
    return "evidence/review";
  }
  if (/^harness:(security|secret|risk|dependency|untrusted)/.test(script)) {
    return "security/risk gates";
  }
  if (/^harness:(learning|operator|refactor|doctor|next|dashboard)/.test(script)) {
    return "learning/operator diagnostics";
  }
  if (/^harness:v\d+/.test(script)) {
    return "compatibility namespaces";
  }
  return "maintenance/internal";
}

function commandTaxonomyDescription(script) {
  if (script === "pretest") return "Run starter preflight checks before tests.";
  if (script === "test") return "Run reusable harness tests.";
  if (script.startsWith("browser:")) return "Collect or inspect browser evidence.";
  if (script.startsWith("harness:")) return "Run a standard-harness command.";
  return "Starter package script.";
}

function starterReferenceArtifactPlaceholder(relativePath) {
  const title = path
    .basename(relativePath, path.extname(relativePath))
    .toLowerCase()
    .split(/[_-]+/)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
  return `# ${title}

Starter placeholder. Replace this file with project-specific content only after the relevant requirements, profile, packet, or approval boundary makes it active.

## Starter Boundary
- This file is not current execution state.
- Generated runtime state must be created by harness commands, not edited manually.
- Product-specific facts, packet history, credentials, screenshots, and evidence from the source project must not be copied here.
`;
}

function redactProductContent(content) {
  let redacted = String(content ?? "");
  for (const { pattern, replacement } of productLeakageReplacementRules()) {
    redacted = redacted.replace(pattern, replacement);
  }
  return redacted;
}

function productLeakageReplacementRules() {
  const productName = ["Financial", "BI"].join(" ");
  const productSlug = ["financial", "bi"].join("-");
  const databaseName = ["financial", "bi"].join("_");
  const packetPrefix = ["PKT", "FINBI"].join("-");
  const envPrefix = ["FINBI", ""].join("_");
  const sourcePath = ["C:", "30_project", productSlug].join("[\\\\/]+");
  const repoPath = ["Heeyoung-Ahn", productSlug].join("[\\\\/]+");
  return [
    { pattern: new RegExp(`\\b${escapeRegExp(productName)}\\b`, "gi"), replacement: "Standard Harness" },
    { pattern: new RegExp(`\\b${escapeRegExp(productSlug)}\\b`, "gi"), replacement: "standard-harness-starter" },
    { pattern: new RegExp(`\\b${escapeRegExp(databaseName)}\\b`, "gi"), replacement: "standard_harness_starter" },
    { pattern: new RegExp(`${escapeRegExp(packetPrefix)}[A-Z0-9_-]*`, "gi"), replacement: "PKT-STARTER" },
    { pattern: new RegExp(`\\b${escapeRegExp(envPrefix)}[A-Z0-9_]*\\b`, "g"), replacement: "STARTER_DATABASE_URL" },
    { pattern: new RegExp(sourcePath, "gi"), replacement: "C:\\path\\to\\standard-harness-starter" },
    { pattern: new RegExp(repoPath, "gi"), replacement: "example/standard-harness-starter" }
  ];
}

function writeExportProvenance({ sourceRoot, targetRoot, plan }) {
  const provenancePath = path.join(targetRoot, ".harness/promotion/EXPORT_PROVENANCE.json");
  fs.mkdirSync(path.dirname(provenancePath), { recursive: true });
  fs.writeFileSync(
    provenancePath,
    `${JSON.stringify(
      {
        schemaVersion: "1.0",
        generatedBy: "harness:promote-starter",
        generatedAt: new Date().toISOString(),
        sourceRootRedacted: true,
        targetRootRedacted: true,
        summary: summarizePlan(plan),
        authority: AUTHORITY_DENIAL
      },
      null,
      2
    )}\n`,
    "utf8"
  );
}

function auditFindingForPath(filePath) {
  const normalized = normalizePromotionPath(filePath);
  return {
    severity: "block",
    lane: auditLaneForPath(normalized),
    path: normalized,
    reason: "File matches a starter promotion contamination boundary."
  };
}

function findProductContentLeakage({ candidateRoot }) {
  const findings = [];
  for (const filePath of listFiles(candidateRoot)) {
    const absolutePath = path.join(candidateRoot, filePath);
    let content = "";
    try {
      content = fs.readFileSync(absolutePath, "utf8");
    } catch {
      continue;
    }
    const matches = productLeakageMatchers()
      .filter(({ pattern }) => pattern.test(content))
      .map(({ label }) => label);
    if (matches.length === 0) continue;
    findings.push({
      severity: "block",
      lane: "product_content_leakage",
      path: normalizePromotionPath(filePath),
      reason: `File content contains product-only marker(s): ${matches.join(", ")}.`
    });
  }
  return findings;
}

function productLeakageMatchers() {
  const productName = ["Financial", "BI"].join(" ");
  const productSlug = ["financial", "bi"].join("-");
  const databaseName = ["financial", "bi"].join("_");
  const packetPrefix = ["PKT", "FINBI"].join("-");
  const envPrefix = ["FINBI", ""].join("_");
  const sourcePath = ["C:", "30_project", productSlug].join("[\\\\/]+");
  const repoPath = ["Heeyoung-Ahn", productSlug].join("[\\\\/]+");
  return [
    {
      label: productName,
      pattern: new RegExp(`\\b${escapeRegExp(productName)}\\b`, "i")
    },
    {
      label: productSlug,
      pattern: new RegExp(`\\b${escapeRegExp(productSlug)}\\b`, "i")
    },
    {
      label: databaseName,
      pattern: new RegExp(`\\b${escapeRegExp(databaseName)}\\b`, "i")
    },
    {
      label: packetPrefix,
      pattern: new RegExp(`${escapeRegExp(packetPrefix)}[A-Z0-9_-]*`, "i")
    },
    {
      label: `${envPrefix}*`,
      pattern: new RegExp(`\\b${escapeRegExp(envPrefix)}[A-Z0-9_]*\\b`)
    },
    {
      label: ["C:", "30_project", productSlug].join("\\"),
      pattern: new RegExp(sourcePath, "i")
    },
    {
      label: ["Heeyoung-Ahn", productSlug].join("/"),
      pattern: new RegExp(repoPath, "i")
    }
  ];
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function auditLaneForPath(filePath) {
  const lower = filePath.toLowerCase();
  if (lower.startsWith("src/") || lower.startsWith("app/") || lower.startsWith("apps/") || lower.startsWith("product/")) {
    return "product_code";
  }
  if (
    lower.startsWith(".agents/runtime/") ||
    lower.startsWith(".harness/cache/") ||
    lower.startsWith(".harness/logs/") ||
    lower.includes("operating_state.sqlite")
  ) {
    return "runtime_state";
  }
  if (
    lower.startsWith(".harness/packets/") ||
    lower.startsWith(".harness/reports/") ||
    lower.startsWith("reference/archive/legacy-reference-layout/") ||
    lower.startsWith("reference/evidence/") ||
    isPacketInstanceArtifact(lower) ||
    lower.startsWith(".agents/artifacts/") ||
    lower.startsWith("verification/")
  ) {
    return "evidence_report";
  }
  if (
    lower.includes("secret") ||
    lower.includes("credential") ||
    lower.includes("session") ||
    lower.includes("transcript") ||
    lower === ".env" ||
    lower.startsWith(".env.")
  ) {
    return "secret_session_transcript";
  }
  if (lower.startsWith("docs/requirements/") || lower.startsWith("docs/planning/") || lower.startsWith("docs/decisions/")) {
    return "project_specific_docs";
  }
  return "generated_or_excluded";
}

function isPacketInstanceArtifact(lowerPath) {
  if (!lowerPath.startsWith("reference/packets/")) return false;
  if (lowerPath.startsWith("reference/packets/templates/")) return false;
  if (lowerPath === "reference/packets/readme.md" || lowerPath === "reference/packets/pkt-01_work_item_packet_template.md") return false;
  return lowerPath.split("/").length > 3;
}

function summarizeFindings(findings) {
  return {
    pass: findings.length === 0 ? 1 : 0,
    warn: findings.filter((finding) => finding.severity === "warn").length,
    hold: findings.filter((finding) => finding.severity === "hold").length,
    block: findings.filter((finding) => finding.severity === "block").length
  };
}

function listFiles(root) {
  const files = [];
  if (!fs.existsSync(root)) return files;
  walk(root, "");
  return files.map(normalizePromotionPath).sort();

  function walk(currentRoot, relativeRoot) {
    for (const entry of fs.readdirSync(currentRoot, { withFileTypes: true })) {
      if (entry.name === "node_modules" || entry.name === ".git") continue;
      const relativePath = relativeRoot ? `${relativeRoot}/${entry.name}` : entry.name;
      const absolutePath = path.join(currentRoot, entry.name);
      if (entry.isDirectory()) {
        walk(absolutePath, relativePath);
      } else if (entry.isFile()) {
        files.push(relativePath);
      }
    }
  }
}
