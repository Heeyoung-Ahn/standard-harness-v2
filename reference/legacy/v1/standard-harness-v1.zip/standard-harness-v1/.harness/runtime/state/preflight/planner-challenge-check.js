import {
  normalizePacketHeaderValue,
  readPacketBulletFieldValueFromContent,
  sliceSection
} from "../lib/packet-markdown.js";

export const PLANNER_PACKET_CHALLENGE_HEADING = "## Planner Packet Challenge Review";

const PLANNER_PACKET_CHALLENGE_REQUIRED_FIELDS = [
  "Challenge reviewer",
  "Challenge reviewer independence basis",
  "Source refs reviewed",
  "Parent objective coverage",
  "Deferred scope with named follow-up",
  "Acceptance proves behavior change",
  "Failure fixture or failure condition",
  "Reviewer closeout hold basis",
  "First-wave limit check",
  "Guidance-only sufficiency rationale",
  "Challenge evidence artifact path",
  "Findings disposition",
  "Required corrections applied",
  "No self-approval claim"
];

const TWO_CHALLENGE_TRIGGER_PATTERN =
  /\b(broad deferred scope|disputed evidence|cross-project rollout|security|auth|authentication|authorization|DB-backed|db backed|runtime persistence|browser|E2E|end-to-end|admin workflow|migration|deploy|deployment|cutover|reusable harness governance)\b/i;
const NEGATED_SCOPE_LINE_PATTERN =
  /\b(out of scope|non-goal|not[- ]needed|not applicable|no product|no schema|no db|no database|no browser|no ui|no deployment|no migration|none)\b/i;

export function evaluatePlannerPacketChallenge({ content, stage, effectiveRisk, gateProfile, changeZone, routeClass }) {
  const explicitRequired = normalizePacketHeaderValue(readPacketBulletFieldValueFromContent(content, "Planner packet challenge required") ?? "");
  const fastPathExempt =
    effectiveRisk === "low" &&
    changeZone === "padded" &&
    routeClass === "fast-path" &&
    (gateProfile === "light" || gateProfile === "standard" || !gateProfile);
  const requiredReasons = [
    "universal planning packet challenge/exemption gate",
    effectiveRisk === "high" || effectiveRisk === "critical" ? `effective risk ${effectiveRisk}` : null,
    changeZone === "core" || changeZone === "load-bearing" ? `Change zone ${changeZone}` : null,
    gateProfile === "contract" || gateProfile === "release" ? `Gate profile ${gateProfile}` : null,
    routeClass === "packet-path" && !fastPathExempt ? "Route class packet-path" : null,
    routeClass === "strict-path" ? "Route class strict-path" : null,
    ["yes", "required", "true"].includes(explicitRequired) ? "packet declares challenge required" : null
  ].filter(Boolean);
  const requiresTwoIndependentChallenges =
    effectiveRisk === "critical" ||
    (effectiveRisk === "high" && hasRiskTriggerInActiveScope(content));
  if (requiresTwoIndependentChallenges) {
    requiredReasons.push("two independent challenge reviews required by risk trigger");
  }
  const required = true;
  const section = sliceSection(content, PLANNER_PACKET_CHALLENGE_HEADING) ?? "";
  const status = normalizePacketHeaderValue(readPacketBulletFieldValueFromContent(section, "Challenge status") ?? "");
  const statusIsPass = status === "pass";
  const statusIsExemption = ["exempt", "exemption-approved", "approved-exemption"].includes(status);
  const statusAccepted = statusIsPass || (statusIsExemption && fastPathExempt);
  const missingFields = PLANNER_PACKET_CHALLENGE_REQUIRED_FIELDS.filter((field) => {
    const value = readPacketBulletFieldValueFromContent(section, field);
    return !isClosedChallengeField(value);
  });
  const diagnostics = [];
  if (required && !section) {
    diagnostics.push({
      field: "Planner Packet Challenge Review",
      status: stage === "implementation-transition" ? "block" : "hold",
      current: "missing",
      expected: PLANNER_PACKET_CHALLENGE_HEADING,
      reason: `Challenge review is required because ${requiredReasons.join(", ")}.`,
      message: `Planner Packet Challenge Review is required before implementation transition because ${requiredReasons.join(", ")}.`,
      repairHint: buildPlannerChallengeRepairHint("Planner Packet Challenge Review")
    });
  }
  if (required && statusIsExemption && !fastPathExempt) {
    diagnostics.push({
      field: "Challenge status",
      status: stage === "implementation-transition" ? "block" : "hold",
      current: status,
      expected: "pass unless low-risk fast-path explicit exemption is valid",
      reason: "Only low-risk padded fast-path packets may use explicit challenge exemption.",
      message: "Planner Packet Challenge Review exemption is only allowed for low-risk padded fast-path packets.",
      repairHint: buildPlannerChallengeRepairHint("Challenge status")
    });
  }
  if (required && !statusAccepted) {
    diagnostics.push({
      field: "Challenge status",
      status: stage === "implementation-transition" ? "block" : "hold",
      current: status || "missing",
      expected: "pass or approved explicit low-risk exemption",
      reason: "Planning packets must pass packet-quality challenge review or record a valid explicit exemption before Ready For Code delivery.",
      message: `Planner Packet Challenge Review requires Challenge status: pass or approved explicit exemption before implementation transition; current value is ${status || "missing"}.`,
      repairHint: buildPlannerChallengeRepairHint("Challenge status")
    });
  }
  for (const field of missingFields) {
    diagnostics.push({
      field,
      status: stage === "implementation-transition" ? "block" : "hold",
      current: readPacketBulletFieldValueFromContent(section, field) || "missing",
      expected: "closed challenge-review evidence",
      reason: "Required challenge review fields must show non-pending packet-quality evidence.",
      message: `Planner Packet Challenge Review field "${field}" must be closed before implementation transition.`,
      repairHint: buildPlannerChallengeRepairHint(field)
    });
  }
  if (required && requiresTwoIndependentChallenges && section && !hasTwoIndependentChallengeReviewers(section)) {
    diagnostics.push({
      field: "Challenge reviewer",
      status: stage === "implementation-transition" ? "block" : "hold",
      current: readPacketBulletFieldValueFromContent(section, "Challenge reviewer") || "missing",
      expected: "two separate subagents or two independent challenge reviewers",
      reason: "Critical or high-risk trigger packets need two independent lenses before Ready For Code.",
      message: "Planner Packet Challenge Review must record two separate subagents or two independent challenge reviewers for this risk trigger.",
      repairHint: buildPlannerChallengeRepairHint("Challenge reviewer", { requiresTwo: true })
    });
  }
  diagnostics.push(...inspectChallengeFieldQuality({ section, stage, required, statusIsPass, statusIsExemption }));

  const closedChallengeClaim = statusIsPass || statusIsExemption;
  const blocking =
    required &&
    diagnostics.length > 0 &&
    (stage === "implementation-transition" || closedChallengeClaim);
  return {
    ok: !required || diagnostics.length === 0,
    required,
    requiredReasons,
    requiredChallengeLevel: requiresTwoIndependentChallenges ? "two-independent-challenges" : "one-independent-challenge-or-exemption",
    status: status || "missing",
    current: required
      ? `required; status=${status || "missing"}; missingFields=${missingFields.length}`
      : "not required",
    expected: required
      ? "Challenge status pass or approved explicit exemption with closed source/evidence/disposition fields"
      : "optional only when packet contract explicitly disables the universal gate",
    diagnostics,
    blocking
  };
}

function inspectChallengeFieldQuality({ section, stage, required, statusIsPass = false, statusIsExemption = false }) {
  if (!required || !section) {
    return [];
  }
  const diagnostics = [];
  const closedChallengeClaim = statusIsPass || statusIsExemption;
  const packetAuthor = readPacketBulletFieldValueFromContent(section, "Packet author") ?? "";
  const reviewerIdentities = extractChallengeReviewerIdentities(section);
  const normalizedAuthor = normalizeReviewerIdentityToken(packetAuthor);
  if (normalizedAuthor && reviewerIdentities.has(normalizedAuthor)) {
    diagnostics.push(buildChallengeQualityDiagnostic({
      field: "Challenge reviewer",
      code: "planner_challenge_self_approval",
      stage,
      forceBlock: closedChallengeClaim,
      current: readPacketBulletFieldValueFromContent(section, "Challenge reviewer") ?? "missing",
      expected: "challenge reviewer identity different from packet author",
      reason: "Planner Packet Challenge Review cannot be approved by the same identity that authored the packet.",
      message: "Planner Packet Challenge Review appears self-approved because Packet author and Challenge reviewer match."
    }));
  }

  const deferredScope = readPacketBulletFieldValueFromContent(section, "Deferred scope with named follow-up") ?? "";
  const deferredNormalized = normalizePacketHeaderValue(deferredScope);
  if (
    deferredScope &&
    !["none", "not-needed", "no-deferred-scope"].includes(deferredNormalized) &&
    !/follow[- ]?up|next packet|OPS-[A-Z0-9-]+|PKT-[A-Z0-9-]+/i.test(deferredScope)
  ) {
    diagnostics.push(buildChallengeQualityDiagnostic({
      field: "Deferred scope with named follow-up",
      stage,
      forceBlock: closedChallengeClaim,
      current: deferredScope,
      expected: "none, not-needed, or named follow-up packet",
      reason: "Deferred scope must not escape without a named owner.",
      message: "Planner Packet Challenge Review deferred scope must name a follow-up packet or state none/not-needed."
    }));
  }

  const acceptance = readPacketBulletFieldValueFromContent(section, "Acceptance proves behavior change") ?? "";
  if (/document exists|artifact exists|marker only|presence only|exists only/i.test(acceptance)) {
    diagnostics.push(buildChallengeQualityDiagnostic({
      field: "Acceptance proves behavior change",
      stage,
      forceBlock: closedChallengeClaim,
      current: acceptance,
      expected: "behavior-changing evidence, not marker-only artifact existence",
      reason: "Acceptance must prove the parent objective changes behavior.",
      message: "Planner Packet Challenge Review acceptance evidence cannot be marker-only artifact/document existence."
    }));
  }

  const noSelfApproval = readPacketBulletFieldValueFromContent(section, "No self-approval claim") ?? "";
  if (noSelfApproval && !/no self|not self|independent|sub-agent|adversarial/i.test(noSelfApproval)) {
    diagnostics.push(buildChallengeQualityDiagnostic({
      field: "No self-approval claim",
      stage,
      forceBlock: closedChallengeClaim,
      current: noSelfApproval,
      expected: "explicit no-self-approval or independent reviewer claim",
      reason: "Planner must not self-pass the challenge review.",
      message: "Planner Packet Challenge Review must explicitly rule out self-approval."
    }));
  }

  const reReview = readPacketBulletFieldValueFromContent(section, "Re-review evidence") ?? "";
  if (/stale|pre[- ]?correction[- ]?only|before correction only|not rerun|not re[- ]?reviewed/i.test(reReview)) {
    diagnostics.push(buildChallengeQualityDiagnostic({
      field: "Re-review evidence",
      stage,
      forceBlock: closedChallengeClaim,
      current: reReview,
      expected: "post-correction re-review evidence or not-needed",
      reason: "Packet edits after challenge findings must be re-reviewed before Ready For Code.",
      message: "Planner Packet Challenge Review re-review evidence is stale or pre-correction-only."
    }));
  }

  return diagnostics;
}

function buildChallengeQualityDiagnostic({ field, code, stage, forceBlock = false, current, expected, reason, message }) {
  return {
    field,
    code,
    status: stage === "implementation-transition" || forceBlock ? "block" : "hold",
    current: current || "missing",
    expected,
    reason,
    message,
    repairHint: buildPlannerChallengeRepairHint(field)
  };
}

export function buildPlannerChallengeRepairHint(field, { requiresTwo = false } = {}) {
  if (field === "Planner Packet Challenge Review") {
    return [
      `Add ${PLANNER_PACKET_CHALLENGE_HEADING} with closed challenge evidence, for example:`,
      "- Packet author: planner-agent",
      "- Challenge reviewer: independent-reviewer-1",
      "- Challenge reviewer independence basis: reviewer is not the packet author",
      "- Source refs reviewed: packet, parent objective, approved source",
      "- Challenge status: pass",
      "- Findings disposition: no findings, or findings applied/deferred with owner",
      "- Required corrections applied: applied, or not-needed because no findings",
      "- No self-approval claim: independent reviewer, not packet author"
    ].join("\n");
  }
  if (field === "Challenge reviewer") {
    return requiresTwo
      ? 'Record two concrete reviewer identities, e.g. "- Challenge reviewer: reviewer-a; reviewer-b".'
      : 'Record a reviewer identity that differs from the packet author, e.g. "- Challenge reviewer: independent-reviewer-1".';
  }
  if (field === "Challenge status") {
    return 'Use "- Challenge status: pass" after independent challenge review, or an approved low-risk exemption only when the packet qualifies.';
  }
  if (field === "No self-approval claim") {
    return 'Use "- No self-approval claim: independent reviewer, not packet author" and ensure Challenge reviewer differs from Packet author.';
  }
  if (field === "Re-review evidence") {
    return 'Use "- Re-review evidence: post-correction review completed" when challenge findings caused packet edits, or "not-needed" when no corrections were required.';
  }
  return `Add "- ${field}: <closed challenge-review evidence>" under ${PLANNER_PACKET_CHALLENGE_HEADING}.`;
}

function isClosedChallengeField(value) {
  const normalized = normalizePacketHeaderValue(value);
  return Boolean(value) && !["pending", "draft", "todo", "tbd", "unknown", "missing", "fail", "hold"].includes(normalized);
}

function hasTwoIndependentChallengeReviewers(section) {
  return extractChallengeReviewerIdentities(section).size >= 2;
}

function extractChallengeReviewerIdentities(section) {
  const reviewer = readPacketBulletFieldValueFromContent(section, "Challenge reviewer") ?? "";
  const uuidIdentities = reviewer.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi) ?? [];
  const tokenIdentities = reviewer
    .split(/\s*(?:,|;|\/|\band\b|\&|\+)\s*/i)
    .map(normalizeReviewerIdentityToken)
    .filter(Boolean)
    .filter((item) => !/^(independent|planning|reviewer|reviewers|subagent|subagents|adversarial|two|2|separate|lenses?)$/i.test(item));
  return new Set([...uuidIdentities, ...tokenIdentities].map((item) => item.toLowerCase()));
}

function normalizeReviewerIdentityToken(value) {
  let normalized = String(value ?? "")
    .replace(/[`*_]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
  if (!normalized || /^(two|2)\s+(independent|separate)\s+(reviewers?|subagents?|lenses?)$/.test(normalized)) {
    return "";
  }
  normalized = normalized
    .replace(/^(independent|separate|adversarial)\s+/i, "")
    .replace(/^(planning\s+)?(reviewers?|subagents?|lenses?)\s+/i, "")
    .trim();
  if (/^(independent|planning|reviewer|reviewers|subagent|subagents|adversarial|two|2|separate|lenses?)$/.test(normalized)) {
    return "";
  }
  return normalized;
}

export function hasRiskTriggerInActiveScope(content = "") {
  return TWO_CHALLENGE_TRIGGER_PATTERN.test(activeScopeText(content));
}

function activeScopeText(content = "") {
  return String(content)
    .split(/\r?\n/)
    .filter((line) => !NEGATED_SCOPE_LINE_PATTERN.test(line))
    .join("\n");
}
