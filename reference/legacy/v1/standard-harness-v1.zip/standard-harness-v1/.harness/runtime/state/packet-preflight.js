import fs from "node:fs";
import path from "node:path";

import {
  normalizePacketHeaderValue,
  parseTableCells,
  readPacketBulletFieldValueFromContent,
  readPacketHeaderValueFromContent,
  sliceSection
} from "./lib/packet-markdown.js";
import { inspectTaskPacketContract } from "./drift-validator.js";
import {
  evaluateChangeZoneClassification,
  parseChangedFilesOption
} from "./change-zone-map.js";
import { evaluateModelingImpact } from "./modeling-impact.js";
import { createOperatingStateStore, DEFAULT_DB_PATH } from "./operating-state-store.js";
import { evaluateParallelBatchPlan } from "./parallel-batch.js";
import { evaluateSecurityReviewEvidence } from "./security-evidence.js";
import { evaluateTddEvidenceContract } from "./tdd-evidence.js";
import { evaluateRiskAdaptiveGate } from "./risk-adaptive-gates.js";
import { selectActiveWorkItem } from "./workflow-routing.js";
import { evaluateEvidenceManifestBinding } from "./evidence-manifest.js";
import { evaluateBrowserEvidenceBinding } from "./browser-evidence.js";
import { evaluatePacketArtifactLifecycle } from "./packet-artifact-lifecycle.js";
import { resolvePacketMarkdownPath } from "./packet-paths.js";
import {
  CLOSEOUT_ENUMS,
  CLOSEOUT_REFERENCE,
  NARRATIVE_DESTINATION,
  STRICT_LITERAL_ENUM_GUIDE,
  inspectCloseoutEnums
} from "./preflight/closeout-contract.js";
import { classifyRisk, emptyRisk } from "./preflight/risk.js";
import {
  blockedNextActionForStage,
  decideStage,
  normalizeStage,
  resolveFinalDisposition
} from "./preflight/stage-decision.js";
import {
  PLANNER_PACKET_CHALLENGE_HEADING,
  evaluatePlannerPacketChallenge,
  hasRiskTriggerInActiveScope
} from "./preflight/planner-challenge-check.js";
export function runPacketPreflightCommand({
  repoRoot = process.cwd(),
  dbPath = DEFAULT_DB_PATH,
  args = []
} = {}) {
  const options = parseArgs(args);
  return withStore({ repoRoot, dbPath }, (store) => buildPacketPreflight({ store, repoRoot, options }));
}

function buildPacketPreflight({ store, repoRoot, options }) {
  const errors = [];
  const findings = [];
  const checks = [];
  const workItemId = options.workItem ?? options.workItemId ?? null;
  const workItem = workItemId ? store.getWorkItem(workItemId) : null;
  const activeTask = selectActiveWorkItem(store.listWorkItems(), { repoRoot });
  const requestedPacketPath = normalizeRelativePath(options.packet ?? options.packetPath ?? workItem?.sourceRef ?? activeTask?.sourceRef);
  const packetPath = resolvePacketMarkdownPath(repoRoot, requestedPacketPath);
  const content = readRelativeFile(repoRoot, packetPath);

  if (!packetPath) {
    errors.push("Missing --packet or --work-item with a sourceRef.");
  } else if (!content) {
    errors.push(`Packet file not found or unreadable: ${packetPath}.`);
  }

  const stage = normalizeStage(options.stage) ?? inferStage({ options, workItem, content });
  if (options.stage && !normalizeStage(options.stage)) {
    errors.push(`Invalid --stage ${options.stage}. Expected one of ${[...STAGES].join(", ")}.`);
  }

  const packet = content ? inspectPacket(content) : emptyPacket();
  const risk = content ? classifyRisk(packet, content) : emptyRisk();
  const readyForCode = normalizeReadyForCode(packet.header["Ready For Code"] ?? workItem?.metadata?.readyForCode);
  const routeClass = normalizePacketHeaderValue(packet.header["Route class"] ?? packet.fields["Route class"] ?? "");
  const deliveryRouteMode = normalizePacketHeaderValue(packet.header["Delivery route mode"] ?? workItem?.metadata?.deliveryRouteMode ?? "");
  const gateProfile = normalizePacketHeaderValue(packet.header["Gate profile"] ?? packet.fields["Gate profile"] ?? workItem?.metadata?.gateProfile ?? "");
  const changeZone = normalizePacketHeaderValue(packet.header["Change zone"] ?? packet.fields["Change zone"] ?? "");
  const changedFiles = parseChangedFilesOption(options.changedFiles ?? options.changedFile ?? "");
  const changeZoneClassification = content
    ? evaluateChangeZoneClassification({
        repoRoot,
        declaredChangeZone: changeZone,
        changedFiles,
        requestedRouteClass: routeClass || null
      })
    : null;
  const modelingImpact = content
    ? evaluateModelingImpact({
        repoRoot,
        content,
        stage,
        changeZone,
        changedFiles,
        changeZoneClassification
      })
    : null;
  const plannerPacketChallenge = content
    ? evaluatePlannerPacketChallenge({
        content,
        stage,
        effectiveRisk: risk.effective,
        gateProfile,
        changeZone,
        routeClass: changeZoneClassification?.effectiveRouteClass ?? routeClass
      })
    : null;
  const firstImplementationReadiness = content
    ? evaluateFirstImplementationReadiness({
        repoRoot,
        stage,
        workItem,
        workItemId,
        packetPath,
        readyForCode,
        gateProfile,
        deliveryRouteMode,
        routeClass: changeZoneClassification?.effectiveRouteClass ?? routeClass,
        changeZone
      })
    : null;
  const tddEvidence = content
    ? evaluateTddEvidenceContract({ repoRoot, content, stage, changedFiles })
    : null;
  const securityReview = content
    ? evaluateSecurityReviewEvidence({
        repoRoot,
        content,
        packetPath,
        workItemId: workItemId ?? activeTask?.workItemId ?? null,
        stage,
        effectiveRisk: risk.effective,
        changedFiles
      })
    : null;
  const parallelBatch = content
    ? evaluateParallelBatchPlan({ repoRoot, content, stage })
    : null;
  const riskAdaptive = content
    ? evaluateRiskAdaptiveGate({
        repoRoot,
        content,
        packetPath,
        stage,
        effectiveRisk: risk.effective,
        changedFiles,
        gateProfile,
        deliveryRouteMode,
        routeClass: changeZoneClassification?.effectiveRouteClass ?? routeClass
      })
    : null;
  const evidenceManifest = content
    ? evaluateEvidenceManifestBinding({
        repoRoot,
        content,
        packetPath,
        workItemId: workItemId ?? activeTask?.workItemId ?? null,
        stage,
        strict: Boolean(options.strictEvidenceManifest || options.requireEvidenceManifest)
      })
    : null;
  const browserEvidence = content
    ? evaluateBrowserEvidenceBinding({
        repoRoot,
        content,
        packetPath,
        workItemId: workItemId ?? activeTask?.workItemId ?? null,
        stage,
        changedFiles,
        strict: Boolean(options.strictBrowserEvidence || options.requireBrowserEvidence || options.strictEvidenceManifest)
      })
    : null;
  const packetScopeParity = content
    ? evaluatePacketScopeParity({ content, stage })
    : null;
  const dbBackedRuntimeEvidence = content
    ? evaluateDbBackedRuntimeEvidence({ content, stage })
    : null;
  const artifactSyncFreshness = content
    ? evaluateArtifactSyncFreshness({
        repoRoot,
        content,
        stage,
        workItemId: workItemId ?? activeTask?.workItemId ?? null,
        packetPath
      })
    : null;
  const packetArtifactLifecycle = content
    ? evaluatePacketArtifactLifecycle({
        repoRoot,
        content,
        packetPath,
        workItemId: workItemId ?? activeTask?.workItemId ?? null,
        stage
      })
    : null;
  const reviewExcerptFreshness = content
    ? evaluateReviewExcerptFreshness({
        repoRoot,
        content,
        stage,
        workItemId: workItemId ?? activeTask?.workItemId ?? null,
        packetPath
      })
    : null;
  const catalogFreshness = content
    ? evaluateDevelopmentCatalogFreshness({ repoRoot, content, stage })
    : null;

  addHeaderCheck(checks, findings, packet, "Ready For Code");
  addHeaderCheck(checks, findings, packet, "Gate profile");
  addHeaderCheck(checks, findings, packet, "Risk if started now");
  addHeaderCheck(checks, findings, packet, "Delivery route mode");
  addHeaderCheck(checks, findings, packet, "Route class");
  addHeaderCheck(checks, findings, packet, "Change zone");

  checks.push({
    field: "Risk preview",
    status: "info",
    current: `declared=${risk.declared}; derived=${risk.derived}; effective=${risk.effective}`,
    expected: "Use effective risk for stage-specific enforcement.",
    reason: risk.triggerReason
  });

  const enumDiagnostics = stage === "closeout" && content
    ? inspectCloseoutEnums(packet)
    : [];
  const semanticDiagnostics = content
    ? inspectSemanticContract({ repoRoot, packetPath, content, stage })
    : [];
  const semanticBlockingDiagnostics = semanticDiagnostics.filter((diagnostic) => diagnostic.blocking);
  const authoringGuide = buildAuthoringGuide({ semanticDiagnostics, enumDiagnostics });

  const stageDecision = decideStage({
    stage,
    readyForCode,
    effectiveRisk: risk.effective,
    enumDiagnostics
  });

  if (changeZoneClassification) {
    checks.push({
      field: "Change zone classification",
      status: changeZoneClassification.ok ? "pass" : "block",
      current:
        changedFiles.length === 0
          ? "no changed files supplied"
          : `${changeZoneClassification.diagnostics.length} classified path(s)`,
      expected: "declared Change zone matches ownership-map path defaults or promotes safely"
    });
    findings.push(...changeZoneClassification.diagnostics);
    if (!changeZoneClassification.ok) {
      errors.push(...changeZoneClassification.errors);
    }
  }

  if (modelingImpact) {
    checks.push({
      field: "Modeling Impact",
      status: modelingImpact.ok ? "pass" : "block",
      current: `${modelingImpact.status}; required=${modelingImpact.required ? "yes" : "no"}`,
      expected: "required core/load-bearing modeling impact is packet-local or promoted with an existing artifact"
    });
    findings.push(...modelingImpact.diagnostics);
    if (!modelingImpact.ok) {
      errors.push(...modelingImpact.diagnostics.map((diagnostic) => diagnostic.message));
    }
  }
  if (plannerPacketChallenge) {
    checks.push({
      field: "Planner Packet Challenge Review",
      status: plannerPacketChallenge.ok ? "pass" : plannerPacketChallenge.required ? "hold" : "info",
      current: plannerPacketChallenge.current,
      expected: plannerPacketChallenge.expected
    });
    findings.push(...plannerPacketChallenge.diagnostics);
    if (!plannerPacketChallenge.ok && plannerPacketChallenge.blocking) {
      errors.push(...plannerPacketChallenge.diagnostics.map(formatDiagnosticMessage));
    }
  }
  if (firstImplementationReadiness) {
    checks.push({
      field: "First implementation readiness",
      status: firstImplementationReadiness.triggerPresent ? "info" : "pass",
      current: firstImplementationReadiness.status,
      expected: "compact readiness boundary before first implementation transition"
    });
  }
  if (tddEvidence) {
    checks.push({
      field: "TDD Evidence Contract",
      status: tddEvidence.blocking ? "block" : tddEvidence.diagnostics.length > 0 ? "hold" : "pass",
      current: tddEvidence.required ? `required; diagnostics=${tddEvidence.diagnostics.length}` : "not required",
      expected: "RED/GREEN/REFACTOR evidence or approved exemption at closeout"
    });
    findings.push(...tddEvidence.diagnostics);
    if (tddEvidence.blocking) {
      errors.push(...tddEvidence.diagnostics.filter((item) => item.status === "block").map((item) => item.message));
    }
  }
  if (securityReview) {
    checks.push({
      field: "CSO Security Review",
      status: securityReview.blocking ? "block" : securityReview.required ? "hold" : "pass",
      current: securityReview.required ? `required; diagnostics=${securityReview.diagnostics.length}` : "not required",
      expected: "packet-bound security review evidence for high-risk/security-sensitive closeout"
    });
    findings.push(...securityReview.diagnostics);
    if (securityReview.blocking) {
      errors.push(...securityReview.diagnostics.filter((item) => item.status === "block").map(formatDiagnosticMessage));
    }
  }
  if (parallelBatch) {
    checks.push({
      field: "Parallel Batch Plan",
      status: parallelBatch.blocking ? "block" : parallelBatch.present ? "info" : "pass",
      current: parallelBatch.present ? `present; diagnostics=${parallelBatch.diagnostics.length}` : "not declared",
      expected: "file-overlap-safe batch plan when parallel execution is declared"
    });
    findings.push(...parallelBatch.diagnostics);
    if (parallelBatch.blocking) {
      errors.push(...parallelBatch.diagnostics.filter((item) => item.status === "block").map((item) => item.message));
    }
  }


  if (riskAdaptive) {
    checks.push({
      field: "V2.5 Risk-Adaptive Gate",
      status: riskAdaptive.blocking ? "block" : riskAdaptive.diagnostics.length > 0 ? "hold" : "pass",
      current: `${riskAdaptive.lane}; overlays=${riskAdaptive.riskOverlays.length > 0 ? riskAdaptive.riskOverlays.join(",") : "none"}; diagnostics=${riskAdaptive.diagnostics.length}`,
      expected: "risk overlays have stage-appropriate evidence before implementation transition or closeout"
    });
    findings.push(...riskAdaptive.diagnostics);
    if (riskAdaptive.blocking) {
      errors.push(...riskAdaptive.diagnostics.filter((item) => item.status === "block").map((item) => item.message));
    }
  }

  if (evidenceManifest) {
    checks.push({
      field: "Evidence Manifest Contract",
      status: evidenceManifest.blocking ? "block" : evidenceManifest.diagnostics.length > 0 ? "hold" : "pass",
      current: `${evidenceManifest.manifestPaths.length} manifest path(s); diagnostics=${evidenceManifest.diagnostics.length}`,
      expected: "packet-bound evidence manifests use supported V2.7/V2.8 schema and match packet_path/work_item_id"
    });
    findings.push(...evidenceManifest.diagnostics.map((diagnostic) => ({
      field: diagnostic.field ?? "Evidence Manifest",
      status: diagnostic.severity === "error" ? "block" : "hold",
      current: diagnostic.code ?? "diagnostic",
      expected: "valid packet-bound evidence manifest",
      reason: diagnostic.message,
      message: diagnostic.message
    })));
    if (evidenceManifest.blocking) {
      errors.push(...evidenceManifest.diagnostics
        .filter((item) => item.severity === "error")
        .map((item) => item.message));
    }
  }

  if (browserEvidence) {
    checks.push({
      field: "Browser Evidence Contract",
      status: browserEvidence.blocking ? "block" : browserEvidence.diagnostics.length > 0 ? "hold" : "pass",
      current: `required=${browserEvidence.required ? "yes" : "no"}; browser manifests=${browserEvidence.manifestPaths.length}; diagnostics=${browserEvidence.diagnostics.length}`,
      expected: "UI/user-facing closeout has packet-bound Codex Browser or optional Playwright evidence"
    });
    findings.push(...browserEvidence.diagnostics.map((diagnostic) => ({
      field: diagnostic.field ?? "Browser Evidence",
      status: diagnostic.severity === "error" ? "block" : "hold",
      current: diagnostic.code ?? "diagnostic",
      expected: "valid Codex Browser or optional Playwright browser evidence",
      reason: diagnostic.message,
      message: diagnostic.message
    })));
    if (browserEvidence.blocking) {
      errors.push(...browserEvidence.diagnostics
        .filter((item) => item.severity === "error")
        .map((item) => item.message));
    }
  }

  if (packetScopeParity) {
    checks.push({
      field: "Packet-scope parity",
      status: packetScopeParity.blocking ? "block" : packetScopeParity.required ? "pass" : "pass",
      current: packetScopeParity.required ? `required; status=${packetScopeParity.status ?? "missing"}; diagnostics=${packetScopeParity.diagnostics.length}` : "not required",
      expected: "approved packet requirements mapped to implementation and verification evidence"
    });
    findings.push(...packetScopeParity.diagnostics.map((diagnostic) => ({
      field: diagnostic.field,
      status: "block",
      current: diagnostic.code,
      expected: "packet-scope parity evidence without unimplemented or unverified approved scope",
      reason: diagnostic.message,
      message: diagnostic.message
    })));
    if (packetScopeParity.blocking) {
      errors.push(...packetScopeParity.diagnostics.map(formatDiagnosticMessage));
    }
  }

  if (dbBackedRuntimeEvidence) {
    checks.push({
      field: "DB-backed runtime evidence",
      status: dbBackedRuntimeEvidence.blocking ? "block" : dbBackedRuntimeEvidence.required ? "pass" : "pass",
      current: dbBackedRuntimeEvidence.required
        ? `required; schema=${dbBackedRuntimeEvidence.schemaStatus ?? "missing"}; runtime=${dbBackedRuntimeEvidence.runtimeStatus ?? "missing"}`
        : "not required",
      expected: "schema/migration evidence and live runtime persistence evidence are separate"
    });
    findings.push(...dbBackedRuntimeEvidence.diagnostics.map((diagnostic) => ({
      field: diagnostic.field,
      status: "block",
      current: diagnostic.code,
      expected: "separate passing schema/migration and live runtime persistence evidence",
      reason: diagnostic.message,
      message: diagnostic.message
    })));
    if (dbBackedRuntimeEvidence.blocking) {
      errors.push(...dbBackedRuntimeEvidence.diagnostics.map((diagnostic) => diagnostic.message));
    }
  }

  if (artifactSyncFreshness) {
    checks.push({
      field: "Artifact-sync freshness",
      status: artifactSyncFreshness.blocking ? "block" : artifactSyncFreshness.required ? "pass" : "pass",
      current: artifactSyncFreshness.required
        ? `${artifactSyncFreshness.reportPath ?? "missing report"}; diagnostics=${artifactSyncFreshness.diagnostics.length}`
        : "not required",
      expected: "active packet artifact-sync report is closeout-current and not stale"
    });
    findings.push(...artifactSyncFreshness.diagnostics.map((diagnostic) => ({
      field: diagnostic.field,
      status: "block",
      current: diagnostic.code,
      expected: "fresh artifact-sync closeout evidence",
      reason: diagnostic.message,
      message: diagnostic.message
    })));
    if (artifactSyncFreshness.blocking) {
      errors.push(...artifactSyncFreshness.diagnostics.map((diagnostic) => diagnostic.message));
    }
  }

  if (packetArtifactLifecycle) {
    checks.push({
      field: "Packet artifact lifecycle",
      status: packetArtifactLifecycle.blocking ? "block" : packetArtifactLifecycle.required ? "pass" : "pass",
      current: packetArtifactLifecycle.required
        ? `${packetArtifactLifecycle.manifestPath ?? "missing manifest path"}; diagnostics=${packetArtifactLifecycle.diagnostics.length}`
        : "not required",
      expected: "declared lifecycle packets have a replay manifest and lifecycle folders at closeout"
    });
    findings.push(...packetArtifactLifecycle.diagnostics.map((diagnostic) => ({
      field: diagnostic.field,
      status: "block",
      current: diagnostic.code,
      expected: "packet-centered artifact lifecycle evidence",
      reason: diagnostic.message,
      message: diagnostic.message
    })));
    if (packetArtifactLifecycle.blocking) {
      errors.push(...packetArtifactLifecycle.diagnostics.map((diagnostic) => diagnostic.message));
    }
  }

  if (reviewExcerptFreshness) {
    checks.push({
      field: "Generated review excerpt freshness",
      status: reviewExcerptFreshness.blocking ? "block" : reviewExcerptFreshness.required ? "pass" : "pass",
      current: reviewExcerptFreshness.required
        ? `${reviewExcerptFreshness.excerptPath ?? "missing excerpt"}; diagnostics=${reviewExcerptFreshness.diagnostics.length}`
        : "not required",
      expected: "generated review excerpt is source-bound to the active work item"
    });
    findings.push(...reviewExcerptFreshness.diagnostics.map((diagnostic) => ({
      field: diagnostic.field,
      status: "block",
      current: diagnostic.code,
      expected: "active work-item review excerpt",
      reason: diagnostic.message,
      message: diagnostic.message
    })));
    if (reviewExcerptFreshness.blocking) {
      errors.push(...reviewExcerptFreshness.diagnostics.map((diagnostic) => diagnostic.message));
    }
  }

  if (catalogFreshness) {
    checks.push({
      field: "Development catalog freshness",
      status: catalogFreshness.blocking ? "block" : catalogFreshness.required ? "pass" : "pass",
      current: catalogFreshness.required
        ? `required catalogs=${catalogFreshness.requiredCatalogs.join(", ")}; diagnostics=${catalogFreshness.diagnostics.length}`
        : "not required",
      expected: "API, test, and DB catalogs are non-template and source-bound when the packet declares catalog impact"
    });
    findings.push(...catalogFreshness.diagnostics.map((diagnostic) => ({
      field: diagnostic.field,
      status: "block",
      current: diagnostic.code,
      expected: "non-template source-bound development catalog",
      reason: diagnostic.message,
      message: diagnostic.message
    })));
    if (catalogFreshness.blocking) {
      errors.push(...catalogFreshness.diagnostics.map((diagnostic) => diagnostic.message));
    }
  }

  findings.push(...stageDecision.findings);
  if (stageDecision.blocking) {
    errors.push(...stageDecision.errors);
  }
  if (enumDiagnostics.length > 0) {
    errors.push(...enumDiagnostics.map(formatDiagnosticMessage));
  }
  checks.push({
    field: "Task packet semantic contract",
    status: semanticBlockingDiagnostics.length === 0 ? "pass" : "block",
    current:
      semanticDiagnostics.length === 0
        ? "pass"
        : `${semanticBlockingDiagnostics.length} blocking / ${semanticDiagnostics.length} total`,
    expected: "same semantic contract used by packet registration"
  });
  findings.push(...semanticDiagnostics);
  if (semanticBlockingDiagnostics.length > 0) {
    errors.push(...semanticBlockingDiagnostics.map(formatDiagnosticMessage));
  }

  const finalDisposition = resolveFinalDisposition({ stage, errors, stageDecision });
  return {
    ok: errors.length === 0,
    command: "packet-preflight",
    stage,
    disposition: finalDisposition,
    workItemId: workItemId ?? activeTask?.workItemId ?? null,
    packetPath,
    readyForCode,
    gateProfile: gateProfile || "missing",
    deliveryRouteMode: deliveryRouteMode || "missing",
    routeClass: changeZoneClassification?.effectiveRouteClass ?? (routeClass || "missing"),
    requestedRouteClass: routeClass || "missing",
    changeZone: changeZone || "missing",
    changedFiles,
    changeZoneClassification,
    modelingImpact,
    plannerPacketChallenge,
    firstImplementationReadiness,
    tddEvidence,
    securityReview,
    parallelBatch,
    riskAdaptive,
    evidenceManifest,
    browserEvidence,
    packetScopeParity,
    dbBackedRuntimeEvidence,
    artifactSyncFreshness,
    packetArtifactLifecycle,
    reviewExcerptFreshness,
    catalogFreshness,
    authoringGuide,
    risk,
    checks,
    findings,
    semanticDiagnostics,
    enumDiagnostics,
    errors,
    nextAction: errors.length > 0 ? blockedNextActionForStage(stage, stageDecision) : stageDecision.nextAction
  };
}

function evaluateFirstImplementationReadiness({
  repoRoot,
  stage,
  workItem,
  workItemId,
  packetPath,
  readyForCode,
  gateProfile,
  deliveryRouteMode,
  routeClass,
  changeZone
}) {
  const owner = normalizePacketHeaderValue(workItem?.owner ?? "");
  const status = normalizePacketHeaderValue(workItem?.status ?? "");
  const implementationOwners = new Set(["developer", "orchestrator", "tester", "reviewer"]);
  const implementationTransition = stage === "implementation-transition";
  const triggerReasons = [];
  const noRepeatReasons = [];

  if (implementationTransition && (!owner || owner === "planner")) {
    triggerReasons.push("implementation transition from planner or no-active owner");
  }
  if (implementationTransition && ["planning", "hold", "blocked"].includes(status)) {
    triggerReasons.push(`current status ${status || "missing"} is pre-implementation`);
  }
  if (implementationTransition && implementationOwners.has(owner)) {
    noRepeatReasons.push(`current owner ${owner} already has active implementation/verification handoff`);
  }
  if (!implementationTransition) {
    noRepeatReasons.push(`stage ${stage} is not implementation-transition`);
  }

  const activeContext = inspectActiveContextFreshness({ repoRoot, workItemId, packetPath });
  if (implementationTransition && activeContext.status !== "fresh") {
    triggerReasons.push(`active context ${activeContext.status}`);
  }

  const triggerPresent = triggerReasons.length > 0 && noRepeatReasons.length === 0;
  const readinessChecks = [
    {
      item: "active lane",
      value: workItemId ? `${workItemId} / ${owner || "missing"} / ${status || "missing"}` : "missing",
      source: "work_item_registry"
    },
    {
      item: "active packet",
      value: packetPath ?? "missing",
      source: "packet sourceRef"
    },
    {
      item: "Ready For Code",
      value: readyForCode,
      source: "packet Quick Decision Header"
    },
    {
      item: "packet/lane/route",
      value: `gate=${gateProfile || "missing"}; route=${routeClass || "missing"}; delivery=${deliveryRouteMode || "missing"}; changeZone=${changeZone || "missing"}`,
      source: "packet metadata"
    },
    {
      item: "canonical/generated boundary",
      value: "packet and operational DB are canonical for this transition; Active Context and generated docs are read models",
      source: "workspace contract"
    },
    {
      item: "validation finding meaning",
      value: "blockers stop the transition; warnings require explanation but do not equal product verification",
      source: "validation report contract"
    },
    {
      item: "root/standard-template parity",
      value: "required when reusable root workflow/runtime/test/manual surfaces change",
      source: "contract gate profile"
    }
  ];

  return {
    schemaVersion: "standard-harness-first-implementation-readiness/v1",
    status: triggerPresent ? "required" : "not-needed",
    triggerPresent,
    triggerReasons,
    noRepeatReasons,
    activeContext,
    readinessChecks,
    allowedNextAction:
      readyForCode === "approved"
        ? "Proceed only with the approved implementation transition and selected route."
        : "Hold before implementation until Ready For Code is explicitly approved.",
    stopCondition:
      "Stop if Ready For Code is not approved, Active Context is stale without sync/repair, the active packet is missing, or the requested work exceeds packet scope.",
    refreshBeforeBroadReread:
      activeContext.status === "fresh"
        ? null
        : "Run sync-state or context --repair before broad rereads or implementation."
  };
}

function inspectActiveContextFreshness({ repoRoot, workItemId, packetPath }) {
  const activeContextPath = path.resolve(repoRoot, ".agents", "runtime", "ACTIVE_CONTEXT.json");
  if (!fs.existsSync(activeContextPath)) {
    return {
      status: "missing",
      path: ".agents/runtime/ACTIVE_CONTEXT.json",
      reason: "Active Context is missing."
    };
  }
  try {
    const parsed = JSON.parse(fs.readFileSync(activeContextPath, "utf8"));
    const selectedWorkItem = parsed.selectedLane?.workItemId ?? parsed.activeTask?.workItemId ?? null;
    const selectedPacket = parsed.sources?.activePacket ?? parsed.activeTask?.sourceRef ?? null;
    if (workItemId && selectedWorkItem && selectedWorkItem !== workItemId) {
      return {
        status: "stale",
        path: ".agents/runtime/ACTIVE_CONTEXT.json",
        reason: `Active Context selected work item ${selectedWorkItem} does not match ${workItemId}.`
      };
    }
    if (packetPath && selectedPacket && normalizeRelativePath(selectedPacket) !== normalizeRelativePath(packetPath)) {
      return {
        status: "stale",
        path: ".agents/runtime/ACTIVE_CONTEXT.json",
        reason: `Active Context active packet ${selectedPacket} does not match ${packetPath}.`
      };
    }
    return {
      status: "fresh",
      path: ".agents/runtime/ACTIVE_CONTEXT.json",
      generatedAt: parsed.generatedAt ?? null
    };
  } catch (error) {
    return {
      status: "unreadable",
      path: ".agents/runtime/ACTIVE_CONTEXT.json",
      reason: error.message
    };
  }
}

function buildAuthoringGuide({ semanticDiagnostics, enumDiagnostics }) {
  const exactLiteralDiagnostics = semanticDiagnostics.filter(
    (diagnostic) => diagnostic.code === "task_packet_exact_enum_value_invalid"
  );
  const activeExactFields = new Set([
    ...exactLiteralDiagnostics.map((diagnostic) => diagnostic.field),
    ...enumDiagnostics.map((diagnostic) => diagnostic.field)
  ]);

  return {
    exactFieldRule: "Exact enum fields must contain the enum value only; punctuation and spaces are part of the exact value.",
    strictLiteralEnums: STRICT_LITERAL_ENUM_GUIDE.map((entry) => ({
      ...entry,
      activeDiagnostic: activeExactFields.has(entry.field)
    })),
    verificationManifest: {
      heading: "## Verification Manifest or numbered equivalent, for example ## 12. Verification Manifest",
      minimalExample: [
        "- Ready For Code: approved",
        "- root: targeted/full root checks (reusable harness core/root-starter sync packets only)",
        "- standard-template: targeted/full starter checks (reusable harness core/root-starter sync packets only)",
        "- targeted: packet-specific regression",
        "- validator: harness validator pass",
        "- active context: regenerated or not-needed",
        "- review closeout: Reviewer report or not-needed"
      ]
    },
    evidenceManifest: {
      heading: "## Evidence Manifest",
      minimalExample: [
        "- Evidence manifest path: reference/evidence/manifests/WI-01-tdd.json",
        "- Security evidence manifest path: reference/evidence/manifests/WI-01-security.json"
      ],
      createCommand: "npm run harness:evidence-manifest -- create --type tdd --work-item WI-01 --packet reference/packets/PKT-01.md --source-command 'npm test' --apply"
    },
    plannerPacketChallenge: {
      heading: PLANNER_PACKET_CHALLENGE_HEADING,
      requiredWhen: "all user-requested planning packets before Ready For Code; low-risk fast-path may use an explicit sourced exemption record, never a silent skip",
      minimalExample: [
        "- Challenge reviewer: independent planning reviewer",
        "- Challenge reviewer independence basis: reviewer is not the packet author",
        "- Source refs reviewed: packet, parent objective, approved source",
        "- Challenge status: pass",
        "- Parent objective coverage: names the parent objective slice this packet closes",
        "- Deferred scope with named follow-up: none, or follow-up packet id",
        "- Acceptance proves behavior change: concrete behavior/evidence, not marker-only existence",
        "- Failure fixture or failure condition: negative fixture or stated hold condition",
        "- Reviewer closeout hold basis: what later review may fail",
        "- First-wave limit check: not objective avoidance",
        "- Guidance-only sufficiency rationale: intentional level, or runtime enforcement planned",
        "- Challenge evidence artifact path: packet-local ledger or external evidence path",
        "- Findings disposition: no findings, or findings applied/deferred with owner",
        "- Required corrections applied: applied, or not-needed because no findings",
        "- No self-approval claim: independent reviewer, not packet author"
      ]
    },
    closeoutMetadataExample: {
      reference: CLOSEOUT_REFERENCE,
      fields: CLOSEOUT_ENUMS.map((entry) => ({
        field: entry.field,
        expected: entry.expected
      })),
      narrativeDestination: NARRATIVE_DESTINATION
    }
  };
}

function formatDiagnosticMessage(diagnostic) {
  const repair = diagnostic?.repairHint ?? diagnostic?.repairExample;
  return repair
    ? `${diagnostic.message}\n\n${repair}`
    : diagnostic.message;
}

function buildPacketScopeParityRepairExample() {
  return [
    "Copy-ready Packet-Scope Parity example:",
    "## Packet-Scope Parity Matrix",
    "| Requirement | Implementation evidence | Verification evidence | Status |",
    "|---|---|---|---|",
    "| Approved packet requirement | path/to/implementation-or-report.md | command or report evidence | implemented-and-verified |",
    "",
    "## 15. Packet Exit Quality Gate",
    "- Packet-scope parity status: pass",
    "- Reviewer parity reviewers: reviewer-a; reviewer-b",
    "",
    "Allowed parity status values: pass, approved, implemented-and-verified, not-needed.",
    "High-risk trigger closeout also requires two concrete Reviewer parity reviewer identities.",
    "Narrative destination: Closeout notes or REVIEW_REPORT.md."
  ].join("\n");
}

function evaluatePacketScopeParity({ content = "", stage = "planning-open" } = {}) {
  const allFields = readBulletFields(content);
  const closeoutFields = readBulletFields(sliceSection(content, "## 15. Packet Exit Quality Gate") ?? "");
  const status = normalizePacketHeaderValue(
    closeoutFields["Packet-scope parity status"] ??
    closeoutFields["Reviewer parity status"] ??
    closeoutFields["Implementation-vs-packet parity status"] ??
    allFields["Packet-scope parity status"] ??
    allFields["Reviewer parity status"] ??
    allFields["Implementation-vs-packet parity status"] ??
    ""
  );
  const effectiveRiskText = normalizePacketHeaderValue(
    readPacketHeaderValueFromContent(content, "Risk class") ??
    readPacketHeaderValueFromContent(content, "Risk if started now") ??
    allFields["Risk class"] ??
    allFields["Risk if started now"] ??
    ""
  );
  const highRiskTriggerScope =
    ["high", "critical"].includes(effectiveRiskText) && hasRiskTriggerInActiveScope(content);
  const required = stage === "closeout" && (
    normalizePacketHeaderValue(allFields["Packet-scope parity required"] ?? "") === "yes" ||
    normalizePacketHeaderValue(allFields["Reviewer parity required"] ?? "") === "yes" ||
    normalizePacketHeaderValue(allFields["Implementation-vs-packet parity required"] ?? "") === "yes" ||
    highRiskTriggerScope ||
    Boolean(status)
  );
  const reviewerParityReviewers =
    closeoutFields["Reviewer parity reviewers"] ??
    closeoutFields["Reviewer parity reviewer"] ??
    allFields["Reviewer parity reviewers"] ??
    allFields["Reviewer parity reviewer"] ??
    "";
  const requiresTwoReviewerParityIdentities = required && highRiskTriggerScope;
  const diagnostics = [];
  if (!required) {
    return { ok: true, required: false, status: status || null, diagnostics, blocking: false };
  }

  const acceptedStatuses = new Set(["pass", "approved", "implemented-and-verified", "implemented_and_verified", "not-needed", "not_needed"]);
  if (!acceptedStatuses.has(status)) {
    diagnostics.push({
      field: "Packet-scope parity status",
      code: "packet_scope_parity_missing_or_not_pass",
      message: `Closeout requires Packet-scope parity status pass/approved; current status is ${status || "missing"}.`,
      repairExample: buildPacketScopeParityRepairExample()
    });
  }

  const paritySection = sliceSection(content, "## Packet-Scope Parity Matrix") ?? "";
  if (!paritySection) {
    diagnostics.push({
      field: "Packet-scope parity matrix",
      code: "packet_scope_parity_matrix_missing",
      message: "Closeout requires a Packet-Scope Parity Matrix section mapping approved requirements to implementation and verification evidence.",
      repairExample: buildPacketScopeParityRepairExample()
    });
  }
  const unresolvedMatches = [...paritySection.matchAll(/\b(not-implemented|not_implemented|implemented-not-verified|implemented_not_verified)\b/gi)];
  for (const match of unresolvedMatches) {
    diagnostics.push({
      field: "Packet-scope parity matrix",
      code: "approved_scope_unimplemented_or_unverified",
      message: `Packet-scope parity matrix contains unresolved approved scope status: ${match[1]}.`
    });
  }
  const weakEvidenceMatches = [...paritySection.matchAll(/\b(api-only|render-only|schema-only|migration-only|stale|source-missing|source missing)\b/gi)];
  for (const match of weakEvidenceMatches) {
    diagnostics.push({
      field: "Packet-scope parity matrix",
      code: "approved_scope_weak_or_stale_evidence",
      message: `Packet-scope parity matrix contains weak or stale closeout evidence for approved scope: ${match[1]}.`
    });
  }
  if (requiresTwoReviewerParityIdentities && !hasTwoConcreteReviewerIdentities(reviewerParityReviewers)) {
    diagnostics.push({
      field: "Reviewer parity reviewers",
      code: "reviewer_parity_two_identities_missing",
      message: `High-risk trigger closeout requires two concrete reviewer parity identities; current value is ${reviewerParityReviewers || "missing"}.`,
      repairExample: buildPacketScopeParityRepairExample()
    });
  }
  return {
    ok: diagnostics.length === 0,
    required,
    status: status || null,
    diagnostics,
    blocking: stage === "closeout" && diagnostics.length > 0
  };
}

function hasTwoConcreteReviewerIdentities(value) {
  return extractConcreteReviewerIdentities(value).size >= 2;
}

function extractConcreteReviewerIdentities(value) {
  const reviewerText = String(value ?? "");
  const uuidIdentities = reviewerText.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi) ?? [];
  const tokenIdentities = reviewerText
    .split(/\s*(?:,|;|\/|\band\b|\&|\+)\s*/i)
    .map(normalizeConcreteReviewerIdentity)
    .filter(Boolean)
    .filter((item) => !/^(independent|reviewer|reviewers|subagent|subagents|adversarial|two|2|separate|lenses?|parity)$/i.test(item));
  return new Set([...uuidIdentities, ...tokenIdentities].map((item) => item.toLowerCase()));
}

function normalizeConcreteReviewerIdentity(value) {
  let normalized = String(value ?? "")
    .replace(/[`*_]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
  if (!normalized || /^(two|2)\s+(independent|separate)\s+(reviewers?|subagents?|lenses?)$/.test(normalized)) {
    return "";
  }
  normalized = normalized
    .replace(/^(independent|separate|adversarial)\s+/i, "")
    .replace(/^(reviewer|reviewers|subagent|subagents|lenses?|parity)\s+/i, "")
    .trim();
  if (/^(independent|reviewer|reviewers|subagent|subagents|adversarial|two|2|separate|lenses?|parity)$/.test(normalized)) {
    return "";
  }
  return normalized;
}

function evaluateDbBackedRuntimeEvidence({ content = "", stage = "planning-open" } = {}) {
  const allFields = readBulletFields(content);
  const closeoutFields = readBulletFields(sliceSection(content, "## 15. Packet Exit Quality Gate") ?? "");
  const schemaStatus = normalizePacketHeaderValue(
    closeoutFields["DB migration/schema status"] ??
    closeoutFields["Migration/schema status"] ??
    allFields["DB migration/schema status"] ??
    allFields["Migration/schema status"] ??
    ""
  );
  const runtimeStatus = normalizePacketHeaderValue(
    closeoutFields["DB-backed runtime persistence status"] ??
    closeoutFields["Runtime persistence status"] ??
    allFields["DB-backed runtime persistence status"] ??
    allFields["Runtime persistence status"] ??
    ""
  );
  const required = stage === "closeout" && (
    normalizePacketHeaderValue(allFields["DB-backed runtime required"] ?? "") === "yes" ||
    normalizePacketHeaderValue(allFields["Persistent runtime required"] ?? "") === "yes" ||
    Boolean(schemaStatus) ||
    Boolean(runtimeStatus)
  );
  const diagnostics = [];
  if (!required) {
    return { ok: true, required: false, schemaStatus: schemaStatus || null, runtimeStatus: runtimeStatus || null, diagnostics, blocking: false };
  }

  const passing = new Set(["pass", "approved", "verified", "implemented-and-verified", "implemented_and_verified"]);
  if (!passing.has(schemaStatus)) {
    diagnostics.push({
      field: "DB migration/schema status",
      code: "db_schema_evidence_missing_or_not_pass",
      message: `DB-backed closeout requires separate DB migration/schema evidence; current status is ${schemaStatus || "missing"}.`
    });
  }
  if (!passing.has(runtimeStatus)) {
    diagnostics.push({
      field: "DB-backed runtime persistence status",
      code: "db_runtime_persistence_missing_or_not_pass",
      message: `DB-backed closeout requires live runtime persistence evidence; current status is ${runtimeStatus || "missing"}. Migration/schema evidence alone is insufficient.`
    });
  }
  return {
    ok: diagnostics.length === 0,
    required,
    schemaStatus: schemaStatus || null,
    runtimeStatus: runtimeStatus || null,
    diagnostics,
    blocking: stage === "closeout" && diagnostics.length > 0
  };
}

function evaluateArtifactSyncFreshness({
  repoRoot,
  content = "",
  stage = "planning-open",
  workItemId = null,
  packetPath = null
} = {}) {
  const required = stage === "closeout" && /artifact-sync freshness|Artifact Sync Freshness Contract|stale artifact-sync|reference\/reports\/artifact-sync/i.test(content);
  const diagnostics = [];
  if (!required) {
    return { ok: true, required: false, reportPath: null, diagnostics, blocking: false };
  }
  const resolvedWorkItemId = resolvePacketWorkItemId({ content, workItemId, packetPath });
  const reportPath = resolvedWorkItemId
    ? resolveArtifactSyncReportPath(repoRoot, resolvedWorkItemId)
    : null;
  if (!reportPath) {
    diagnostics.push({
      field: "Artifact-sync report",
      code: "artifact_sync_work_item_missing",
      message: "Closeout requires an active work-item id to check artifact-sync freshness."
    });
    return { ok: false, required, reportPath, diagnostics, blocking: true };
  }
  const reportContent = readRelativeFile(repoRoot, reportPath);
  if (!reportContent) {
    diagnostics.push({
      field: "Artifact-sync report",
      code: "artifact_sync_report_missing",
      message: `Closeout requires artifact-sync report ${reportPath}.`
    });
    return { ok: false, required, reportPath, diagnostics, blocking: true };
  }
  const staleStatusPatterns = [
    /(?:^|\n)\s*-?\s*(current\s+)?status\s*:\s*(planning-open|ready for code|in[- ]?progress|pending|closeout pending|hold)\b/i,
    /(?:^|\n)\s*-?\s*closeout\s*:\s*pending\b/i,
    /(?:^|\n)\s*-?\s*Ready For Code\s*:\s*hold\b/i
  ];
  if (staleStatusPatterns.some((pattern) => pattern.test(reportContent))) {
    diagnostics.push({
      field: "Artifact-sync report",
      code: "artifact_sync_report_stale_status",
      message: `Artifact-sync report ${reportPath} contains stale planning/in-progress/pending language during closeout.`
    });
  }
  if (!/closeout complete|planner closeout|exit recommendation\s*:\s*approved|status\s*:\s*(closed|complete|closeout-ready)/i.test(reportContent)) {
    diagnostics.push({
      field: "Artifact-sync report",
      code: "artifact_sync_report_closeout_evidence_missing",
      message: `Artifact-sync report ${reportPath} must record closeout-current status, latest verification, residual risk, or follow-up owner evidence.`
    });
  }
  return {
    ok: diagnostics.length === 0,
    required,
    reportPath,
    diagnostics,
    blocking: diagnostics.length > 0
  };
}

function resolveArtifactSyncReportPath(repoRoot, workItemId) {
  const candidates = [
    `reference/packets/${workItemId}/07_closeout/artifact-sync.md`,
    `reference/packets/${workItemId}/07_closeout/legacy_artifact-sync_${workItemId}.md`
  ];
  return candidates.find((candidate) => readRelativeFile(repoRoot, candidate)) ?? candidates[0];
}

function evaluateReviewExcerptFreshness({
  repoRoot,
  content = "",
  stage = "planning-open",
  workItemId = null,
  packetPath = null
} = {}) {
  const required = stage === "closeout" && /generated review excerpt|review excerpt freshness|review-report-excerpts/i.test(content);
  const diagnostics = [];
  if (!required) {
    return { ok: true, required: false, excerptPath: null, diagnostics, blocking: false };
  }
  const resolvedWorkItemId = resolvePacketWorkItemId({ content, workItemId, packetPath });
  const excerptPath = resolvedWorkItemId
    ? `.agents/runtime/review-report-excerpts/${safeFilePart(resolvedWorkItemId)}-review-report.md`
    : null;
  if (!excerptPath) {
    diagnostics.push({
      field: "Generated review excerpt",
      code: "review_excerpt_work_item_missing",
      message: "Closeout requires an active work-item id to check generated review excerpt freshness."
    });
    return { ok: false, required, excerptPath, diagnostics, blocking: true };
  }
  const excerptContent = readRelativeFile(repoRoot, excerptPath);
  if (!excerptContent) {
    diagnostics.push({
      field: "Generated review excerpt",
      code: "review_excerpt_missing",
      message: `Closeout requires generated review excerpt ${excerptPath}. Run sync-state after packet-bound review evidence exists.`
    });
    return { ok: false, required, excerptPath, diagnostics, blocking: true };
  }
  const normalizedExcerpt = excerptContent.toLowerCase();
  if (!normalizedExcerpt.includes(resolvedWorkItemId.toLowerCase())) {
    diagnostics.push({
      field: "Generated review excerpt",
      code: "review_excerpt_work_item_mismatch",
      message: `Generated review excerpt ${excerptPath} does not mention active work item ${resolvedWorkItemId}.`
    });
  }
  const packetMatches = [...excerptContent.matchAll(/-\s*Packet:\s*`?([^`\r\n]+)`?/gi)].map((match) => match[1].trim());
  const hasDifferentPacket = packetMatches.some((packetRef) => {
    const normalized = packetRef.replace(/\\/g, "/").toLowerCase();
    return !normalized.includes(resolvedWorkItemId.toLowerCase());
  });
  if (hasDifferentPacket) {
    diagnostics.push({
      field: "Generated review excerpt",
      code: "review_excerpt_points_to_different_packet",
      message: `Generated review excerpt ${excerptPath} contains Packet lines for another packet instead of ${resolvedWorkItemId}.`
    });
  }
  return {
    ok: diagnostics.length === 0,
    required,
    excerptPath,
    diagnostics,
    blocking: diagnostics.length > 0
  };
}

function evaluateDevelopmentCatalogFreshness({ repoRoot, content = "", stage = "planning-open" } = {}) {
  const required = stage === "closeout" && /Minimum Artifact Catalog Contract|catalog freshness|API_CATALOG|TEST_CATALOG|DATABASE_MODEL/i.test(content);
  const diagnostics = [];
  const requiredCatalogs = [
    "reference/artifacts/API_CATALOG.md",
    "reference/artifacts/TEST_CATALOG.md",
    ".agents/artifacts/DATABASE_MODEL.md"
  ];
  if (!required) {
    return { ok: true, required: false, requiredCatalogs, diagnostics, blocking: false };
  }
  for (const catalogPath of requiredCatalogs) {
    const catalogContent = readRelativeFile(repoRoot, catalogPath);
    if (!catalogContent) {
      diagnostics.push({
        field: catalogPath,
        code: "development_catalog_missing",
        message: `Required development catalog is missing: ${catalogPath}.`
      });
      continue;
    }
    if (isTemplateOnlyCatalog(catalogContent)) {
      diagnostics.push({
        field: catalogPath,
        code: "development_catalog_template_only",
        message: `Required development catalog is still template-only or placeholder-like: ${catalogPath}.`
      });
    }
    diagnostics.push(...inspectCatalogContent({ catalogPath, catalogContent }));
  }
  return {
    ok: diagnostics.length === 0,
    required,
    requiredCatalogs,
    diagnostics,
    blocking: diagnostics.length > 0
  };
}

function inspectCatalogContent({ catalogPath, catalogContent }) {
  const diagnostics = [];
  const content = catalogContent.toLowerCase();
  if (catalogPath.endsWith("API_CATALOG.md")) {
    const requiredTokens = ["/api/auth/login", "/api/session/current", "/api/admin/users", "method", "path", "permission", "error", "test"];
    for (const token of requiredTokens) {
      if (!content.includes(token)) {
        diagnostics.push({
          field: catalogPath,
          code: "api_catalog_required_field_missing",
          message: `API catalog must include ${token} for current high-risk route inventory.`
        });
      }
    }
  }
  if (catalogPath.endsWith("TEST_CATALOG.md")) {
    const requiredTokens = ["api-platform.test.mjs", "auth-user-group-core.test.mjs", "browser", "evidence", "packet"];
    for (const token of requiredTokens) {
      if (!content.includes(token)) {
        diagnostics.push({
          field: catalogPath,
          code: "test_catalog_required_field_missing",
          message: `Test catalog must include ${token} for scenario/evidence mapping.`
        });
      }
    }
  }
  if (catalogPath.endsWith("DATABASE_MODEL.md")) {
    const requiredTokens = ["001_platform_foundation.sql", "002_auth_user_group_core.sql", "schema/migration evidence", "runtime persistence evidence"];
    for (const token of requiredTokens) {
      if (!content.includes(token)) {
        diagnostics.push({
          field: catalogPath,
          code: "database_catalog_required_field_missing",
          message: `Database model catalog must include ${token} and separate schema evidence from runtime persistence evidence.`
        });
      }
    }
  }
  return diagnostics;
}

function isTemplateOnlyCatalog(content) {
  const normalized = content.toLowerCase();
  return (
    /optional template|template is activated|activating packet:\s*(\r?\n|$)/i.test(content) ||
    /\|\s*\|\s*\|\s*\|/.test(content)
  );
}

function resolvePacketWorkItemId({ content = "", workItemId = null, packetPath = null } = {}) {
  if (workItemId) {
    return String(workItemId);
  }
  const headerValue = readPacketHeaderValueFromContent(content, "Work item") ?? "";
  const headerMatch = String(headerValue).match(/([A-Z]+-[A-Z0-9]+-\d+[A-Z0-9_-]*)/);
  if (headerMatch) {
    return headerMatch[1];
  }
  const titleMatch = String(content).match(/#\s+([A-Z]+-[A-Z0-9]+-\d+[A-Z0-9_-]*)/);
  if (titleMatch) {
    return titleMatch[1];
  }
  if (packetPath) {
    const basename = path.basename(packetPath, path.extname(packetPath));
    const pathMatch = basename.match(/([A-Z]+-[A-Z0-9]+-\d+[A-Z0-9_-]*)/);
    if (pathMatch) {
      return pathMatch[1];
    }
  }
  return null;
}

function safeFilePart(value) {
  return String(value ?? "")
    .replace(/[^A-Za-z0-9._-]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function inspectPacket(content) {
  const header = readQuickDecisionHeader(content);
  const fields = readBulletFields(content);
  const closeout = readBulletFields(sliceSection(content, "## 15. Packet Exit Quality Gate") ?? "");
  return { header, fields, closeout };
}

function emptyPacket() {
  return { header: {}, fields: {}, closeout: {} };
}

function inspectSemanticContract({ repoRoot, packetPath, content, stage }) {
  const semanticContract = inspectTaskPacketContract({
    repoRoot,
    packetPath,
    content,
    stage
  });
  const semanticErrors = semanticContract.findings?.filter((finding) => finding.severity === "error") ?? [];
  return semanticErrors.map((finding) => {
    const allowedPlanningHold =
      stage === "planning-open" && finding.code === "risk_class_high_requires_packet_approval_evidence";
    return {
      field: finding.headerItem ?? finding.field ?? "Task packet semantic contract",
      status: allowedPlanningHold ? "hold" : "block",
      current: finding.currentValue ?? finding.effectiveRiskClass ?? finding.declaredRiskClass ?? finding.headerItem ?? finding.field ?? "semantic error",
      expected: semanticFindingExpected(finding),
      code: finding.code,
      blocking: !allowedPlanningHold,
      reason: finding.message,
      message: formatSemanticFindingMessage(finding),
      repairHint: semanticFindingRepairHint(finding)
    };
  });
}

function semanticFindingExpected(finding) {
  if (Array.isArray(finding.expectedValues) && finding.expectedValues.length > 0) {
    return finding.expectedValues.join(" | ");
  }
  if (finding.headerItem) {
    return `approved status for ${finding.headerItem}`;
  }
  if (finding.code === "risk_class_high_requires_packet_approval_evidence") {
    return "Ready For Code approved with verification evidence before implementation transition";
  }
  return "registered packet semantic contract";
}

function formatSemanticFindingMessage(finding) {
  const details = [
    finding.code ? `code=${finding.code}` : null,
    finding.headerItem ? `field=${finding.headerItem}` : null,
    finding.field ? `field=${finding.field}` : null
  ].filter(Boolean);
  return `Task packet semantic preflight failed: ${finding.message}${details.length > 0 ? ` (${details.join("; ")})` : ""}`;
}

function semanticFindingRepairHint(finding) {
  const field = finding.headerItem ?? finding.field ?? "";
  if (field === "Packet exit metadata version") {
    return 'Use "- Packet exit metadata version: v1" before packet exit metadata fields.';
  }
  if (finding.code === "task_packet_exact_enum_value_invalid" && Array.isArray(finding.expectedValues) && finding.expectedValues.length > 0) {
    const current = finding.currentValue ?? "current value";
    return `Replace "${current}" with one of: ${finding.expectedValues.join(" | ")}. Move narrative to ${NARRATIVE_DESTINATION}.`;
  }
  return null;
}

function addHeaderCheck(checks, findings, packet, field) {
  const current = packet.header[field] ?? packet.fields[field] ?? "";
  const status = current ? "pass" : "warn";
  const check = {
    field,
    status,
    current: current || "missing",
    expected: "Quick Decision Header row"
  };
  checks.push(check);
  if (!current) {
    findings.push({
      ...check,
      reason: `${field} is missing from the packet authoring preflight surface.`
    });
  }
}

function readQuickDecisionHeader(content) {
  const section = sliceSection(content, "## Quick Decision Header") ?? "";
  const rows = {};
  for (const rawLine of section.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line.startsWith("|")) {
      continue;
    }
    const cells = parseTableCells(line);
    if (cells.length < 4 || /^-+$/.test(cells[0]) || cells[0].toLowerCase() === "item") {
      continue;
    }
    rows[cells[0].trim()] = cells[1]?.trim() ?? "";
  }
  return rows;
}

function readBulletFields(content) {
  const fields = {};
  if (!content) {
    return fields;
  }
  for (const rawLine of content.split(/\r?\n/)) {
    const match = rawLine.trim().match(/^-\s*([^:]+):\s*(.*)$/);
    if (match) {
      fields[match[1].trim()] = match[2].trim();
    }
  }
  return fields;
}

function inferStage({ options, workItem, content }) {
  if (options.transition && /^planner-to-(developer|orchestrator)$/i.test(options.transition)) {
    return "implementation-transition";
  }
  const packetExitStatus = normalizePacketHeaderValue(readPacketHeaderValueFromContent(content ?? "", "Packet exit gate status") ?? "");
  const closeoutRecommendation = normalizePacketHeaderValue(
    readPacketBulletFieldValueFromContent(sliceSection(content ?? "", "## 15. Packet Exit Quality Gate") ?? "", "Exit recommendation") ?? ""
  );
  if (packetExitStatus === "approved" || closeoutRecommendation === "approved") {
    return "closeout";
  }
  if (workItem?.owner === "planner" || !workItem) {
    return "planning-open";
  }
  return "implementation-transition";
}

function normalizeReadyForCode(value) {
  const normalized = normalizePacketHeaderValue(value);
  if (normalized === "approve") {
    return "approved";
  }
  if (["approved", "hold", "pending", "draft"].includes(normalized)) {
    return normalized;
  }
  return normalized || "missing";
}

function stripInlineFormatting(value) {
  return String(value ?? "")
    .trim()
    .replace(/^`|`$/g, "")
    .replace(/^\*\*|\*\*$/g, "")
    .replace(/^__|__$/g, "")
    .trim();
}

function readRelativeFile(repoRoot, relativePath) {
  if (!relativePath) {
    return null;
  }
  const target = path.resolve(repoRoot, relativePath);
  const root = path.resolve(repoRoot);
  if (!target.startsWith(root) || !fs.existsSync(target)) {
    return null;
  }
  return fs.readFileSync(target, "utf8");
}

function normalizeRelativePath(value) {
  if (!value) {
    return null;
  }
  return String(value).replace(/\\/g, "/").replace(/^\.\//, "");
}

function withStore({ repoRoot, dbPath }, callback) {
  const resolvedDbPath = path.isAbsolute(dbPath) ? dbPath : path.resolve(repoRoot, dbPath);
  const store = createOperatingStateStore({ dbPath: resolvedDbPath });
  try {
    return callback(store);
  } finally {
    store.close();
  }
}

function parseArgs(args) {
  const options = { positionals: [] };
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    if (!arg.startsWith("--")) {
      options.positionals.push(arg);
      continue;
    }
    const key = arg.slice(2).replace(/-([a-z])/g, (_, char) => char.toUpperCase());
    const next = args[index + 1];
    if (next == null || next.startsWith("--")) {
      options[key] = true;
      continue;
    }
    options[key] = next;
    index += 1;
  }
  const [first] = options.positionals;
  if (first) {
    options.workItem ??= first;
  }
  delete options.positionals;
  return options;
}
