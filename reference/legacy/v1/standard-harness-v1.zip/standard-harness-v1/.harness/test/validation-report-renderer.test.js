import assert from "node:assert/strict";
import test from "node:test";

import { buildValidationReportMarkdown } from "../runtime/state/validation-report/markdown-renderer.js";

test("validation report renderer preserves full markdown for optional sections", () => {
  const report = {
    executedAt: "2026-06-19T00:00:00.000Z",
    validatorVersion: "v-test",
    cutoverReady: false,
    gateDecision: "hold",
    nextAction: "Review evidence.",
    profileSummary: {
      path: ".agents/artifacts/ACTIVE_PROFILES.md",
      status: "declared",
      profiles: [{ profileId: "PRF-X", evidenceStatus: "approved", reason: "test profile" }]
    },
    riskClassifications: [
      {
        packetPath: "reference/packets/PKT.md",
        declaredRiskClass: "high",
        derivedRiskClass: "normal",
        effectiveRiskClass: "high",
        requestedRouteClass: "strict-path",
        chosenRouteClass: "strict-path",
        routeEligibility: "rejected",
        gateEffect: "hold",
        routeRejectionReasons: ["missing review"],
        modelingImpact: { status: "required", required: true, diagnosticCount: 2 }
      }
    ],
    findings: [{ severity: "warning", code: "sample_warning", message: "Sample warning." }],
    contextBudget: {
      status: "warn",
      enforcement: "advisory",
      hardFailEnabled: false,
      severity: "warning",
      blocking: false,
      gateEffect: "advisory-only",
      operatorMessage: "Stay lean.",
      workItemId: "OPS-TEST",
      role: "developer",
      defaultReadSet: {
        fileCount: 3,
        maxFileCount: 5,
        tokenEstimate: 1000,
        maxTokenEstimate: 2000
      },
      fallbackOnlyReadSet: {
        fileCount: 1,
        triggerReasons: ["large packet"]
      },
      overrunRationale: "none",
      warningCount: 1,
      outputBudget: {
        summaryMaxLines: 20,
        closeoutMaxLines: 40,
        repeatedHistoryPolicy: "summarize"
      }
    },
    riskAdaptive: {
      gateEffect: "blocking",
      lane: "standard",
      phase: "implementation",
      riskOverlays: ["security"],
      readCount: 4,
      estimatedTokensRead: 1500,
      targetTokens: 2200,
      contextBudgetStatus: "warn",
      humanManualAutoRead: false,
      blocking: true,
      overlayEvidence: ["contract gate"],
      diagnostics: [{ status: "hold", field: "security", message: "Security evidence required." }],
      nextAction: "Add evidence."
    },
    llmJudge: {
      status: "warning",
      gateEffect: "advisory",
      workItemId: "OPS-TEST",
      providerInvocation: "not-run",
      contextPackage: {
        status: "prepared",
        allowedInputFields: ["requirementsSummary", "testEvidenceResult"]
      },
      result: {
        status: "warning",
        sourceMode: "artifact",
        sourcePath: ".agents/runtime/judge/result.json",
        canClaimLiveIndependentReview: false,
        rationale: "artifact only",
        findings: [{ code: "judge_finding", message: "Judge finding.", sourceRef: "ref.md" }],
        disagreements: [{ code: "judge_disagreement", message: "Judge disagreement.", sourceRef: "ref2.md" }]
      },
      diagnostics: [{ code: "judge_diag", message: "Judge diagnostic." }]
    },
    securityReview: {
      contractStatus: "required",
      activationSource: "packet",
      summaryStatus: "review-required",
      checkedScope: ["package.json"],
      declaredPaths: ["reference/manuals/human/HARNESS_MANUAL.md"],
      blockingErrorFindings: [{ code: "secret_error", message: "Secret finding." }],
      warningFindings: [{ code: "artifact_warning", message: "Artifact warning." }],
      reviewRequiredCategories: [{ label: "Secret review", reviewNote: "Human review required." }],
      operatorNextActions: ["Ask security reviewer."],
      humanReviewStillRequired: ["Final human review."],
      outOfScopeNote: "No deployment.",
      dependencyInventory: {
        packages: [
          {
            packageLabel: "root",
            packageName: "standard-harness-starter",
            nodeEngine: ">=24.0.0",
            directDependencies: ["fastify"],
            directDevDependencies: ["typescript"],
            releaseScripts: ["package:release"]
          }
        ]
      },
      localSecretScan: {
        scannedPaths: ["package.json"],
        scanRuleCount: 2,
        findingCount: 1
      },
      releaseArtifactAudit: {
        checkedArtifacts: [{ path: "installer/install-harness.js" }],
        findingCount: 1
      }
    },
    traceSummary: {
      path: ".agents/runtime/agent-traces/OPS-TEST.json",
      workItemId: "OPS-TEST",
      packetId: "OPS-TEST",
      turnClosedAt: "2026-06-19T00:01:00.000Z",
      semanticTraceStatus: "warning",
      warningCount: 1,
      workflowDisciplineStatus: "warning",
      workflowDisciplineWarningCount: 2,
      workflowDisciplineCloseoutHoldCount: 1,
      workflowDisciplineHardErrorCount: 0
    },
    candidateGates: [{ id: "required-evidence-present", phase: "candidate-only", description: "Evidence exists." }]
  };

  const expected = `# Validation Report

## Summary
- Executed at: 2026-06-19T00:00:00.000Z
- Validator version: v-test
- Cutover ready: no
- Gate decision: hold
- Next action: Review evidence.
- Scope: harness structural/state validation and workflow evidence consistency only; this is not product/feature verification approval.
- Product evidence owner: Tester/Reviewer/product-specific acceptance evidence.
- Surface role: persisted gate evidence only, not product acceptance; live re-entry should use \`.agents/runtime/ACTIVE_CONTEXT.json\` and CLI context/status.

## Active Profiles
- Source: .agents/artifacts/ACTIVE_PROFILES.md
- Status: declared
- PRF-X: approved (test profile)

## Risk Classifications
- reference/packets/PKT.md: declared high, derived normal, effective high, requested route strict-path, chosen route strict-path, eligibility rejected, gate effect hold
  - rejection reasons: missing review
  - modeling impact: status required, required yes, diagnostics 2

## Findings
- [warning] sample_warning: Sample warning.

## Context Budget
- Status: warn
- Enforcement: advisory; hard fail: disabled
- Severity: warning; blocking: no; gate effect: advisory-only
- Operator message: Stay lean.
- Work item: OPS-TEST
- Role: developer
- Default read set: files 3/5, tokens 1000/2000
- Fallback-only reads: files 1, triggers large packet
- Overrun rationale: none
- Warning count: 1
- Output budget: summary <= 20 lines, closeout <= 40 lines, history policy summarize

## V2.5 Risk-Adaptive Gate Summary
- Gate effect: blocking
- Lane: standard
- Phase: implementation
- Risk overlays: security
- Read set: 4 files, estimated 1500/2200 tokens
- Context budget status: warn
- Human manual auto-read: no
- Blocking diagnostics: yes
- Overlay evidence:
  - contract gate
- Diagnostics:
  - [hold] security: Security evidence required.
- Next action: Add evidence.

## LLM Judge
- Status: warning
- Gate effect: advisory
- Work item: OPS-TEST
- Provider invocation: not-run
- Context package: prepared
- Allowed input fields: requirementsSummary, testEvidenceResult
- Result status: warning
- Result source: artifact (.agents/runtime/judge/result.json)
- Can claim live independent review: no
- Rationale: artifact only
- Advisory findings: 1
  - judge_finding: Judge finding. (ref.md)
- Advisory disagreements: 1
  - judge_disagreement: Judge disagreement. (ref2.md)
- Diagnostics: 1
  - judge_diag: Judge diagnostic.

## Security Review Summary
- Activation source: packet
- Summary status: review-required
- Checked scope: package.json
- Declared security/release paths: reference/manuals/human/HARNESS_MANUAL.md
- Blocking error findings: 1
  - secret_error: Secret finding.
- Warning findings: 1
  - artifact_warning: Artifact warning.
- Review-required categories:
  - Secret review: Human review required.
- Operator next actions:
  - Ask security reviewer.
- Human review still required:
  - Final human review.
- Out of scope note: No deployment.

## Dependency Inventory
- root: standard-harness-starter / node >=24.0.0
  - direct dependencies: fastify
  - direct devDependencies: typescript
  - release scripts: package:release

## Local Secret Scan
- Scanned paths: 1
- Scan rules: 2
- Findings: 1

## Release Artifact Audit
- Checked artifacts: 1
  - installer/install-harness.js
- Audit findings: 1

## Semantic Trace
- Path: .agents/runtime/agent-traces/OPS-TEST.json
- Work item: OPS-TEST
- Packet: OPS-TEST
- Turn closed at: 2026-06-19T00:01:00.000Z
- Status: warning
- Warning count: 1
- Workflow discipline: warning / warning 2 / closeout hold 1 / hard error 0

## Candidate Gates
- required-evidence-present: candidate-only / Evidence exists.
`;

  assert.equal(buildValidationReportMarkdown(report), expected);
});
