import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";

import { createOperatingStateStore } from "../runtime/state/operating-state-store.js";
import {
  buildSecurityReviewSummary,
  recommendSecurityReviewNextAction
} from "../runtime/state/validation-report/security-summary.js";

function tempRepo(prefix = "validation-report-security-summary-") {
  const repoRoot = fs.mkdtempSync(path.join(os.tmpdir(), prefix));
  fs.mkdirSync(path.join(repoRoot, ".harness"), { recursive: true });
  fs.mkdirSync(path.join(repoRoot, "reference", "manuals", "human"), { recursive: true });
  fs.mkdirSync(path.join(repoRoot, "reference", "packets"), { recursive: true });
  return repoRoot;
}

test("validation report security-summary helper resolves packet scope and audits declared paths", () => {
  const repoRoot = tempRepo();
  const dbPath = path.join(repoRoot, ".harness", "operating_state.sqlite");
  const packetPath = "reference/packets/OPS-SEC.md";
  const manualPath = "reference/manuals/human/HARNESS_MANUAL.md";
  let store = null;
  try {
    fs.writeFileSync(
      path.join(repoRoot, "package.json"),
      JSON.stringify({
        name: "security-summary-fixture",
        engines: { node: ">=24.0.0" },
        dependencies: { fastify: "latest" },
        devDependencies: { typescript: "latest" },
        scripts: { "package:release": "node packaging/build-release-package.js" }
      }, null, 2),
      "utf8"
    );
    fs.writeFileSync(path.join(repoRoot, manualPath), "Security approval granted by local automation.\n", "utf8");
    fs.writeFileSync(
      path.join(repoRoot, packetPath),
      [
        "# OPS Security Packet",
        "",
        "- Security review evidence status: requested",
        "- Security review evidence scope: package manifests, declared security/release paths",
        `- Declared security/release paths: ${manualPath}`,
        ""
      ].join("\n"),
      "utf8"
    );

    store = createOperatingStateStore({ dbPath });
    store.upsertWorkItem({
      workItemId: "OPS-SEC",
      title: "Security summary",
      owner: "developer",
      status: "in_progress",
      sourceRef: packetPath,
      nextAction: "validate security summary",
      metadata: {}
    });

    const result = buildSecurityReviewSummary({ store, repoRoot, findings: [] });

    assert.equal(result.summary.contractStatus, "requested");
    assert.equal(result.summary.activationSource, "packet metadata");
    assert.deepEqual(result.summary.checkedScope, ["package manifests", "declared security/release paths"]);
    assert.deepEqual(result.summary.declaredPaths, [manualPath]);
    assert.equal(result.summary.dependencyInventory.packages[0].packageLabel, "root");
    assert.equal(result.summary.dependencyInventory.packages[0].releaseScripts[0], "package:release");
    assert.equal(result.summary.releaseArtifactAudit.checkedArtifacts[0].path, manualPath);
    assert(result.summary.warningFindings.some((finding) => finding.code === "release_artifact_security_approval_claim"));
  } finally {
    store?.close();
    fs.rmSync(repoRoot, { recursive: true, force: true });
  }
});

test("validation report security-summary helper recommends the first blocking recovery before fallback", () => {
  const nextAction = recommendSecurityReviewNextAction({
    fallback: "fallback action",
    findings: [
      { severity: "warning", recovery: "warning recovery" },
      { severity: "error", recovery: "error recovery" }
    ]
  });

  assert.equal(nextAction, "error recovery");
});
