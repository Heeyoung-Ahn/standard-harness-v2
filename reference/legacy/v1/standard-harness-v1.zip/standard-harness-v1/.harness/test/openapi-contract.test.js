import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";

import {
  buildOpenApiContract,
  extractCatalogRoutes,
  extractSourceRoutes,
  validateOpenApiParity,
  scanOpenApiForSecrets
} from "../runtime/state/openapi-contract.js";

function tempRepo() {
  const repoRoot = fs.mkdtempSync(path.join(os.tmpdir(), "finbi-openapi-"));
  fs.mkdirSync(path.join(repoRoot, "reference", "artifacts"), { recursive: true });
  fs.mkdirSync(path.join(repoRoot, "apps", "api", "src"), { recursive: true });
  return repoRoot;
}

function writeFixture(repoRoot, { catalogRows, sourceRoutes }) {
  const table = [
    "| Method | Path | Purpose | Request | Response | Auth / Permission | Primary errors | Audit event | Owner packet | Test path |",
    "|---|---|---|---|---|---|---|---|---|---|",
    ...catalogRows.map((route) =>
      `| ${route.method} | \`${route.path}\` | ${route.purpose ?? "Purpose"} | none | ok | ${route.auth ?? "public"} | ${route.errors ?? "none"} | ${route.audit ?? "none"} | ${route.owner ?? "PKT"} | ${route.test ?? "tests/product/api-platform.test.mjs"} |`
    )
  ].join("\n");
  fs.writeFileSync(path.join(repoRoot, "reference", "artifacts", "API_CATALOG.md"), `# API Catalog\n\n${table}\n`, "utf8");
  fs.writeFileSync(
    path.join(repoRoot, "apps", "api", "src", "server.ts"),
    ["export function register(app) {", ...sourceRoutes.map((route) => `  app.${route.method.toLowerCase()}("${route.path}", async () => {});`), "}"].join("\n"),
    "utf8"
  );
}

test("extracts normalized source and catalog routes", () => {
  const repoRoot = tempRepo();
  try {
    writeFixture(repoRoot, {
      catalogRows: [{ method: "GET", path: "/health" }, { method: "GET", path: "/api/reports/:reportSlug" }],
      sourceRoutes: [{ method: "GET", path: "/health" }, { method: "GET", path: "/api/reports/:reportSlug" }]
    });

    assert.deepEqual(extractCatalogRoutes({ repoRoot }).map((route) => `${route.method} ${route.path}`), [
      "GET /health",
      "GET /api/reports/:reportSlug"
    ]);
    assert.deepEqual(extractSourceRoutes({ repoRoot }).map((route) => `${route.method} ${route.path}`), [
      "GET /health",
      "GET /api/reports/:reportSlug"
    ]);
  } finally {
    fs.rmSync(repoRoot, { recursive: true, force: true });
  }
});

test("builds deterministic OpenAPI and validates source/catalog/openapi parity", () => {
  const repoRoot = tempRepo();
  try {
    writeFixture(repoRoot, {
      catalogRows: [{ method: "GET", path: "/health", purpose: "Runtime health" }, { method: "POST", path: "/api/export", auth: "authenticated" }],
      sourceRoutes: [{ method: "GET", path: "/health" }, { method: "POST", path: "/api/export" }]
    });

    const built = buildOpenApiContract({ repoRoot, write: true });
    assert.equal(built.ok, true);
    assert.equal(built.routeCounts.source, 2);
    assert.equal(built.routeCounts.catalog, 2);
    assert.equal(built.routeCounts.openapi, 2);
    assert.equal(fs.existsSync(path.join(repoRoot, "reference", "api", "openapi.json")), true);

    const validated = validateOpenApiParity({ repoRoot });
    assert.equal(validated.ok, true);
    assert.deepEqual(validated.diagnostics, []);
  } finally {
    fs.rmSync(repoRoot, { recursive: true, force: true });
  }
});

test("blocks source route missing from catalog and OpenAPI", () => {
  const repoRoot = tempRepo();
  try {
    writeFixture(repoRoot, {
      catalogRows: [{ method: "GET", path: "/health" }],
      sourceRoutes: [{ method: "GET", path: "/health" }, { method: "GET", path: "/api/missing" }]
    });
    buildOpenApiContract({ repoRoot, write: true });
    const result = validateOpenApiParity({ repoRoot });
    assert.equal(result.ok, false);
    assert(result.diagnostics.some((diagnostic) => diagnostic.code === "source_route_missing_from_catalog"));
    assert(result.diagnostics.some((diagnostic) => diagnostic.code === "source_route_missing_from_openapi"));
  } finally {
    fs.rmSync(repoRoot, { recursive: true, force: true });
  }
});

test("blocks catalog route missing from OpenAPI and catalog route absent from source", () => {
  const repoRoot = tempRepo();
  try {
    writeFixture(repoRoot, {
      catalogRows: [{ method: "GET", path: "/health" }, { method: "DELETE", path: "/api/ghost/:id" }],
      sourceRoutes: [{ method: "GET", path: "/health" }]
    });
    fs.mkdirSync(path.join(repoRoot, "reference", "api"), { recursive: true });
    fs.writeFileSync(
      path.join(repoRoot, "reference", "api", "openapi.json"),
      JSON.stringify({ openapi: "3.1.0", info: { title: "x", version: "0" }, paths: { "/health": { get: { responses: { 200: { description: "OK" } } } } } }, null, 2),
      "utf8"
    );
    const result = validateOpenApiParity({ repoRoot });
    assert.equal(result.ok, false);
    assert(result.diagnostics.some((diagnostic) => diagnostic.code === "catalog_route_missing_from_openapi"));
    assert(result.diagnostics.some((diagnostic) => diagnostic.code === "catalog_route_absent_from_source"));
  } finally {
    fs.rmSync(repoRoot, { recursive: true, force: true });
  }
});

test("blocks OpenAPI extra route, method mismatch, and parameter normalization mismatch", () => {
  const repoRoot = tempRepo();
  try {
    writeFixture(repoRoot, {
      catalogRows: [{ method: "GET", path: "/api/reports/:reportSlug" }],
      sourceRoutes: [{ method: "POST", path: "/api/reports/:reportSlug" }]
    });
    fs.mkdirSync(path.join(repoRoot, "reference", "api"), { recursive: true });
    fs.writeFileSync(
      path.join(repoRoot, "reference", "api", "openapi.json"),
      JSON.stringify(
        {
          openapi: "3.1.0",
          info: { title: "x", version: "0" },
          paths: {
            "/api/reports/{slug}": { get: { responses: { 200: { description: "OK" } } } },
            "/api/extra": { get: { responses: { 200: { description: "OK" } } } }
          }
        },
        null,
        2
      ),
      "utf8"
    );
    const result = validateOpenApiParity({ repoRoot });
    assert.equal(result.ok, false);
    assert(result.diagnostics.some((diagnostic) => diagnostic.code === "method_mismatch"));
    assert(result.diagnostics.some((diagnostic) => diagnostic.code === "path_parameter_normalization_mismatch"));
    assert(result.diagnostics.some((diagnostic) => diagnostic.code === "openapi_extra_route"));
  } finally {
    fs.rmSync(repoRoot, { recursive: true, force: true });
  }
});

test("secret scan allows schema keys but blocks example-like live secret values", () => {
  const openapi = {
    paths: {
      "/api/admin/users": {
        post: {
          responses: {
            201: {
              description: "Created",
              content: {
                "application/json": {
                  schema: {
                    properties: {
                      temporaryPassword: { type: "string" }
                    }
                  },
                  example: {
                    temporaryPassword: "tmp-real-secret-123"
                  }
                }
              }
            }
          }
        }
      }
    }
  };
  const result = scanOpenApiForSecrets({ openapi });
  assert.equal(result.ok, false);
  assert(result.diagnostics.some((diagnostic) => diagnostic.code === "openapi_secret_like_example_value"));
});
