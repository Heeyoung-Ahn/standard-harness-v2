import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";

import { buildCodexReadinessDashboard } from "../runtime/state/codex-ready-dashboard.js";
import { createOperatingStateStore } from "../runtime/state/operating-state-store.js";

function copyMinimalRepo() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "codex-ready-"));
  fs.mkdirSync(path.join(dir, ".codex-plugin"), { recursive: true });
  fs.mkdirSync(path.join(dir, ".agents", "ssot"), { recursive: true });
  fs.mkdirSync(path.join(dir, "reference", "reviewer-profiles"), { recursive: true });
  fs.writeFileSync(path.join(dir, ".codex-plugin", "plugin.json"), JSON.stringify({ name: "standard-harness", version: "2.6.0", description: "x", skills: "./.agents/skills/", interface: { category: "Coding", capabilities: ["Interactive", "Read", "Write"], defaultPrompt: ["x"] } }), "utf8");
  fs.writeFileSync(path.join(dir, ".agents", "ssot", "AI_OPERATING_CONTRACT.md"), "# ssot\n", "utf8");
  fs.writeFileSync(path.join(dir, "reference", "reviewer-profiles", "REVIEWER_PROFILE_INDEX.json"), JSON.stringify({ default_reviewers: ["correctness"], lane_reviewers: { standard: ["correctness"] }, profile_reviewers: {} }), "utf8");
  fs.writeFileSync(path.join(dir, "reference", "reviewer-profiles", "correctness.md"), "# Correctness\n", "utf8");
  return dir;
}

test("codex readiness holds on starter without active packet", () => {
  const dir = copyMinimalRepo();
  try {
    const result = buildCodexReadinessDashboard({ repoRoot: dir });
    assert.equal(result.verdict, "HOLD");
    assert(result.gates.some((gate) => gate.gate === "Active packet" && gate.status === "FAIL"));
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("codex readiness holds when initialized kickoff still has open decisions", () => {
  const dir = copyMinimalRepo();
  try {
    fs.mkdirSync(path.join(dir, ".agents", "runtime"), { recursive: true });
    fs.writeFileSync(path.join(dir, ".agents", "runtime", "ACTIVE_CONTEXT.json"), JSON.stringify({ ok: true }), "utf8");
    const dbPath = path.join(dir, ".harness", "operating_state.sqlite");
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
    const store = createOperatingStateStore({ dbPath });
    try {
      store.recordDecision({
        decisionId: "DEC-INIT-01",
        title: "Approve kickoff baseline",
        decisionNeeded: true,
        impactSummary: "Implementation cannot begin before this is closed.",
        status: "open",
        sourceRef: ".agents/artifacts/REQUIREMENTS.md"
      });
    } finally {
      store.close();
    }

    const result = buildCodexReadinessDashboard({ repoRoot: dir });
    assert.equal(result.verdict, "HOLD");
    assert.equal(result.ok, false);
    assert(result.gates.some((gate) => gate.gate === "Active packet" && gate.status === "FAIL"));
    assert(result.gates.some((gate) => gate.gate === "Workflow decisions" && gate.status === "FAIL"));
    assert.equal(result.reason, "active_context_active_task_missing");
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("codex readiness holds when active context has no active task", () => {
  const dir = copyMinimalRepo();
  try {
    fs.mkdirSync(path.join(dir, ".agents", "runtime"), { recursive: true });
    fs.writeFileSync(
      path.join(dir, ".agents", "runtime", "ACTIVE_CONTEXT.json"),
      JSON.stringify({ activeTask: null }),
      "utf8"
    );

    const result = buildCodexReadinessDashboard({ repoRoot: dir });
    const activePacketGate = result.gates.find((gate) => gate.gate === "Active packet");
    assert.equal(result.verdict, "HOLD");
    assert.equal(activePacketGate?.status, "FAIL");
    assert.equal(activePacketGate?.blocker, "active_context_active_task_missing");
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("codex readiness passes active packet gate from active task source ref", () => {
  const dir = copyMinimalRepo();
  try {
    fs.mkdirSync(path.join(dir, ".agents", "runtime"), { recursive: true });
    fs.writeFileSync(
      path.join(dir, ".agents", "runtime", "ACTIVE_CONTEXT.json"),
      JSON.stringify({
        activeTask: {
          workItemId: "OPS-07",
          sourceRef: "reference/packets/OPS-07.md"
        }
      }),
      "utf8"
    );

    const result = buildCodexReadinessDashboard({ repoRoot: dir });
    const activePacketGate = result.gates.find((gate) => gate.gate === "Active packet");
    assert.equal(activePacketGate?.status, "PASS");
    assert.equal(result.packet, "reference/packets/OPS-07.md");
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("codex readiness holds when active packet fails packet preflight challenge gate", () => {
  const dir = copyMinimalRepo();
  try {
    const packetPath = "reference/packets/OPS-07.md";
    fs.mkdirSync(path.join(dir, ".agents", "runtime"), { recursive: true });
    fs.mkdirSync(path.join(dir, "reference", "packets"), { recursive: true });
    fs.writeFileSync(
      path.join(dir, ".agents", "runtime", "ACTIVE_CONTEXT.json"),
      JSON.stringify({
        activeTask: {
          workItemId: "OPS-07",
          sourceRef: packetPath
        }
      }),
      "utf8"
    );
    fs.writeFileSync(
      path.join(dir, packetPath),
      [
        "# OPS-07",
        "",
        "## Quick Decision Header",
        "| Item | Proposed | Why | Status |",
        "|---|---|---|---|",
        "| Work item | OPS-07 | Test | approved |",
        "| Ready For Code | approved | Test | approved |",
        "| Gate profile | contract | Test | approved |",
        "| Risk if started now | high | Test | approved |",
        "| Route class | strict-path | Test | approved |",
        "| Change zone | core | Test | approved |",
        "",
        "## Scope",
        "- security/auth runtime behavior must stay visible.",
        "",
        "## Modeling Impact",
        "- Modeling impact status: required",
        "- Critical User Journey: operator approves a packet and preflight protects implementation transition.",
        "- API contract: packet-preflight diagnostic contract only.",
        "- Component responsibility: packet-preflight owns stage-aware challenge checks.",
        "- Allowed dependency direction: runtime helper reads packet markdown only.",
        "- Data ownership: packet-local markdown owns challenge evidence.",
        "- Public contract vs internal/scratch field: Modeling Impact fields are public packet contract.",
        "- Promoted modeling artifact: not-needed",
        "- Not-needed rationale: not-needed because packet-local fields are present.",
        "- Changed-file / classification evidence: test fixture core route",
        "",
        "## Planner Packet Challenge Review",
        "- Challenge reviewer: independent planning reviewer",
        "- Challenge reviewer independence basis: reviewer is separate from the packet author.",
        "- Source refs reviewed: active packet and parent objective.",
        "- Challenge status: pass",
        "- Parent objective coverage: closes security-sensitive packet transition guard.",
        "- Deferred scope with named follow-up: none",
        "- Acceptance proves behavior change: implementation-transition blocks missing challenge evidence.",
        "- Failure fixture or failure condition: missing two-reviewer security challenge blocks.",
        "- Reviewer closeout hold basis: hold if required challenge evidence is absent.",
        "- First-wave limit check: not objective avoidance.",
        "- Guidance-only sufficiency rationale: runtime guard included.",
        "- Challenge evidence artifact path: packet-local challenge ledger.",
        "- Findings disposition: no findings remain.",
        "- Required corrections applied: applied.",
        "- No self-approval claim: independent reviewer, not self."
      ].join("\n"),
      "utf8"
    );

    const result = buildCodexReadinessDashboard({ repoRoot: dir });
    const preflightGate = result.gates.find((gate) => gate.gate === "Packet preflight");
    assert.equal(result.verdict, "HOLD");
    assert.equal(preflightGate?.status, "FAIL");
    assert.match(preflightGate?.blocker ?? "", /two separate subagents|two independent challenge reviewers/i);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("codex readiness holds on corrupt active context with parse diagnostic", () => {
  const dir = copyMinimalRepo();
  try {
    fs.mkdirSync(path.join(dir, ".agents", "runtime"), { recursive: true });
    fs.writeFileSync(path.join(dir, ".agents", "runtime", "ACTIVE_CONTEXT.json"), "{", "utf8");

    const result = buildCodexReadinessDashboard({ repoRoot: dir });
    const activePacketGate = result.gates.find((gate) => gate.gate === "Active packet");
    assert.equal(result.verdict, "HOLD");
    assert.equal(activePacketGate?.status, "FAIL");
    assert.equal(activePacketGate?.blocker, "active_context_parse_failed");
    assert.match(activePacketGate?.nextAction ?? "", /harness:context -- --repair/);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("codex readiness reports stale active context projection with repair guidance", () => {
  const dir = copyMinimalRepo();
  try {
    const runtimeDir = path.join(dir, ".agents", "runtime");
    fs.mkdirSync(runtimeDir, { recursive: true });
    const jsonPath = path.join(runtimeDir, "ACTIVE_CONTEXT.json");
    const briefPath = path.join(runtimeDir, "ACTIVE_CONTEXT.brief.md");
    const docRoutePath = path.join(runtimeDir, "DOC_ROUTE.json");
    fs.writeFileSync(
      jsonPath,
      JSON.stringify({
        activeTask: {
          workItemId: "OPS-07",
          sourceRef: "reference/packets/OPS-07.md"
        }
      }),
      "utf8"
    );
    fs.writeFileSync(briefPath, "# stale\n", "utf8");
    fs.writeFileSync(docRoutePath, "{}\n", "utf8");
    const oldTime = new Date("2026-06-18T00:00:00.000Z");
    const newTime = new Date("2026-06-19T00:00:00.000Z");
    fs.utimesSync(briefPath, oldTime, oldTime);
    fs.utimesSync(docRoutePath, oldTime, oldTime);
    fs.utimesSync(jsonPath, newTime, newTime);

    const result = buildCodexReadinessDashboard({ repoRoot: dir });
    const projectionGate = result.gates.find((gate) => gate.gate === "Active context projection");
    assert.equal(projectionGate?.status, "WARN");
    assert.match(projectionGate?.blocker ?? "", /ACTIVE_CONTEXT\.brief\.md older than ACTIVE_CONTEXT\.json/);
    assert.match(projectionGate?.blocker ?? "", /DOC_ROUTE\.json older than ACTIVE_CONTEXT\.json/);
    assert.equal(projectionGate?.nextAction, "npm run harness:context -- --repair");
    assert.equal(result.activeContextProjection.status, "STALE");
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
