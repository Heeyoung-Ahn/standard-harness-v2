import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";

import {
  buildArtifactMigrationAudit,
  runArtifactMigrationAuditCommand
} from "../runtime/state/artifact-migration-audit.js";

function makeRepo() {
  return fs.mkdtempSync(path.join(os.tmpdir(), "artifact-migration-audit-"));
}

function write(repoRoot, relativePath, content = "") {
  const absolutePath = path.join(repoRoot, relativePath);
  fs.mkdirSync(path.dirname(absolutePath), { recursive: true });
  fs.writeFileSync(absolutePath, content, "utf8");
}

test("artifact migration audit classifies packet, report, packet-local evidence, and generated read models", () => {
  const repoRoot = makeRepo();
  write(repoRoot, "reference/packets/PKT-1.md", "# PKT-1\n");
  write(repoRoot, "reference/packets/PKT-1/08_evidence/EVIDENCE.md", "# Evidence\n");
  write(repoRoot, "reference/reports/planner/PKT-1_REVIEW.md", "# Review\n");
  write(repoRoot, ".agents/runtime/generated-state-docs/CURRENT_STATE.md", "# Generated\n");

  const audit = buildArtifactMigrationAudit({ repoRoot, workItemId: "PKT-1" });

  const byPath = new Map(audit.artifacts.map((artifact) => [artifact.current_path, artifact]));
  assert.equal(byPath.get("reference/packets/PKT-1.md").classification, "legacy_flat_packet");
  assert.equal(byPath.get("reference/packets/PKT-1/08_evidence/EVIDENCE.md").classification, "packet_local_evidence");
  assert.equal(byPath.get("reference/reports/planner/PKT-1_REVIEW.md").classification, "legacy_report_root_leftover");
  assert.equal(byPath.get(".agents/runtime/generated-state-docs/CURRENT_STATE.md").classification, "generated_read_model");
  assert.equal(byPath.get(".agents/runtime/generated-state-docs/CURRENT_STATE.md").proposed_target_path, null);
});

test("artifact migration audit detects cited-by references before apply readiness", () => {
  const repoRoot = makeRepo();
  write(repoRoot, "reference/reports/planner/PKT-1_REVIEW.md", "# Review\n");
  write(repoRoot, "reference/packets/PKT-1.md", "See reference/reports/planner/PKT-1_REVIEW.md\n");

  const audit = buildArtifactMigrationAudit({ repoRoot, workItemId: "PKT-1" });
  const report = audit.artifacts.find((artifact) => artifact.current_path === "reference/reports/planner/PKT-1_REVIEW.md");

  assert.deepEqual(report.cited_by, ["reference/packets/PKT-1.md"]);
  assert.equal(report.approval_state, "blocked-or-retain");
});

test("artifact migration audit blocks target collisions", () => {
  const repoRoot = makeRepo();
  write(repoRoot, "reference/reports/planner/PKT-1_REVIEW.md", "# Review\n");
  write(repoRoot, "reference/packets/PKT-1/99_superseded/reference_reports_planner_PKT-1_REVIEW.md", "# Existing\n");

  const audit = buildArtifactMigrationAudit({ repoRoot, workItemId: "PKT-1" });
  const collision = audit.findings.find((finding) => finding.code === "migration_target_collision");

  assert.ok(collision);
  assert.equal(collision.artifact, "reference/reports/planner/PKT-1_REVIEW.md");
});

test("artifact migration audit command writes only packet-local audit evidence with apply", () => {
  const repoRoot = makeRepo();
  write(repoRoot, "reference/packets/PKT-1.md", "# PKT-1\n");
  write(repoRoot, "reference/reports/planner/PKT-1_REVIEW.md", "# Review\n");

  const result = runArtifactMigrationAuditCommand({
    repoRoot,
    args: ["--work-item", "PKT-1", "--packet", "reference/packets/PKT-1.md", "--apply"]
  });

  assert.equal(result.ok, true);
  assert.equal(fs.existsSync(path.join(repoRoot, "reference/reports/planner/PKT-1_REVIEW.md")), true);
  assert.equal(fs.existsSync(path.join(repoRoot, "reference/packets/PKT-1/08_evidence/ARTIFACT_MIGRATION_AUDIT.json")), true);
  assert.equal(fs.existsSync(path.join(repoRoot, "reference/packets/PKT-1/08_evidence/ARTIFACT_MIGRATION_AUDIT.md")), true);
});
