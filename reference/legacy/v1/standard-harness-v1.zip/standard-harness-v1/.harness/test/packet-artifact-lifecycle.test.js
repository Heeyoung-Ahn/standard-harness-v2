import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";

import {
  runPacketArtifactInitCommand,
  runPacketArtifactValidateCommand
} from "../runtime/state/packet-artifact-lifecycle.js";
import { runPacketPreflightCommand } from "../runtime/state/packet-preflight.js";
import { createOperatingStateStore } from "../runtime/state/operating-state-store.js";
import { seedStandardRepo } from "./dev05-test-helpers.js";

function createRepo() {
  const repoRoot = fs.mkdtempSync(path.join(os.tmpdir(), "packet-artifact-lifecycle-"));
  seedStandardRepo(repoRoot);
  const dbPath = path.join(repoRoot, ".harness", "operating_state.sqlite");
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  return { repoRoot, dbPath };
}

function registerWorkItem(dbPath, packetPath) {
  const store = createOperatingStateStore({ dbPath });
  try {
    store.upsertWorkItem({
      workItemId: "OPS-LIFE-01",
      title: "Packet lifecycle fixture",
      status: "in_progress",
      owner: "developer",
      nextAction: "Implement packet artifact lifecycle.",
      sourceRef: packetPath,
      metadata: {
        readyForCode: "approved",
        gateProfile: "contract",
        deliveryRouteMode: "orchestrated-closeout",
        routeClass: "strict-path"
      }
    });
  } finally {
    store.close();
  }
}

function writeLifecyclePacket(repoRoot, packetPath, { closeout = true } = {}) {
  const closeoutSection = closeout
    ? [
        "",
        "## 15. Packet Exit Quality Gate",
        "- Packet exit metadata version: v1",
        "- Packet exit metadata gate reference: reference/artifacts/PACKET_EXIT_QUALITY_GATE.md",
        "- Packet exit metadata exit recommendation: approved",
        "- Packet exit metadata source parity result: pass",
        "- Packet exit metadata validation / security / cleanup evidence: pass",
        "- Packet exit quality gate reference: reference/artifacts/PACKET_EXIT_QUALITY_GATE.md",
        "- Exit recommendation: approved",
        "- Source parity result: pass",
        "- Validation / security / cleanup evidence: pass"
      ].join("\n")
    : "";
  const absolutePacketPath = path.join(repoRoot, packetPath);
  fs.mkdirSync(path.dirname(absolutePacketPath), { recursive: true });
  fs.writeFileSync(
    absolutePacketPath,
    [
      "# OPS-LIFE-01 Packet Lifecycle Fixture",
      "",
      "## Quick Decision Header",
      "| Item | Proposed | Why | Status |",
      "|---|---|---|---|",
      "| Work item | OPS-LIFE-01 | Test packet lifecycle | approved |",
      "| Ready For Code | approved | Test fixture | approved |",
      "| Gate profile | contract | Runtime contract | approved |",
      "| Risk if started now | proceed-with-guardrails | Test fixture | approved |",
      "| Delivery route mode | orchestrated-closeout | Test fixture | approved |",
      "| Route class | strict-path | Test fixture | approved |",
      "| Change zone | core | Test fixture | approved |",
      "| Layer classification | core | Test fixture | approved |",
      "| User-facing impact | none | Test fixture | not-needed |",
      "| Domain foundation status | approved | Test fixture | approved |",
      "| Authoritative source intake status | approved | Test fixture | approved |",
      "| Shared-source wave status | not-needed | Test fixture | not-needed |",
      "| Packet artifact lifecycle | declared | Test fixture | approved |",
      "| Packet exit gate status | approved | Closeout fixture | approved |",
      "",
      "## Modeling Impact",
      "- Modeling impact status: required",
      "- Critical User Journey: lifecycle packet stores replayable evidence.",
      "- API contract: packet-artifact-init and packet-preflight lifecycle checks.",
      "- Component responsibility: packet lifecycle helper owns manifest scaffold and validator.",
      "- Allowed dependency direction: preflight reads packet and manifest only.",
      "- Data ownership: packet manifest owns packet-local evidence index.",
      "- Public contract vs internal/scratch field: manifest fields are public harness contract.",
      "- Promoted modeling artifact: not-needed",
      "- Not-needed rationale: packet-local model is enough for fixture.",
      "- Changed-file / classification evidence: .harness runtime helper",
      "",
      "## Verification Manifest",
      "- Ready For Code: approved",
      "- targeted: packet artifact lifecycle tests",
      "- validator: harness validator pass",
      "- active context: regenerated",
      "- review closeout: required",
      "",
      "## Planner Packet Challenge Review",
      "- Challenge reviewer: lifecycle-a; lifecycle-b",
      "- Challenge reviewer independence basis: fixture reviewers are separate from packet author.",
      "- Source refs reviewed: packet and lifecycle manifest.",
      "- Challenge status: pass",
      "- Parent objective coverage: closes lifecycle scaffold and manifest validation.",
      "- Deferred scope with named follow-up: none",
      "- Acceptance proves behavior change: missing manifest blocks closeout.",
      "- Failure fixture or failure condition: missing replay field blocks closeout.",
      "- Reviewer closeout hold basis: hold if manifest validation fails.",
      "- First-wave limit check: fixture scope is packet lifecycle helper only.",
      "- Guidance-only sufficiency rationale: runtime validator is implemented.",
      "- Challenge evidence artifact path: packet lifecycle test fixture.",
      "- Findings disposition: no findings remain.",
      "- Required corrections applied: not-needed.",
      "- No self-approval claim: independent fixture reviewers.",
      closeoutSection
    ].join("\n"),
    "utf8"
  );
}

test("packet-artifact-init creates packet lifecycle directories and replay manifest", () => {
  const { repoRoot } = createRepo();
  const packetPath = "reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md";
  writeLifecyclePacket(repoRoot, packetPath, { closeout: false });

  const result = runPacketArtifactInitCommand({
    repoRoot,
    args: ["--packet", packetPath, "--work-item", "OPS-LIFE-01", "--apply"]
  });

  assert.equal(result.ok, true);
  assert.equal(result.apply, true);
  assert.equal(result.packetId, "OPS-LIFE-01");
  assert.equal(result.canonicalPacketPath, packetPath);
  assert.equal(result.manifestPath, "reference/packets/OPS-LIFE-01/PACKET_MANIFEST.md");
  for (const phase of ["00_packet", "01_planning", "02_design", "03_implementation", "04_testing", "05_review", "06_security", "07_closeout", "08_evidence", "90_interim", "99_superseded"]) {
    assert.equal(fs.existsSync(path.join(repoRoot, "reference", "packets", "OPS-LIFE-01", phase)), true, phase);
  }
  const manifest = fs.readFileSync(path.join(repoRoot, result.manifestPath), "utf8");
  assert.match(manifest, /packet_artifact_lifecycle: declared/);
  assert.match(manifest, /path: reference\/packets\/OPS-LIFE-01\/00_packet\/OPS-LIFE-01\.md/);
  assert.match(manifest, /authority_type: governance_truth/);
  assert.match(manifest, /canonical_role: canonical/);
  assert.match(manifest, /source_refs:/);
  assert.match(manifest, /decision_refs:/);
  assert.match(manifest, /closeout_refs:/);
});

test("packet-artifact-init preserves underscore packet ids", () => {
  const { repoRoot } = createRepo();
  const packetPath = "reference/packets/OPS-LIFE-01_PACKET_SCOPE/00_packet/OPS-LIFE-01_PACKET_SCOPE.md";
  writeLifecyclePacket(repoRoot, packetPath, { closeout: false });

  const result = runPacketArtifactInitCommand({
    repoRoot,
    args: ["--packet", packetPath, "--work-item", "OPS-LIFE-01_PACKET_SCOPE", "--apply"]
  });

  assert.equal(result.ok, true);
  assert.equal(result.packetId, "OPS-LIFE-01_PACKET_SCOPE");
  assert.equal(result.manifestPath, "reference/packets/OPS-LIFE-01_PACKET_SCOPE/PACKET_MANIFEST.md");
  assert.equal(fs.existsSync(path.join(repoRoot, result.manifestPath)), true);
});

test("packet-artifact validate fails missing or unresolved packet input", () => {
  const { repoRoot } = createRepo();

  const missing = runPacketArtifactValidateCommand({ repoRoot, args: [] });
  assert.equal(missing.ok, false);
  assert.match(missing.errors.join("\n"), /Missing --packet/);

  const unresolved = runPacketArtifactValidateCommand({
    repoRoot,
    args: ["--packet", "OPS-LIFE-MISSING"]
  });
  assert.equal(unresolved.ok, false);
  assert.match(unresolved.errors.join("\n"), /Packet file not found: OPS-LIFE-MISSING/);
});

test("packet-artifact validate resolves packet ids to canonical packet markdown and manifest declaration", () => {
  const { repoRoot } = createRepo();
  const packetPath = "reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md";
  writeLifecyclePacket(repoRoot, packetPath, { closeout: false });
  runPacketArtifactInitCommand({
    repoRoot,
    args: ["--packet", packetPath, "--work-item", "OPS-LIFE-01", "--apply"]
  });
  const packetWithoutLifecycleHeader = fs.readFileSync(path.join(repoRoot, packetPath), "utf8")
    .replace("| Packet artifact lifecycle | declared | Test fixture | approved |\n", "");
  fs.writeFileSync(path.join(repoRoot, packetPath), packetWithoutLifecycleHeader, "utf8");

  const result = runPacketArtifactValidateCommand({
    repoRoot,
    args: ["--packet", "OPS-LIFE-01"],
    stage: "closeout"
  });

  assert.equal(result.ok, true);
  assert.equal(result.packetPath, packetPath);
  assert.equal(result.result.required, true);
  assert.equal(result.result.declared, true);
});

test("packet-preflight blocks declared lifecycle closeout when manifest is missing", () => {
  const { repoRoot, dbPath } = createRepo();
  const packetPath = "reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md";
  writeLifecyclePacket(repoRoot, packetPath);
  registerWorkItem(dbPath, packetPath);

  const result = runPacketPreflightCommand({
    repoRoot,
    dbPath,
    args: ["--work-item", "OPS-LIFE-01", "--stage", "closeout"]
  });

  assert.equal(result.ok, false);
  assert.equal(result.packetArtifactLifecycle.required, true);
  assert(result.packetArtifactLifecycle.diagnostics.some((diagnostic) => diagnostic.code === "packet_artifact_lifecycle_manifest_missing"));
  assert.match(result.errors.join("\n"), /PACKET_MANIFEST/);
});

test("packet-preflight blocks declared lifecycle closeout when manifest lacks replay fields", () => {
  const { repoRoot, dbPath } = createRepo();
  const packetPath = "reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md";
  writeLifecyclePacket(repoRoot, packetPath);
  registerWorkItem(dbPath, packetPath);
  fs.mkdirSync(path.join(repoRoot, "reference", "packets", "OPS-LIFE-01"), { recursive: true });
  fs.writeFileSync(
    path.join(repoRoot, "reference", "packets", "OPS-LIFE-01", "PACKET_MANIFEST.md"),
    [
      "# OPS-LIFE-01 Packet Manifest",
      "",
      "packet_artifact_lifecycle: declared",
      "",
      "- artifact_id: packet",
      "- path: reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md",
      "- status: active",
      "- retention_reason: decision_trace",
      "- owner: Planner"
    ].join("\n"),
    "utf8"
  );

  const result = runPacketPreflightCommand({
    repoRoot,
    dbPath,
    args: ["--work-item", "OPS-LIFE-01", "--stage", "closeout"]
  });

  assert.equal(result.ok, false);
  assert(result.packetArtifactLifecycle.diagnostics.some((diagnostic) => diagnostic.code === "packet_artifact_lifecycle_required_row_field_missing"));
  assert.match(result.errors.join("\n"), /authority_type|source_refs|closeout_relevance/);
});

test("packet-preflight blocks declared lifecycle closeout when phase replay edges are missing", () => {
  const { repoRoot, dbPath } = createRepo();
  const packetPath = "reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md";
  writeLifecyclePacket(repoRoot, packetPath);
  registerWorkItem(dbPath, packetPath);
  runPacketArtifactInitCommand({
    repoRoot,
    args: ["--packet", packetPath, "--work-item", "OPS-LIFE-01", "--apply"]
  });
  fs.appendFileSync(
    path.join(repoRoot, "reference", "packets", "OPS-LIFE-01", "PACKET_MANIFEST.md"),
    [
      "",
      "- artifact_id: implementation-without-edge",
      "- path: reference/packets/OPS-LIFE-01/03_implementation/DEVELOPER_REPORT.md",
      "- phase: 03_implementation",
      "- status: active",
      "- retention_reason: evidence",
      "- owner: Developer",
      "- authority_type: packet_evidence",
      "- canonical_role: canonical",
      "- source_refs: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- decision_refs: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- implementation_refs: [none]",
      "- test_refs: [none]",
      "- review_refs: [none]",
      "- security_refs: [none]",
      "- closeout_refs: [reference/packets/OPS-LIFE-01/03_implementation/DEVELOPER_REPORT.md]",
      "- source_or_superseded_by: none",
      "- cited_by: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- created_or_updated_by: developer",
      "- created_or_updated_at: 2026-06-25T00:00:00.000Z",
      "- closeout_relevance: required",
      ""
    ].join("\n"),
    "utf8"
  );

  const result = runPacketPreflightCommand({
    repoRoot,
    dbPath,
    args: ["--work-item", "OPS-LIFE-01", "--stage", "closeout"]
  });

  assert.equal(result.ok, false);
  assert(result.packetArtifactLifecycle.diagnostics.some((diagnostic) => diagnostic.code === "packet_artifact_lifecycle_phase_replay_edge_missing"));
  assert.match(result.errors.join("\n"), /implementation_refs/);
});

test("packet-preflight blocks stale compatibility pointer rows", () => {
  const { repoRoot, dbPath } = createRepo();
  const packetPath = "reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md";
  writeLifecyclePacket(repoRoot, packetPath);
  registerWorkItem(dbPath, packetPath);
  runPacketArtifactInitCommand({
    repoRoot,
    args: ["--packet", packetPath, "--work-item", "OPS-LIFE-01", "--apply"]
  });
  fs.appendFileSync(
    path.join(repoRoot, "reference", "packets", "OPS-LIFE-01", "PACKET_MANIFEST.md"),
    [
      "",
      "- artifact_id: stale-compatibility-pointer",
      "- path: reference/reports/developer/OPS-LIFE-01.md",
      "- phase: 08_evidence",
      "- status: active",
      "- retention_reason: replay",
      "- owner: Runtime",
      "- authority_type: packet_evidence",
      "- canonical_role: compatibility_pointer",
      "- source_refs: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- decision_refs: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- implementation_refs: [none]",
      "- test_refs: [none]",
      "- review_refs: [none]",
      "- security_refs: [none]",
      "- closeout_refs: [reference/reports/developer/OPS-LIFE-01.md]",
      "- source_or_superseded_by: none",
      "- cited_by: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- created_or_updated_by: runtime",
      "- created_or_updated_at: 2026-06-25T00:00:00.000Z",
      "- closeout_relevance: supporting",
      ""
    ].join("\n"),
    "utf8"
  );

  const result = runPacketPreflightCommand({
    repoRoot,
    dbPath,
    args: ["--work-item", "OPS-LIFE-01", "--stage", "closeout"]
  });

  assert.equal(result.ok, false);
  assert(result.packetArtifactLifecycle.diagnostics.some((diagnostic) => diagnostic.code === "packet_artifact_lifecycle_compatibility_pointer_stale"));
  assert.match(result.errors.join("\n"), /compatibility pointer/);
});

test("packet-preflight blocks migration apply approval without replay references", () => {
  const { repoRoot, dbPath } = createRepo();
  const packetPath = "reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md";
  writeLifecyclePacket(repoRoot, packetPath);
  registerWorkItem(dbPath, packetPath);
  runPacketArtifactInitCommand({
    repoRoot,
    args: ["--packet", packetPath, "--work-item", "OPS-LIFE-01", "--apply"]
  });
  fs.appendFileSync(
    path.join(repoRoot, "reference", "packets", "OPS-LIFE-01", "PACKET_MANIFEST.md"),
    [
      "",
      "- artifact_id: migration-approved-without-refs",
      "- path: reference/packets/OPS-LIFE-01/99_superseded/OLD_REPORT.md",
      "- phase: 99_superseded",
      "- status: active",
      "- retention_reason: superseded_by",
      "- owner: Planner",
      "- authority_type: packet_evidence",
      "- canonical_role: superseded_record",
      "- source_refs: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- decision_refs: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- implementation_refs: [none]",
      "- test_refs: [none]",
      "- review_refs: [none]",
      "- security_refs: [none]",
      "- closeout_refs: [reference/packets/OPS-LIFE-01/99_superseded/OLD_REPORT.md]",
      "- source_or_superseded_by: reference/packets/OPS-LIFE-01/08_evidence/ARTIFACT_INVENTORY_DRY_RUN.md",
      "- cited_by: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- created_or_updated_by: planner",
      "- created_or_updated_at: 2026-06-25T00:00:00.000Z",
      "- closeout_relevance: supporting",
      "- approval_state: approved-to-apply",
      ""
    ].join("\n"),
    "utf8"
  );

  const result = runPacketPreflightCommand({
    repoRoot,
    dbPath,
    args: ["--work-item", "OPS-LIFE-01", "--stage", "closeout"]
  });

  assert.equal(result.ok, false);
  assert(result.packetArtifactLifecycle.diagnostics.some((diagnostic) => diagnostic.code === "packet_artifact_lifecycle_unapproved_migration_apply"));
  assert.match(result.errors.join("\n"), /approval_ref|follow_up_apply_packet_id/);
});

test("packet-preflight blocks PMO authority misuse, duplicate active rows, and dry-run active output", () => {
  const { repoRoot, dbPath } = createRepo();
  const packetPath = "reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md";
  writeLifecyclePacket(repoRoot, packetPath);
  registerWorkItem(dbPath, packetPath);
  runPacketArtifactInitCommand({
    repoRoot,
    args: ["--packet", packetPath, "--work-item", "OPS-LIFE-01", "--apply"]
  });
  fs.appendFileSync(
    path.join(repoRoot, "reference", "packets", "OPS-LIFE-01", "PACKET_MANIFEST.md"),
    [
      "",
      "- artifact_id: pmo-approval-misuse",
      "- path: reference/pmo/day-wrap-up/OPS-LIFE-01.md",
      "- phase: 07_closeout",
      "- status: active",
      "- retention_reason: replay",
      "- owner: Project Manager",
      "- authority_type: governance_truth",
      "- canonical_role: canonical",
      "- source_refs: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- decision_refs: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- implementation_refs: [reference/packets/OPS-LIFE-01/03_implementation/DEVELOPER_REPORT.md]",
      "- test_refs: [reference/packets/OPS-LIFE-01/04_testing/TESTER_REPORT.md]",
      "- review_refs: [reference/packets/OPS-LIFE-01/05_review/REVIEWER_REPORT.md]",
      "- security_refs: [none]",
      "- closeout_refs: [reference/pmo/day-wrap-up/OPS-LIFE-01.md]",
      "- source_or_superseded_by: none",
      "- cited_by: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- created_or_updated_by: project-manager",
      "- created_or_updated_at: 2026-06-25T00:00:00.000Z",
      "- closeout_relevance: required",
      "",
      "- artifact_id: duplicate-active",
      "- path: reference/pmo/day-wrap-up/OPS-LIFE-01.md",
      "- phase: 07_closeout",
      "- status: active",
      "- retention_reason: replay",
      "- owner: Project Manager",
      "- authority_type: packet_evidence",
      "- canonical_role: canonical",
      "- source_refs: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- decision_refs: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- implementation_refs: [reference/packets/OPS-LIFE-01/03_implementation/DEVELOPER_REPORT.md]",
      "- test_refs: [reference/packets/OPS-LIFE-01/04_testing/TESTER_REPORT.md]",
      "- review_refs: [reference/packets/OPS-LIFE-01/05_review/REVIEWER_REPORT.md]",
      "- security_refs: [none]",
      "- closeout_refs: [reference/pmo/day-wrap-up/OPS-LIFE-01.md]",
      "- source_or_superseded_by: none",
      "- cited_by: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- created_or_updated_by: project-manager",
      "- created_or_updated_at: 2026-06-25T00:00:00.000Z",
      "- closeout_relevance: required",
      "",
      "- artifact_id: dry-run-active",
      "- path: reference/packets/OPS-LIFE-01/08_evidence/DRY_RUN_OUTPUT.md",
      "- phase: 08_evidence",
      "- status: active",
      "- retention_reason: replay",
      "- owner: Runtime",
      "- authority_type: packet_evidence",
      "- canonical_role: generated_summary",
      "- source_refs: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- decision_refs: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- implementation_refs: [reference/packets/OPS-LIFE-01/03_implementation/DEVELOPER_REPORT.md]",
      "- test_refs: [reference/packets/OPS-LIFE-01/04_testing/TESTER_REPORT.md]",
      "- review_refs: [reference/packets/OPS-LIFE-01/05_review/REVIEWER_REPORT.md]",
      "- security_refs: [none]",
      "- closeout_refs: [reference/packets/OPS-LIFE-01/08_evidence/DRY_RUN_OUTPUT.md]",
      "- source_or_superseded_by: none",
      "- cited_by: [reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md]",
      "- created_or_updated_by: dry-run",
      "- created_or_updated_at: 2026-06-25T00:00:00.000Z",
      "- closeout_relevance: required",
      "- write_mode: dry-run",
      ""
    ].join("\n"),
    "utf8"
  );

  const result = runPacketPreflightCommand({
    repoRoot,
    dbPath,
    args: ["--work-item", "OPS-LIFE-01", "--stage", "closeout"]
  });

  assert.equal(result.ok, false);
  const codes = result.packetArtifactLifecycle.diagnostics.map((diagnostic) => diagnostic.code);
  assert(codes.includes("packet_artifact_lifecycle_pmo_authority_misuse"));
  assert(codes.includes("packet_artifact_lifecycle_duplicate_active_artifact"));
  assert(codes.includes("packet_artifact_lifecycle_dry_run_write"));
});

test("packet-preflight accepts declared lifecycle closeout with scaffold manifest", () => {
  const { repoRoot, dbPath } = createRepo();
  const packetPath = "reference/packets/OPS-LIFE-01/00_packet/OPS-LIFE-01.md";
  writeLifecyclePacket(repoRoot, packetPath);
  registerWorkItem(dbPath, packetPath);
  runPacketArtifactInitCommand({
    repoRoot,
    args: ["--packet", packetPath, "--work-item", "OPS-LIFE-01", "--apply"]
  });

  const result = runPacketPreflightCommand({
    repoRoot,
    dbPath,
    args: ["--work-item", "OPS-LIFE-01", "--stage", "closeout"]
  });

  assert.equal(result.packetArtifactLifecycle.ok, true);
  assert(!result.errors.some((message) => /packet artifact lifecycle/i.test(message)));
});
