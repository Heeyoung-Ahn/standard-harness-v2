import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";

import { createOperatingStateStore } from "../runtime/state/operating-state-store.js";
import { runProgressSyncCommand } from "../runtime/state/progress-sync.js";
import { seedStandardRepo } from "./dev05-test-helpers.js";

function setupProgressRepo() {
  const repoRoot = fs.mkdtempSync(path.join(os.tmpdir(), "progress-sync-"));
  seedStandardRepo(repoRoot);
  const dbPath = path.join(repoRoot, ".harness", "operating_state.sqlite");
  for (const phase of ["03_implementation", "04_testing", "05_review", "07_closeout"]) {
    fs.mkdirSync(path.join(repoRoot, "reference", "packets", "OPS-HARNESS-04-TRACE-GENERATOR-FOLLOWUP", phase), { recursive: true });
  }
  fs.mkdirSync(path.join(repoRoot, "reference", "packets", "OPS-HARNESS-04-ROLLOUT-FOLLOWUP", "07_closeout"), { recursive: true });
  fs.writeFileSync(
    path.join(repoRoot, ".agents", "artifacts", "PROJECT_PROGRESS.md"),
    [
      "# Project Progress",
      "",
      "## Current Lane",
      "",
      "| Field | Value |",
      "|---|---|",
      "| Active lane | Harness improvement before product implementation resumes |",
      "| Active packet | `OPS-HARNESS-04_ARTIFACT_SYNC_AND_DEVELOPMENT_CATALOGS` |",
      "| Paused product packet | `PKT-APP-01C_CATALOG_PERMISSION_ADMIN_CORE` |",
      "| Next product direction | Resume 01C only after harness follow-ups close |",
      "| Progress source | packets, artifact-sync reports, review reports, test/security evidence |",
      "",
      "## WBS Board",
      "",
      "| Phase | Task ID | Task | Status | Source / Evidence | Notes |",
      "|---|---|---|---|---|---|",
      "| Harness | OPS-HARNESS-04-TRACE-GENERATOR-FOLLOWUP | Trace generator follow-up | in_progress | `reference/packets/OPS-HARNESS-04-TRACE-GENERATOR-FOLLOWUP/00_packet/OPS-HARNESS-04-TRACE-GENERATOR-FOLLOWUP.md` | stale row |",
      "| Harness | OPS-HARNESS-04-ROLLOUT-FOLLOWUP | Rollout follow-up | deferred | `reference/packets/OPS-HARNESS-04-ROLLOUT-FOLLOWUP/00_packet/OPS-HARNESS-04-ROLLOUT-FOLLOWUP.md` | closed without full evidence |",
      "| Product Planning | PKT-APP-01C | Catalog, permission, admin core | paused | `reference/packets/PKT-APP-01C.md` | must stay paused |",
      "| Design / Auth | PKT-APP-01B | Login/user/group/common platform | remediation-needed | `reference/packets/PKT-APP-01B_AUTH_USER_GROUP_CORE/00_packet/PKT-APP-01B_AUTH_USER_GROUP_CORE.md` | must stay visible |",
      "",
      "## Follow-Up Register",
      "",
      "| Follow-up | Trigger | Status |",
      "|---|---|---|",
      "| `OPS-HARNESS-04-TRACE-GENERATOR-FOLLOWUP` | trace matrix automation | deferred |",
      "| `OPS-HARNESS-04-WBS-AUTOMATION-FOLLOWUP` | WBS automation | deferred |",
      "| `OPS-HARNESS-04-ROLLOUT-FOLLOWUP` | rollout automation | deferred |",
      "| `PKT-APP-01B-REMEDIATION` | admin UI and DB runtime gaps | pending decision |"
    ].join("\n"),
    "utf8"
  );
  fs.writeFileSync(
    path.join(repoRoot, ".agents", "runtime", "ACTIVE_CONTEXT.json"),
    JSON.stringify(
      {
        generatedAt: "2026-06-18T08:00:00.000Z",
        activeTask: { workItemId: "OPS-HARNESS-04-TRACE-GENERATOR-FOLLOWUP" },
        nextWork: { owner: "planner" }
      },
      null,
      2
    ),
    "utf8"
  );
  const store = createOperatingStateStore({ dbPath });
  store.upsertWorkItem({
    workItemId: "OPS-HARNESS-04-TRACE-GENERATOR-FOLLOWUP",
    title: "Trace generator follow-up",
    status: "closed",
    owner: "planner",
    sourceRef: "reference/packets/OPS-HARNESS-04-TRACE-GENERATOR-FOLLOWUP/00_packet/OPS-HARNESS-04-TRACE-GENERATOR-FOLLOWUP.md",
    nextAction: "closed"
  });
  store.upsertWorkItem({
    workItemId: "OPS-HARNESS-04-WBS-AUTOMATION-FOLLOWUP",
    title: "WBS automation follow-up",
    status: "in_progress",
    owner: "orchestrator",
    sourceRef: "reference/packets/OPS-HARNESS-04-WBS-AUTOMATION-FOLLOWUP/00_packet/OPS-HARNESS-04-WBS-AUTOMATION-FOLLOWUP.md",
    nextAction: "route delivery"
  });
  store.upsertWorkItem({
    workItemId: "OPS-HARNESS-04-ROLLOUT-FOLLOWUP",
    title: "Rollout follow-up",
    status: "closed",
    owner: "planner",
    sourceRef: "reference/packets/OPS-HARNESS-04-ROLLOUT-FOLLOWUP/00_packet/OPS-HARNESS-04-ROLLOUT-FOLLOWUP.md",
    nextAction: "closed"
  });
  store.close();
  return { repoRoot, dbPath };
}

test("progress-sync detects stale Current Lane, WBS, Follow-Up Register, and generated state without writing", () => {
  const { repoRoot, dbPath } = setupProgressRepo();
  const before = fs.readFileSync(path.join(repoRoot, ".agents", "artifacts", "PROJECT_PROGRESS.md"), "utf8");

  const result = runProgressSyncCommand({ repoRoot, dbPath, args: [] });

  assert.equal(result.ok, false);
  assert.equal(result.write, false);
  assert.deepEqual(
    result.diagnostics.map((diagnostic) => diagnostic.code).sort(),
    [
      "active-context-stale",
      "closed-work-item-missing-closeout-evidence",
      "current-lane-active-packet-stale",
      "followup-status-stale",
      "followup-status-stale",
      "wbs-status-stale"
    ].sort()
  );
  assert.match(result.suggestedPatch, /OPS-HARNESS-04-WBS-AUTOMATION-FOLLOWUP/);
  assert.doesNotMatch(result.suggestedPatch, /OPS-HARNESS-04-ROLLOUT-FOLLOWUP status -> completed/);
  assert.equal(fs.readFileSync(path.join(repoRoot, ".agents", "artifacts", "PROJECT_PROGRESS.md"), "utf8"), before);
});

test("progress-sync write mode applies deterministic fixes and is idempotent", () => {
  const { repoRoot, dbPath } = setupProgressRepo();

  const first = runProgressSyncCommand({ repoRoot, dbPath, args: ["--write"] });
  const second = runProgressSyncCommand({ repoRoot, dbPath, args: ["--write"] });
  const progress = fs.readFileSync(path.join(repoRoot, ".agents", "artifacts", "PROJECT_PROGRESS.md"), "utf8");

  assert.equal(first.ok, false);
  assert.equal(first.write, true);
  assert.equal(first.written, true);
  assert.equal(second.ok, false);
  assert.equal(second.written, false);
  assert.match(progress, /\| Active packet \| `OPS-HARNESS-04-WBS-AUTOMATION-FOLLOWUP` \|/);
  assert.match(progress, /\| Harness \| OPS-HARNESS-04-TRACE-GENERATOR-FOLLOWUP \| Trace generator follow-up \| completed \|/);
  assert.match(progress, /\| Harness \| OPS-HARNESS-04-ROLLOUT-FOLLOWUP \| Rollout follow-up \| deferred \|/);
  assert.match(progress, /\| `OPS-HARNESS-04-TRACE-GENERATOR-FOLLOWUP` \| trace matrix automation \| completed \|/);
  assert.match(progress, /\| `OPS-HARNESS-04-WBS-AUTOMATION-FOLLOWUP` \| WBS automation \| in_progress \|/);
  assert.match(progress, /\| `OPS-HARNESS-04-ROLLOUT-FOLLOWUP` \| rollout automation \| deferred \|/);
  assert.match(progress, /\| Product Planning \| PKT-APP-01C \| Catalog, permission, admin core \| paused \|/);
  assert.match(progress, /\| Design \/ Auth \| PKT-APP-01B \| Login\/user\/group\/common platform \| remediation-needed \|/);
});

test("progress-sync write mode distinguishes fixed, partial, and no-op outcomes", () => {
  const fixed = setupProgressRepo();
  for (const phase of ["03_implementation", "04_testing", "05_review"]) {
    fs.mkdirSync(
      path.join(fixed.repoRoot, "reference", "packets", "OPS-HARNESS-04-ROLLOUT-FOLLOWUP", phase),
      { recursive: true }
    );
  }
  fs.writeFileSync(
    path.join(fixed.repoRoot, ".agents", "runtime", "ACTIVE_CONTEXT.json"),
    JSON.stringify({ activeTask: { workItemId: "OPS-HARNESS-04-WBS-AUTOMATION-FOLLOWUP" } }, null, 2),
    "utf8"
  );

  const fixedResult = runProgressSyncCommand({ repoRoot: fixed.repoRoot, dbPath: fixed.dbPath, args: ["--write"] });
  const noOpResult = runProgressSyncCommand({ repoRoot: fixed.repoRoot, dbPath: fixed.dbPath, args: ["--write"] });

  assert.equal(fixedResult.ok, true);
  assert.equal(fixedResult.status, "write-fixed");
  assert.equal(fixedResult.written, true);
  assert.equal(noOpResult.ok, true);
  assert.equal(noOpResult.status, "write-noop");
  assert.equal(noOpResult.written, false);

  const partial = setupProgressRepo();
  const partialResult = runProgressSyncCommand({ repoRoot: partial.repoRoot, dbPath: partial.dbPath, args: ["--write"] });
  assert.equal(partialResult.ok, false);
  assert.equal(partialResult.status, "write-applied-with-remaining-diagnostics");
  assert.equal(partialResult.written, true);
  assert(partialResult.diagnostics.some((diagnostic) => diagnostic.code === "active-context-stale"));
  assert.match(partialResult.resultSummary, /applied deterministic changes/i);
});
