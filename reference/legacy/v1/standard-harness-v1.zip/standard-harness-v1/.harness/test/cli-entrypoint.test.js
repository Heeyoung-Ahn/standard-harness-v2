import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

import { normalizeKnownNodeRuntimeWarnings } from "./cli-stderr-helpers.js";

const repoRoot = process.cwd();
const stateRuntime = path.join(repoRoot, ".harness", "runtime", "state");
const stableEntrypoint = path.join(stateRuntime, "harness-cli.js");
const legacyEntrypoint = path.join(stateRuntime, "dev05-cli.js");
const formatterModule = path.join(stateRuntime, "cli-result-formatters.js");

function runNodeCli(entrypoint, args = []) {
  return spawnSync(process.execPath, [entrypoint, ...args], {
    cwd: repoRoot,
    env: {
      ...process.env,
      REPO_ROOT: repoRoot
    },
    encoding: "utf8"
  });
}

test("stable CLI entrypoint and legacy wrapper expose identical command behavior", async () => {
  const { createCommandTable } = await import("../runtime/state/cli-dispatch-table.js");
  const { COMMAND_NAMES, renderUsage } = await import("../runtime/state/cli-help.js");

  const commandTable = createCommandTable({
    repoRoot,
    outputDir: repoRoot,
    dbPath: ".harness/operating_state.sqlite",
    args: []
  });
  assert.equal(typeof commandTable.v24, "function");
  assert.equal(typeof commandTable.risk, "function");
  assert.equal(COMMAND_NAMES.includes("v24"), true);
  assert.equal(COMMAND_NAMES.includes("risk"), true);
  assert.match(renderUsage({ entrypointPath: ".harness/runtime/state/harness-cli.js" }), /harness-cli\.js/);

  const stable = runNodeCli(stableEntrypoint, ["v24"]);
  const legacy = runNodeCli(legacyEntrypoint, ["v24"]);

  assert.equal(stable.status, 0);
  assert.equal(legacy.status, 0);
  assert.equal(legacy.stdout, stable.stdout);
  assert.equal(normalizeKnownNodeRuntimeWarnings(legacy.stderr), normalizeKnownNodeRuntimeWarnings(stable.stderr));
});

test("dev05 CLI is a thin compatibility wrapper and package scripts use the stable entrypoint", () => {
  const wrapperSource = fs.readFileSync(legacyEntrypoint, "utf8");
  assert.match(wrapperSource, /harness-cli\.js/);
  assert.equal(wrapperSource.includes("const commands ="), false);
  assert.equal(wrapperSource.split(/\r?\n/).filter((line) => line.trim()).length <= 8, true);

  const packageJson = JSON.parse(fs.readFileSync(path.join(repoRoot, "package.json"), "utf8"));
  const legacyScriptEntries = Object.entries(packageJson.scripts)
    .filter(([scriptName]) => scriptName.startsWith("harness:") || scriptName.startsWith("browser:evidence"))
    .filter(([, command]) => command.includes(".harness/runtime/state/dev05-cli.js"));

  assert.deepEqual(legacyScriptEntries, []);
  assert.equal(packageJson.scripts["harness:validate"], "node .harness/runtime/state/harness-cli.js validate");
  assert.equal(packageJson.scripts["harness:risk"], "node .harness/runtime/state/harness-cli.js risk");
  assert.equal(packageJson.scripts["harness:v28"], "node .harness/runtime/state/harness-cli.js v28");
});

test("selected closeout commands keep bulky JSON payloads out of normal stdout", async () => {
  const { formatResult } = await import("../runtime/state/harness-cli.js");

  const promotion = formatResult({
    command: "promote-starter",
    ok: true,
    dryRun: true,
    summary: { include: 1, exclude: 2, review: 3 },
    targetRoot: "C:/tmp/starter",
    reportPath: "reference/packets/OPS-07/08_evidence/operating-rollout.md",
    authority: { grantsPacketCloseout: false },
    plan: { items: [{ path: "large-plan-entry", decision: "include" }] },
    nextAction: "Review report."
  });
  assert.match(promotion, /Harness Promote Starter/);
  assert.match(promotion, /Report: reference\/packets\/OPS-07\/08_evidence\/operating-rollout\.md/);
  assert.doesNotMatch(promotion, /large-plan-entry/);
  assert.doesNotMatch(promotion, /"plan"/);

  const docs = formatResult({
    command: "docs-commands",
    ok: true,
    subcommand: "audit",
    docCount: 47,
    commandCount: 311,
    diagnostics: [],
    outputPath: "verification/v2.8/docs_command_inventory.json",
    commands: [{ docPath: "README.md", command: "npm run harness:validate" }],
    nextAction: "Documentation command inventory passed."
  });
  assert.match(docs, /Harness Docs Command Inventory/);
  assert.match(docs, /Output: verification\/v2\.8\/docs_command_inventory\.json/);
  assert.doesNotMatch(docs, /README\.md/);
  assert.doesNotMatch(docs, /"commands"/);
});

test("CLI result formatting lives in a dedicated formatter module behind the stable entrypoint", async () => {
  assert.equal(fs.existsSync(formatterModule), true);

  const cliSource = fs.readFileSync(stableEntrypoint, "utf8");
  assert.match(cliSource, /cli-result-formatters\.js/);
  assert.doesNotMatch(cliSource, /function\s+formatHumanSummary\s*\(/);
  assert.doesNotMatch(cliSource, /function\s+shouldSuppressJsonPayload\s*\(/);
  assert.match(cliSource, /export\s+\{\s*formatResult\s*\}/);

  const { formatResult: entrypointFormatResult } = await import("../runtime/state/harness-cli.js");
  const { formatResult: moduleFormatResult } = await import("../runtime/state/cli-result-formatters.js");
  assert.equal(entrypointFormatResult, moduleFormatResult);
});
