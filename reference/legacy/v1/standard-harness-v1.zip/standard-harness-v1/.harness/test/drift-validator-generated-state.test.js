import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

import { createOperatingStateStore } from "../runtime/state/operating-state-store.js";
import {
  COMPATIBILITY_CURRENT_STATE_PATH,
  CURRENT_STATE_DOC,
  TASK_LIST_DOC,
  calculateChecksum,
  writeGeneratedStateDocs
} from "../runtime/state/generate-state-docs.js";
import { writeActiveContext } from "../runtime/state/active-context.js";
import { validateGeneratedStateDocs } from "../runtime/state/drift-validator.js";
import { seedProfileAwareValidatorFixtures } from "./profile-aware-validator-fixtures.js";

test("exposes generated-state helper module boundary", async () => {
  const helper = await import("../runtime/state/validation/generated-state-checks.js");

  assert.equal(typeof helper.validateGeneratedMarkdownProjectionChecks, "function");
  assert.equal(typeof helper.validateGeneratedProjectionFreshness, "function");
});

test("characterizes generated projection checksum and freshness findings exactly", () => {
  const repoRoot = fs.mkdtempSync(path.join(os.tmpdir(), "drift-validator-generated-state-"));
  seedRepoFiles(repoRoot);

  const store = createOperatingStateStore({
    dbPath: path.join(repoRoot, ".harness", "operating_state.sqlite"),
    now: createClock("2026-04-17T15:00:00.000Z")
  });

  seedOperationalRows(store);
  writeGeneratedStateDocs({ store, outputDir: repoRoot });
  writeActiveContext({ store, repoRoot, outputDir: repoRoot });

  const currentStatePath = generatedDocPath(repoRoot, CURRENT_STATE_DOC);
  const taskListPath = generatedDocPath(repoRoot, TASK_LIST_DOC);
  const originalCurrentState = fs.readFileSync(currentStatePath, "utf8");
  const originalTaskList = fs.readFileSync(taskListPath, "utf8");

  store.refreshProjection({
    projectionName: CURRENT_STATE_DOC,
    checksum: calculateChecksum(originalCurrentState),
    generatedAt: "2026-04-17T14:00:00.000Z",
    sourceRevision: "2026-04-17T14:00:00.000Z"
  });
  store.refreshProjection({
    projectionName: TASK_LIST_DOC,
    checksum: calculateChecksum(originalTaskList),
    generatedAt: "2026-04-17T14:00:00.000Z",
    sourceRevision: "2026-04-17T14:00:00.000Z"
  });

  fs.appendFileSync(currentStatePath, "\nTampered after projection refresh.\n", "utf8");

  const result = validateGeneratedStateDocs({ store, outputDir: repoRoot, repoRoot });

  assert.deepEqual(Object.keys(result).sort(), [
    "cutoverReady",
    "findings",
    "ok",
    "riskClassifications",
    "structuralReady"
  ]);
  assert.equal(result.ok, false);
  assert.equal(result.structuralReady, false);
  assert.equal(result.cutoverReady, false);
  assert.deepEqual(
    result.findings
      .filter((finding) => finding.projectionName === CURRENT_STATE_DOC)
      .filter((finding) =>
        ["checksum_mismatch", "stale_generated_view", "freshness_drift_detected"].includes(finding.code)
      ),
    [
      {
        code: "checksum_mismatch",
        severity: "error",
        projectionName: CURRENT_STATE_DOC,
        message: `${CURRENT_STATE_DOC} checksum does not match generation_state.`
      },
      {
        code: "stale_generated_view",
        severity: "error",
        projectionName: CURRENT_STATE_DOC,
        message: `${CURRENT_STATE_DOC} content no longer matches the last generated projection state.`
      },
      {
        code: "stale_generated_view",
        severity: "error",
        projectionName: CURRENT_STATE_DOC,
        message: `${CURRENT_STATE_DOC} is stale relative to the latest DB mutation timestamp.`
      },
      {
        code: "freshness_drift_detected",
        severity: "error",
        projectionName: CURRENT_STATE_DOC,
        message: `${CURRENT_STATE_DOC} is stale relative to the latest DB mutation timestamp.`
      }
    ]
  );
  assert.deepEqual(
    result.findings
      .filter((finding) => finding.projectionName === TASK_LIST_DOC)
      .filter((finding) => ["stale_generated_view", "freshness_drift_detected"].includes(finding.code)),
    [
      {
        code: "stale_generated_view",
        severity: "error",
        projectionName: TASK_LIST_DOC,
        message: `${TASK_LIST_DOC} is stale relative to the latest DB mutation timestamp.`
      },
      {
        code: "freshness_drift_detected",
        severity: "error",
        projectionName: TASK_LIST_DOC,
        message: `${TASK_LIST_DOC} is stale relative to the latest DB mutation timestamp.`
      }
    ]
  );

  store.close();
});

test("characterizes missing generated projection state row exactly", () => {
  const repoRoot = fs.mkdtempSync(path.join(os.tmpdir(), "drift-validator-missing-generation-state-"));
  seedRepoFiles(repoRoot);

  const store = createOperatingStateStore({
    dbPath: path.join(repoRoot, ".harness", "operating_state.sqlite"),
    now: createClock("2026-04-17T16:00:00.000Z")
  });

  seedOperationalRows(store);
  writeGeneratedStateDocs({ store, outputDir: repoRoot });
  writeActiveContext({ store, repoRoot, outputDir: repoRoot });
  store.db.prepare("DELETE FROM generation_state WHERE projection_name = ?").run(TASK_LIST_DOC);

  const result = validateGeneratedStateDocs({ store, outputDir: repoRoot, repoRoot });

  assert.deepEqual(
    result.findings.find(
      (finding) => finding.code === "generation_failed" && finding.projectionName === TASK_LIST_DOC
    ),
    {
      code: "generation_failed",
      severity: "error",
      projectionName: TASK_LIST_DOC,
      message: `${TASK_LIST_DOC} has no generation_state row.`
    }
  );

  store.close();
});

test("characterizes generated document decision parity findings exactly", () => {
  const repoRoot = fs.mkdtempSync(path.join(os.tmpdir(), "drift-validator-generated-parity-"));
  seedRepoFiles(repoRoot);

  const store = createOperatingStateStore({
    dbPath: path.join(repoRoot, ".harness", "operating_state.sqlite"),
    now: createClock("2026-04-17T17:00:00.000Z")
  });

  seedOperationalRows(store);
  writeGeneratedStateDocs({ store, outputDir: repoRoot });
  writeActiveContext({ store, repoRoot, outputDir: repoRoot });

  const currentStatePath = generatedDocPath(repoRoot, CURRENT_STATE_DOC);
  const originalCurrentState = fs.readFileSync(currentStatePath, "utf8");
  const tamperedCurrentState = originalCurrentState.replace(
    /- \d+ open decisions? requires? attention\./,
    "- 0 open decisions require attention."
  );
  fs.writeFileSync(currentStatePath, tamperedCurrentState, "utf8");
  store.refreshProjection({
    projectionName: CURRENT_STATE_DOC,
    checksum: calculateChecksum(tamperedCurrentState),
    generatedAt: "2026-04-17T17:30:00.000Z",
    sourceRevision: "2026-04-17T17:30:00.000Z"
  });

  const result = validateGeneratedStateDocs({ store, outputDir: repoRoot, repoRoot });

  assert.deepEqual(
    result.findings
      .filter((finding) => finding.projectionName === CURRENT_STATE_DOC)
      .filter((finding) =>
        ["generated_docs_parity_mismatch", "count_detail_parity_mismatch"].includes(finding.code)
      ),
    [
      {
        code: "generated_docs_parity_mismatch",
        severity: "error",
        projectionName: CURRENT_STATE_DOC,
        message: "Decision summary count 0 does not match DB count 1."
      },
      {
        code: "count_detail_parity_mismatch",
        severity: "error",
        projectionName: CURRENT_STATE_DOC,
        message: "Decision summary count 0 does not match detail row count 1."
      }
    ]
  );

  store.close();
});

test("characterizes missing compatibility fallback generation row exactly", () => {
  const repoRoot = fs.mkdtempSync(path.join(os.tmpdir(), "drift-validator-compat-generation-state-"));
  seedRepoFiles(repoRoot);

  const store = createOperatingStateStore({
    dbPath: path.join(repoRoot, ".harness", "operating_state.sqlite"),
    now: createClock("2026-04-17T18:00:00.000Z")
  });

  seedOperationalRows(store);
  writeGeneratedStateDocs({ store, outputDir: repoRoot });
  writeActiveContext({ store, repoRoot, outputDir: repoRoot });
  store.db.prepare("DELETE FROM generation_state WHERE projection_name = ?").run(COMPATIBILITY_CURRENT_STATE_PATH);

  const result = validateGeneratedStateDocs({ store, outputDir: repoRoot, repoRoot });

  assert.deepEqual(
    result.findings.find(
      (finding) => finding.code === "generation_failed" && finding.projectionName === COMPATIBILITY_CURRENT_STATE_PATH
    ),
    {
      code: "generation_failed",
      severity: "error",
      projectionName: COMPATIBILITY_CURRENT_STATE_PATH,
      message: `${COMPATIBILITY_CURRENT_STATE_PATH} has no generation_state row.`
    }
  );

  store.close();
});

function seedOperationalRows(store) {
  store.setReleaseState({
    currentStage: "implementation",
    releaseGateState: "open",
    currentFocus: "Generated state validator extraction",
    releaseGoal: "Preserve generated projection diagnostics",
    sourceRef: ".agents/artifacts/REQUIREMENTS.md"
  });
  store.recordDecision({
    decisionId: "DEC-GEN-01",
    title: "Preserve generated projection diagnostics",
    decisionNeeded: true,
    impactSummary: "Characterization fixture",
    sourceRef: ".agents/artifacts/ARCHITECTURE_GUIDE.md"
  });
  store.recordGateRisk({
    riskId: "RISK-GEN-01",
    title: "Generated projection drift",
    severity: "medium",
    sourceRef: ".agents/artifacts/IMPLEMENTATION_PLAN.md"
  });
}

function seedRepoFiles(repoRoot) {
  fs.mkdirSync(path.join(repoRoot, ".agents", "artifacts"), { recursive: true });
  for (const fileName of ["REQUIREMENTS.md", "ARCHITECTURE_GUIDE.md", "IMPLEMENTATION_PLAN.md"]) {
    fs.writeFileSync(path.join(repoRoot, ".agents", "artifacts", fileName), `# ${fileName}\n`, "utf8");
  }
  seedProfileAwareValidatorFixtures(repoRoot);
}

function generatedDocPath(repoRoot, docName) {
  return path.join(repoRoot, ".agents", "runtime", "generated-state-docs", docName);
}

function createClock(startIso) {
  let offset = 0;
  const base = Date.parse(startIso);
  return () => new Date(base + offset++ * 1000).toISOString();
}
