---
name: frontend-design
description: Use for UI, dashboard, approval screen, workflow form, visual hierarchy, interaction, accessibility, browser-verifiable frontend behavior changes, or large multi-screen design work that should be shaped through a user interview loop. Requires design-system detection, common-shell/component-first planning, pre-build UI plan, and visual/browser evidence when available.
---

<!--
GENERATED FILE. DO NOT EDIT DIRECTLY.
Source: reference/skills-src/frontend_design/SKILL.md.tmpl
Regenerate: npm run harness:skills-generate
Check: npm run harness:skills-check
-->
# Frontend Design

## Use When
Use for BI dashboards, reporting screens, approval forms, workflow screens, budget/asset management UI, navigation, layout, components, visual hierarchy, empty/loading/error states, interaction behavior, screenshots, browser checks, accessibility review, or a broad UI surface with many screens that needs common-screen discovery before detailed mockups.

## Do Not Use When
Backend-only changes, internal scripts, pure data migrations, or docs-only changes have no UI impact.

## Authority Boundary
This skill guides UI planning and verification. It must not override existing design systems, approved product requirements, active packet scope, or domain profile artifacts. Ambiguous UX/product decisions route to Planner or user.

## Required Inputs
Active packet, approved business-process or workflow artifact, approved wireframe-design report when one exists, approved mockup/design artifact when one exists, existing design system/component patterns, relevant BI or approval profile, route/component files, and browser/test environment details if available.

## Workflow
1. Detect design context: CSS variables, design tokens, Tailwind/theme config, component library, typography, layout/grid, chart libraries, accessibility helpers.
2. Classify mode: existing_system, partial_system, greenfield, or ambiguous.
3. Map the intended business process before UI planning: actor, trigger, decision, state transition, permission boundary, audit-visible action, failure/empty state, and handoff to the next screen.
4. For large multi-screen UI, run the common-screen interview loop before making detailed screens.
5. Compare approved wireframes, mockups, and design artifacts to the intended implementation. Record what must be preserved, what is intentionally changed, and what needs Planner/user approval before code.
6. Ask the user in Codex chat and wait when business process, mockup interpretation, common shell, reusable component behavior, or design-system context is ambiguous.
7. Write a pre-build UI plan: visual thesis, content plan, interaction plan, accessibility plan, business-process assumptions, common-shell/component plan, and data/metric or approval-state assumptions.
8. Apply domain checks. BI work must match metric catalog, filters, drill-downs, loading/error states, governance, and certification status. Approval/admin work must match state machine, role visibility, permission matrix, approval rule matrix, runtime setting authority, and audit-visible actions.
9. Verify visually when possible: route, viewport, screenshot path, console errors, interaction steps, result. If unavailable, record `not_run` and blocker.

## Common-Screen Interview Loop
Use this loop when the surface has many screens, repeated admin/detail flows, a platform shell, or several related workflow states.

1. Inventory screen families before drawing all screens:
   - shell/navigation/top bar;
   - main list/grid/table;
   - right inspector/detail panel;
   - create/edit forms;
   - confirmation and support modals;
   - empty/no-result/denied/error/loading states;
   - settings/workflow-specific variants.
2. Identify reusable primitives and propose one standard for each repeated family before producing derived screens.
3. Ask the user short interview questions in small batches. Prefer 1-3 questions at a time and focus on decisions that change common structure, not cosmetic preferences.
4. Build and review one common baseline first, such as app shell + list/grid + inspector + modal. Do not mass-produce derived screens until the common baseline is acceptable or the user explicitly asks to proceed.
5. Apply the accepted baseline to derived screens. Record which screens reuse the baseline unchanged and which screens intentionally deviate.
6. When user feedback changes a common component, update the common baseline first, then propagate the change to derived screens and design notes.
7. For each loop, record the decision, affected component family, derived screens, and remaining open questions in the frontend-design report.

Interview prompts should be concrete and operational. Examples:

- "Should create/edit happen in a modal, a right inspector, or a dedicated page for this workflow?"
- "When no row is selected, should the inspector be blank, show guidance, or show aggregate context?"
- "Which controls must stay visible while the grid scrolls?"
- "Which states need full mockup screens rather than acceptance-only text?"
- "Which copy is user-facing and which belongs only in developer notes?"

## Design Judgment Checks
Use external design-judgment references, such as StyleSeed, as inspiration only. Do not install, vendor, copy components, or change dependencies unless the packet explicitly approves that dependency path and dependency-audit evidence exists.

Before producing a mockup or implementation plan:
- State one visual thesis for the screen. The thesis should describe the operating feel, not only colors.
- Use one primary accent with a mostly neutral base unless an existing design system requires otherwise.
- Keep radius, shadow, border, and spacing scales coherent; visible heavy shadows or mixed corner systems need a packet-level reason.
- Build information hierarchy deliberately: summary first, governed details second, audit/evidence last unless the workflow says otherwise.
- Avoid repeating the same section type or card rhythm without variation; alternate grid, table, inspector, and evidence areas when it improves scanability.
- For admin and BI workbenches, prioritize dense but readable comparison, repeated operation, state visibility, and clear permission boundaries over decorative composition.
- Check real states, not only the happy path: default, hover/focus, disabled, loading, empty, error, denied, stale, and success where relevant.
- Never rely on color alone for state or permission meaning.
- Make the design review explain what changed in structure, density, and state handling, not only that it looks better.

## Evidence To Produce
- `reference/packets/<packet-id>/02_design/frontend-design-report.md`
- Business-process conformance matrix: actor, task, state, permission, audit, empty/error state, and evidence.
- Mockup-to-implementation mapping when an approved mockup or UI design artifact exists.
- Wireframe-to-mockup mapping when a wireframe-design report exists.
- Common-screen decision log for large multi-screen UI: common shell/components, user decisions, derived screens, intentional deviations, and unresolved questions.
- Screenshot/browser evidence paths when available.

## Output Format
| Route | Viewport | Screenshot | Console | Interaction | Result |
|---|---|---|---|---|---|

Include design context, business-process conformance, wireframe/mockup/design mapping, pre-build plan, domain checks, verdict, next workflow, next first action, and do-not-cross.

## Stop Conditions
Stop and route to Planner/user when business-process flow is not approved, required wireframe structure is missing or conflicts with the intended mockup, the common baseline has not been accepted for a large multi-screen surface, mockup interpretation conflicts with the intended implementation, design signals conflict, UX behavior changes product scope, BI metric or approval artifact is missing, accessibility requirements cannot be met in scope, or browser evidence is required for release but cannot be produced.
