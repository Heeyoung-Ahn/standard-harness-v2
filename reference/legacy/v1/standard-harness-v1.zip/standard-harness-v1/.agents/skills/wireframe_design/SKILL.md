---
name: wireframe-design
description: Use when Planner is shaping a UI packet before mockup work and must settle screen scope, low-fidelity layout, user flows, state/permission/interaction structure, or decide which screens need Designer mockups versus acceptance text.
---

<!--
GENERATED FILE. DO NOT EDIT DIRECTLY.
Source: reference/skills-src/wireframe_design/SKILL.md.tmpl
Regenerate: npm run harness:skills-generate
Check: npm run harness:skills-check
-->
# Wireframe Design

## Use When
Use during packet planning before Designer mockups when a UI, dashboard, admin console, report viewer, permission matrix, preview, filter, drawer, modal, or multi-screen workflow needs low-fidelity structure first.

Use especially when the screen count is unclear, common list/detail/edit patterns must be settled, or the packet must decide which views need mockups and which can be specified with acceptance text.

## Do Not Use When
Use `frontend_design` instead when visual hierarchy, component styling, mockups, screenshots, accessibility evidence, or browser-verifiable design behavior is the active task. Do not use for backend-only work, data-only changes, or already-approved UI structure with no new screen-flow uncertainty.

## Authority Boundary
This skill supports Planner-owned scope, UX structure, acceptance, and handoff decisions. It does not approve product scope, Ready For Code, mockup acceptance, implementation, visual design, or user-facing behavior changes. Designer may treat approved wireframe output as input, but unresolved product or workflow decisions route back to Planner/user.

## Required Inputs
Active packet or planning target, approved requirements, relevant architecture or UI artifacts, business-process or permission artifacts, known roles and tasks, and any prior mockup or Designer evidence that constrains the structure.

## Workflow
1. Name the planning target: packet id, owner, required SSOT, approval boundary, and do-not-cross.
2. Keep fidelity deliberately low: use boxes, labels, simple tables, ASCII/Markdown layouts, or minimal static HTML only when it clarifies structure. Avoid colors, final typography, decorative visual style, and component polish.
3. Inventory screen families before drawing details: shell/navigation, list/grid/table, detail/inspector, create/edit, matrix, preview, confirmation modal, empty/no-result/denied/error/loading/stale states, and settings variants.
4. Map user task flows: actor, trigger, entry screen, primary action, selection/filter/drill behavior, state transition, permission boundary, audit-visible action, and handoff to the next screen.
5. Draft low-fidelity layouts for the screens that change scope or comprehension. Keep labels operational, such as `filters`, `results table`, `permission matrix`, `right inspector`, `preview`, or `bulk action`.
6. Record state coverage for each important screen: default, empty, loading, error, denied, no-data, stale, success, and validation failure when applicable.
7. Record interaction notes: click, select, search, filter, sort, drill, reset, save, cancel, bulk action, permission preview, and destructive confirmation.
8. Split output into `Mockup required` and `Acceptance text enough`. Require mockups for screens where structure, workflow comprehension, permission visibility, or operator confidence depends on seeing the layout.
9. Capture unresolved decisions with owner, realistic options, recommendation, and why the decision blocks Planner or Designer.
10. Hand off to Designer only when the wireframe report identifies source scope, approved structure, mockup targets, unresolved decisions, and non-scope.

## Evidence To Produce
- `reference/packets/<packet-id>/90_interim/wireframe-design-report.md`
- Optional review artifact when useful: `reference/packets/<packet-id>/90_interim/wireframe.md` or `reference/packets/<packet-id>/90_interim/wireframe.html`

## Output Format
Include:
- active packet or planning target;
- required SSOT and approval boundary;
- screen inventory;
- user task flow table;
- low-fidelity layout notes or artifact path;
- state and interaction matrix;
- `Mockup required` versus `Acceptance text enough`;
- unresolved decisions;
- Designer handoff notes;
- next workflow, next first action, and do-not-cross.

## Stop Conditions
Stop and route to Planner/user when requirements, business process, permission authority, audit-visible behavior, or screen ownership is unclear; when wireframing would redefine product scope; when the user is asking for visual mockups or implementation; when a required source artifact is missing; or when the wireframe cannot distinguish structure decisions from visual design decisions.
