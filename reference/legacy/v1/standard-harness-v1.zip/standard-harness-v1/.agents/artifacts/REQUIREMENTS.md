# Requirements

## Summary
Starter placeholder. Replace during `harness:init`. Keep requirements tied to explicit user goals, approval boundary, open questions, and deferred items.

### 사용자 목표
- pending

### 운영 목표
- pending

### 승인 목표
- pending

## Active Profile Selection
- none yet

## Open Questions
- pending kickoff interview

## Deferred Items
- none yet

## Starter Health Customization Boundary

Preserve this section when customizing starter docs.

- Safe to customize: product-only goals, acceptance criteria, domain terms, and packet-specific facts.
- Preserve reusable starter-health guidance so a copied starter still explains approval boundaries, open questions, deferred items, and packet decision records.
