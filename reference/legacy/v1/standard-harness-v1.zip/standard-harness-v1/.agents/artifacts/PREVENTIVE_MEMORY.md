# Preventive Memory

No project-specific preventive memory has been recorded yet.

## Long-Memory Boundary
- Record project-specific repeated mistakes only after they are observed.
- Do not copy root maintainer history or root maintainer maintenance notes into product preventive memory.
