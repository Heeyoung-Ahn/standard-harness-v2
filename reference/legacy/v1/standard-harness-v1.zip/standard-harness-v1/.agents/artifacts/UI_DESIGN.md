# UI Design

## Purpose
Starter placeholder. Replace after requirements and rough UX direction are approved.

## Scope
- No product UI is approved yet.
- Record navigation, screen structure, interaction states, accessibility, and visual/content contract when a packet requires UI evidence.
