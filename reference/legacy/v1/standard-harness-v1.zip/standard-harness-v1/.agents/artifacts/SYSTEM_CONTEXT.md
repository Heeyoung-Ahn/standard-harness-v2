# System Context

This artifact is conditional canonical for long-term system boundary only when it is explicitly maintained and cited.

Do not use it as current execution truth.

## Reusable Harness Boundary Notes

### Planner Packet Challenge Review
- Planner Packet Challenge Review evidence must identify independent review, source refs, findings disposition, and whether any finding was self-approved or resolved by self-approval.
- Reviewer may hold closeout when findings disposition is missing or challenge evidence is self-approved.

### Production-Forbidden Prototype Lane
- Prototype outputs are learning surfaces, not production implementation sources.
- Production implementation must be re-approved under Modeling Impact and product packet scope before code is merged or reused.
- Reviewer closeout may hold when a packet permits direct copy/merge into production.

### Shared Skill Marketplace Contract
- `reference/artifacts/SKILL_MARKETPLACE_CATALOG.md` is the compact discovery surface for reusable skills.
- Default context, default role briefs, and Planner read sets must not load all skill bodies.
- Load the selected skill body or selected active skills only when an active task, workflow, role, or user request triggers them.
- Skill output does not override packet authority, Ready For Code approval, Tester verification, Reviewer closeout, Planner closeout, or product acceptance.
- `conflict_resolver` remains minimum-contract-deferred until `OPS-SKILL-01A_CONFLICT_RESOLVER_MINIMUM_CONTRACT` or equivalent approval exists.
