# Project History

## Long-Memory Boundary
- Use this long history log for project-specific decisions after initialization.
- Do not copy root maintainer history into product projects.
- Keep root maintainer notes in the source harness maintenance packet or release history.
