# Architecture Guide

## Purpose
Record durable architecture context after requirements are frozen.

## Authoring Flow
- Replace this starter placeholder after requirements freeze.

## Architecture Memory Boundary
Use this as reusable starter-health guidance for component names, module boundaries, data flow, integrations, and constraints.
Do not use it as root maintainer history or current execution truth.

## Starter Health Customization Boundary

Preserve this section when customizing starter docs.

- Safe to customize: product-only architecture decisions after packet approval.
- Preserve reusable starter-health guidance and separate project architecture from root maintainer history and packet decision records.
