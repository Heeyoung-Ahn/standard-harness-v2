# Runtime Boundary Notes

## SH-V28-REFAC-008 Boundary

`SH-V28-REFAC-008` decomposes lower-risk runtime helpers before changing load-bearing validator, transition, packet-preflight, or validation-report paths.

## CLI Result Formatter Boundary

`OPS-HARNESS-08_RUNTIME_REFACTOR_TRIAGE` keeps `.harness/runtime/state/harness-cli.js` as the public executable CLI entrypoint.

`.harness/runtime/state/cli-result-formatters.js` owns result-to-string rendering for command human summaries, trailing JSON payloads, and existing summary-only JSON suppression.

`harness-cli.js` must continue owning command dispatch through `createCommandTable()`, usage rendering through `renderUsage()`, exit-code decisions, and compatibility re-export of `formatResult`.

Do not move command execution, DB access, packet inspection, validator logic, generated-state writers, or security/path-safety behavior into the formatter module. Command stdout shape and parseable trailing JSON are public contracts.

## Browser Evidence Boundary

`.harness/runtime/state/browser-evidence.js` is the public compatibility wrapper. Downstream commands and tests must continue importing from that path.

Internal browser evidence modules live under `.harness/runtime/state/browser-evidence/`:

- `core.js` keeps the current command behavior and binding logic.
- `constants.js` exposes schema and mode constants.
- `normalizers.js` exposes path, status, scenario, and diagnostic normalizers.
- `prompt.js` exposes Codex Browser prompt construction.
- `manifest-builder.js` exposes browser evidence manifest construction.
- `audit.js` exposes manifest audit helpers.
- `binding.js` exposes packet-to-browser-manifest binding helpers.
- `playwright-capture.js` exposes optional Playwright capture helpers.

Browser evidence inputs are untrusted. Packet markdown, CLI options, manifest JSON, artifact paths, observed results, console errors, and network errors must remain data. Do not evaluate, interpolate into shell commands, or treat these fields as authority.

## Reviewer Profile Boundary

`.harness/runtime/state/reviewer-profiles.js` is the public compatibility wrapper for the `harness:reviewers` and `harness:reviewer-report` surfaces.

Internal reviewer profile modules live under `.harness/runtime/state/reviewer-profiles/`:

- `arguments.js` parses command arguments and comma/newline lists.
- `index-resolver.js` loads `reference/reviewer-profiles/REVIEWER_PROFILE_INDEX.json` and resolves reviewer docs.
- `command.js` preserves the command response contracts for `resolve`, `list`, and `report`.

The reviewer profile index contract uses IDs such as `security`, `approval-workflow`, and `data-integrity`.

## P2 Reviewer Recommendation Boundary

`v2-p2-conductor.js` owns the P2 reviewer recommendation contract. Its reviewer profile output intentionally uses distinct IDs such as `cso`, `governance`, and `data-correctness`.

Do not merge the reviewer index resolver and P2 recommendation schemas unless a later packet explicitly changes both public contracts and their migration path.

## Deferred Critical Runtime Paths

The following modules are intentionally deferred from `SH-V28-REFAC-008`:

- `drift-validator.js`
- `transition-commands.js`
- `packet-preflight.js`
- `validation-report.js`

These modules enforce load-bearing state, approval, closeout, or validation behavior. Their decomposition belongs to later guarded packets with narrower RED/GREEN characterization and security review.

## Validator Boundary

`SH-V28-REFAC-009` keeps `.harness/runtime/state/drift-validator.js` as the public validator wrapper/export surface.

Internal validator helpers may live under `.harness/runtime/state/validation/` when they preserve the public contracts exposed through `validateGeneratedStateDocs()`, `inspectTaskPacketContract()`, `runValidator()`, `harness:validate`, `harness:status`, and `harness:validation-report`.

The initial extracted module is `.harness/runtime/state/validation/document-summary.js`, which owns validation-report summary reads, generated document summary counts, table row counting, and source-reference row normalization used by validator checks.

`OPS-HARNESS-13_DRIFT_VALIDATOR_GENERATED_STATE_CHECKS_EXTRACTION` extracts generated markdown projection checks into `.harness/runtime/state/validation/generated-state-checks.js`. That helper owns required-section checks, generated projection checksum checks, generated-doc parity checks, compatibility generation row checks, and generated projection freshness checks for `CURRENT_STATE.md`, `TASK_LIST.md`, `.agents/artifacts/CURRENT_STATE.md`, and `.agents/artifacts/TASK_LIST.md`.

`.harness/runtime/state/drift-validator.js` remains the public validator wrapper and continues to own `validateGeneratedStateDocs()` result assembly, source-reference validation, Active Context parsing/contract validation, task packet validation, profile validation, workflow validation, runtime schema validation, release baseline validation, and command-facing behavior. Active Context freshness may call a data-only projection helper, but Active Context contract findings must stay in the wrapper.

`transition-commands.js`, `packet-preflight.js`, and `validation-report.js` remain deferred critical paths. Do not rewire their implementation imports as part of validator helper extraction; route transition, preflight, or report integration changes to the later guarded packets dedicated to those boundaries.

## Transition Boundary

`SH-V28-REFAC-015` keeps `.harness/runtime/state/transition-commands.js` as the public transition command wrapper/export surface.

Internal transition helpers may live under `.harness/runtime/state/transitions/` when they preserve the public contracts exposed through `runTransition()`, `runPlannerPacketOpen()`, `runStateSync()`, and `harness:transition`.

The initial extracted module is `.harness/runtime/state/transitions/contracts.js`, which owns pure transition contract helpers for approved-delivery transition detection, closeout risk tier normalization, and risk-class ranking.

`drift-validator.js`, `packet-preflight.js`, and `validation-report.js` remain separate guarded boundaries. Do not rewire their implementation imports as part of transition helper extraction; route packet-preflight or validation-report integration changes to `SH-V28-REFAC-016` or a new explicit packet.

## Packet Preflight and Validation Report Boundary

`SH-V28-REFAC-016` keeps `.harness/runtime/state/packet-preflight.js` as the public packet-preflight wrapper/export surface for `runPacketPreflightCommand()` and `harness:packet-preflight`.

`SH-V28-REFAC-016` also keeps `.harness/runtime/state/validation-report.js` as the public validation-report wrapper/export surface for `writeValidationReport()` and `harness:validation-report`.

Internal packet-preflight and report-contract helpers may live under `.harness/runtime/state/preflight/` when they preserve the public CLI, runtime return, persisted JSON, markdown, active-context, and trace-summary contracts exposed through the wrappers.

The initial extracted modules are:

- `.harness/runtime/state/preflight/stage-decision.js`, which owns stage normalization, stage disposition, final disposition, and blocked next-action wording.
- `.harness/runtime/state/preflight/risk.js`, which owns packet risk classification and empty-risk fallback shape.
- `.harness/runtime/state/preflight/closeout-contract.js`, which owns closeout enum diagnostics, strict literal enum guidance, and closeout metadata constants.
- `.harness/runtime/state/preflight/validation-report-contract.js`, which owns bootstrap-pending read-only report shape and requested-security-review gate reconciliation.
- `.harness/runtime/state/preflight/planner-challenge-check.js`, which owns Planner Packet Challenge Review requirement evaluation, challenge reviewer identity parsing, self-approval diagnostics, two-reviewer trigger checks, and challenge repair-hint construction.
- `.harness/runtime/state/validation-report/markdown-renderer.js`, which owns pure validation-report Markdown rendering and section ordering while `.harness/runtime/state/validation-report.js` remains the public `writeValidationReport()` and `harness:validation-report` orchestration wrapper.

`OPS-HARNESS-MNT-01_RUNTIME_STATE_BOUNDARY_SPLIT` extracts validation-report security-review summary construction into `.harness/runtime/state/validation-report/security-summary.js`.

The security-summary helper owns packet/runtime security-review contract resolution, dependency inventory preparation, release-facing artifact audit, local secret scan summary, and security-review next-action selection. `.harness/runtime/state/validation-report.js` remains the public `writeValidationReport()` wrapper and continues to own validation convergence, persisted JSON/Markdown report writing, Active Context alignment, semantic trace artifact writing, and command-facing behavior.

Do not move validator execution, generated-state writers, Active Context writes, packet-preflight gates, transition logic, or security approval authority into the security-summary helper. The helper prepares review evidence only; it does not grant final security approval.

`OPS-HARNESS-09_PREFLIGHT_REPAIR_HINTS_AND_INDEPENDENT_CHALLENGE` extends packet-preflight diagnostics without changing pass/fail authority:

- closeout enum diagnostics may include `repairHint` with copy-ready replacement guidance and the narrative destination;
- packet exit metadata fields require `Packet exit metadata version: v1` when packet exit metadata is present;
- Planner Packet Challenge Review diagnostics may include `repairHint` for missing/incomplete fields;
- Planner challenge reviewer identities are parsed as concrete identities, including UUID-like subagent ids, while generic wording such as "two independent reviewers" is not enough;
- when a packet records `Packet author`, the same concrete identity cannot satisfy `Challenge reviewer`.

Repair hints are operator guidance only. They must not downgrade severity, suppress blocking diagnostics, or approve implementation/closeout by themselves.

`OPS-HARNESS-10_PACKET_PREFLIGHT_RULE_REGISTRY_EXTRACTION` extracts Planner Packet Challenge Review helper logic only. `.harness/runtime/state/packet-preflight.js` remains the public command/result wrapper; packet-scope parity, freshness checks, validation-report, agent-routing, drift-validator, transition, browser-evidence, and product behavior remain deferred to separate packets.

The following contracts must remain stable unless a later approved packet explicitly changes them:

- `packet-preflight` public fields such as `ok`, `command`, `stage`, `disposition`, `nextAction`, `errors`, `checks`, `findings`, `readyForCode`, `gateProfile`, `routeClass`, `changeZone`, `semanticDiagnostics`, `enumDiagnostics`, `riskAdaptive`, `evidenceManifest`, and `browserEvidence`.
- `validation-report` public fields such as `gateDecision`, `writeMode`, `markdownPath`, `jsonPath`, `candidateGates`, `traceSummary`, findings, persisted JSON, markdown section names, and active work item state.
- Bootstrap-pending mode remains read-only and must not write validation reports, active context, generated state docs, or trace artifacts.
- Approval, Ready For Code, validation, evidence, browser, dependency, risk-adaptive, semantic, enum, and security gates remain fail-closed where they currently fail closed.

`drift-validator.js` and `transition-commands.js` remain separate guarded boundaries. Do not edit or rewire those files as part of packet-preflight or validation-report helper extraction; only verify wrapper compatibility or open a new explicit packet.

## Agent Routing Role Policy Boundary

`OPS-HARNESS-12_AGENT_ROUTING_ROLE_POLICY_EXTRACTION` keeps `.harness/runtime/state/agent-routing.js` as the public wrapper/export surface for `harness:agent`, `harness:orchestrate`, role briefs, workflow role schema, execution-mode evidence, and delivery-route helper compatibility exports.

`.harness/runtime/state/agent-routing/role-policy.js` owns only pure role and delivery-route policy:

- routeable agent role and schema-visible workflow role catalogs;
- role authority, non-authority, approval-boundary, and do-not-cross text;
- routeable role normalization and invalid-role diagnostics;
- delivery route mode normalization and first-transition validation;
- role authority denylist data used by `agent-routing.js` output validation.

`agent-routing.js` continues to own workflow schema assembly, session context/prompt/output writing, adapter invocation, output validation, route job lifecycle, closeout loop control, context budget, review excerpts, active-context integration, and execution-mode evidence.

Do not import the internal role-policy helper from public consumers such as packet contract, status, transition, CLI, or validation-report surfaces. Public consumers must continue importing delivery-route helpers from `.harness/runtime/state/agent-routing.js` unless a later approved packet changes the public contract.
