# Standard Harness Command Taxonomy

### core starter lifecycle

| Script | Group | Description |
|---|---|---|
| `harness:context` | core starter lifecycle | Run a standard-harness command. |
| `harness:context-brief` | core starter lifecycle | Run a standard-harness command. |
| `harness:context-budget-policy` | core starter lifecycle | Run a standard-harness command. |
| `harness:context-meter` | core starter lifecycle | Run a standard-harness command. |
| `harness:context-prune` | core starter lifecycle | Run a standard-harness command. |
| `harness:init` | core starter lifecycle | Run a standard-harness command. |
| `harness:payload-boundary` | core starter lifecycle | Run a standard-harness command. |
| `harness:promote-starter` | core starter lifecycle | Run a standard-harness command. |
| `harness:status` | core starter lifecycle | Run a standard-harness command. |
| `harness:sync-state` | core starter lifecycle | Run a standard-harness command. |
| `harness:validate` | core starter lifecycle | Run a standard-harness command. |
| `pretest` | core starter lifecycle | Run starter preflight checks before tests. |
| `test` | core starter lifecycle | Run reusable harness tests. |

### Codex workflow

| Script | Group | Description |
|---|---|---|
| `harness:codex-plugin` | Codex workflow | Run a standard-harness command. |
| `harness:codex-ready` | Codex workflow | Run a standard-harness command. |
| `harness:codex-start` | Codex workflow | Run a standard-harness command. |
| `harness:codex-task` | Codex workflow | Run a standard-harness command. |
| `harness:orchestrate` | Codex workflow | Run a standard-harness command. |
| `harness:packet-artifact-closeout` | Codex workflow | Run a standard-harness command. |
| `harness:packet-artifact-init` | Codex workflow | Run a standard-harness command. |
| `harness:packet-artifact-validate` | Codex workflow | Run a standard-harness command. |
| `harness:packet-lean` | Codex workflow | Run a standard-harness command. |
| `harness:packet-open` | Codex workflow | Run a standard-harness command. |
| `harness:packet-preflight` | Codex workflow | Run a standard-harness command. |
| `harness:task-brief` | Codex workflow | Run a standard-harness command. |
| `harness:transition` | Codex workflow | Run a standard-harness command. |

### evidence/review

| Script | Group | Description |
|---|---|---|
| `browser:evidence` | evidence/review | Collect or inspect browser evidence. |
| `browser:evidence:audit` | evidence/review | Collect or inspect browser evidence. |
| `browser:evidence:intake` | evidence/review | Collect or inspect browser evidence. |
| `browser:evidence:prompt` | evidence/review | Collect or inspect browser evidence. |
| `harness:evidence` | evidence/review | Run a standard-harness command. |
| `harness:evidence-manifest` | evidence/review | Run a standard-harness command. |
| `harness:evidence-quality` | evidence/review | Run a standard-harness command. |
| `harness:review-findings` | evidence/review | Run a standard-harness command. |
| `harness:review-queue` | evidence/review | Run a standard-harness command. |
| `harness:review-scope` | evidence/review | Run a standard-harness command. |
| `harness:reviewer-profile` | evidence/review | Run a standard-harness command. |
| `harness:reviewer-report` | evidence/review | Run a standard-harness command. |
| `harness:reviewers` | evidence/review | Run a standard-harness command. |
| `harness:trace-matrix` | evidence/review | Run a standard-harness command. |
| `harness:validation-report` | evidence/review | Run a standard-harness command. |

### security/risk gates

| Script | Group | Description |
|---|---|---|
| `harness:dependency-intake` | security/risk gates | Run a standard-harness command. |
| `harness:risk` | security/risk gates | Run a standard-harness command. |
| `harness:risk-gate` | security/risk gates | Run a standard-harness command. |
| `harness:secret-scan` | security/risk gates | Run a standard-harness command. |
| `harness:untrusted-scan` | security/risk gates | Run a standard-harness command. |

### learning/operator diagnostics

| Script | Group | Description |
|---|---|---|
| `harness:dashboard` | learning/operator diagnostics | Run a standard-harness command. |
| `harness:doctor` | learning/operator diagnostics | Run a standard-harness command. |
| `harness:learning` | learning/operator diagnostics | Run a standard-harness command. |
| `harness:learning-staleness` | learning/operator diagnostics | Run a standard-harness command. |
| `harness:next` | learning/operator diagnostics | Run a standard-harness command. |
| `harness:operator-digest` | learning/operator diagnostics | Run a standard-harness command. |
| `harness:refactor-audit` | learning/operator diagnostics | Run a standard-harness command. |

### compatibility namespaces

| Script | Group | Description |
|---|---|---|
| `harness:v23` | compatibility namespaces | Run a standard-harness command. |
| `harness:v24` | compatibility namespaces | Run a standard-harness command. |
| `harness:v24-policy-audit` | compatibility namespaces | Run a standard-harness command. |
| `harness:v25` | compatibility namespaces | Run a standard-harness command. |
| `harness:v26` | compatibility namespaces | Run a standard-harness command. |
| `harness:v27` | compatibility namespaces | Run a standard-harness command. |
| `harness:v28` | compatibility namespaces | Run a standard-harness command. |

### maintenance/internal

| Script | Group | Description |
|---|---|---|
| `docs:commands:check` | maintenance/internal | Starter package script. |
| `harness:abstain` | maintenance/internal | Run a standard-harness command. |
| `harness:adapter-guard` | maintenance/internal | Run a standard-harness command. |
| `harness:adapter-manifest` | maintenance/internal | Run a standard-harness command. |
| `harness:agent` | maintenance/internal | Run a standard-harness command. |
| `harness:ai-review-package` | maintenance/internal | Run a standard-harness command. |
| `harness:ai-review-runner` | maintenance/internal | Run a standard-harness command. |
| `harness:artifact-migration-audit` | maintenance/internal | Run a standard-harness command. |
| `harness:automation-candidates` | maintenance/internal | Run a standard-harness command. |
| `harness:brief` | maintenance/internal | Run a standard-harness command. |
| `harness:browser-evidence` | maintenance/internal | Run a standard-harness command. |
| `harness:cutover-preflight` | maintenance/internal | Run a standard-harness command. |
| `harness:cutover-report` | maintenance/internal | Run a standard-harness command. |
| `harness:day-start-brief` | maintenance/internal | Run a standard-harness command. |
| `harness:day-wrap-up-brief` | maintenance/internal | Run a standard-harness command. |
| `harness:directional-pilot` | maintenance/internal | Run a standard-harness command. |
| `harness:doc-policy` | maintenance/internal | Run a standard-harness command. |
| `harness:docs-commands` | maintenance/internal | Run a standard-harness command. |
| `harness:explain` | maintenance/internal | Run a standard-harness command. |
| `harness:first-packet` | maintenance/internal | Run a standard-harness command. |
| `harness:freeze` | maintenance/internal | Run a standard-harness command. |
| `harness:friction-report` | maintenance/internal | Run a standard-harness command. |
| `harness:guard` | maintenance/internal | Run a standard-harness command. |
| `harness:handoff` | maintenance/internal | Run a standard-harness command. |
| `harness:lane` | maintenance/internal | Run a standard-harness command. |
| `harness:learn` | maintenance/internal | Run a standard-harness command. |
| `harness:learn-export` | maintenance/internal | Run a standard-harness command. |
| `harness:learn-prune` | maintenance/internal | Run a standard-harness command. |
| `harness:learn-search` | maintenance/internal | Run a standard-harness command. |
| `harness:manual-route` | maintenance/internal | Run a standard-harness command. |
| `harness:migration-apply` | maintenance/internal | Run a standard-harness command. |
| `harness:migration-preview` | maintenance/internal | Run a standard-harness command. |
| `harness:npm-diagnostic` | maintenance/internal | Run a standard-harness command. |
| `harness:openapi-contract` | maintenance/internal | Run a standard-harness command. |
| `harness:p2` | maintenance/internal | Run a standard-harness command. |
| `harness:packaging-readiness` | maintenance/internal | Run a standard-harness command. |
| `harness:plan-quality` | maintenance/internal | Run a standard-harness command. |
| `harness:progress-sync` | maintenance/internal | Run a standard-harness command. |
| `harness:recovery-rehearsal` | maintenance/internal | Run a standard-harness command. |
| `harness:repro-check` | maintenance/internal | Run a standard-harness command. |
| `harness:skills-check` | maintenance/internal | Run a standard-harness command. |
| `harness:skills-generate` | maintenance/internal | Run a standard-harness command. |
