# Closeout Manual

Closeout is the hard gate that decides whether a packet can be marked complete.

## Command

```bash
npm run harness:packet-preflight -- --stage closeout --packet <packet-path> --work-item <work-item-id> --strict-evidence-manifest --strict-browser-evidence
```

## Evidence expectations

| Evidence type | Required when | Closeout rule |
|---|---|---|
| TDD | Behavior-bearing code changes | Must be packet-bound or explicitly exempted |
| Security | Security-sensitive or untrusted-input changes | Must be packet-bound and reviewed |
| Browser | UI or browser-observable changes | Must be Codex Browser or equivalent real-browser evidence in strict mode |
| Packet-scope parity | Any packet that declares packet-scope parity, or any high-risk behavior packet where approved scope must be traced | Must map approved requirements to implementation and verification evidence; unimplemented or unverified approved scope blocks closeout |
| DB-backed runtime | DB-backed or persistent runtime behavior | Must include separate migration/schema evidence and live runtime persistence evidence |
| Dependency | Dependency-sensitive changes | Must include intake and risk decision |
| Release | Release/canary-sensitive changes | Must include release evidence and known risks |

## Minimal CSO security review pass example

Use this as a shape example only. It is not approval for another packet and it does not replace a scoped security review when the active packet requires one.

```json
{
  "artifact_type": "security_review_report",
  "schema_version": "standard-harness-security-review/v2.2",
  "packet_path": "reference/packets/PKT-01.md",
  "work_item_id": "WI-01",
  "mode": "scoped",
  "phases_run": [0, 1, 12, 13, 14],
  "decision": "pass",
  "findings": [],
  "filter_stats": { "raw_candidates": 0, "suppressed_false_positives": 0, "main_findings": 0 }
}
```

Required fields include `schema_version`, one packet binding field such as `packet_path`, `work_item_id` when available, `mode`, `phases_run`, `decision`, `findings`, and `filter_stats`. If findings exist, include redacted evidence and recommendation fields required by `reference/schemas/CSO_SECURITY_REVIEW_SCHEMA.json`.

## Browser evidence rule

Static HTTP/API smoke evidence is not enough for strict UI closeout. Strict browser evidence must include:

- matching `packet_path`
- matching `work_item_id`
- real browser engine such as `codex-browser`
- screenshot or session artifact paths
- scenario-level observed results
- console/network error summary

When screenshot export fails, record the failure honestly. DOM/session evidence can be stored as bounded `dom_session_transcript` fallback evidence, but it satisfies strict closeout only when the active browser policy declares DOM/session evidence sufficient. Under screenshot-required policy, fallback evidence remains `hold`, `blocked_environment`, or `not_run_agent_error` and should not be counted as product pass.

Failed required scenarios are closeout blockers. A browser report with partial success, such as `7 pass / 5 fail`, is useful execution evidence but cannot close a packet whose failed scenarios are approved scope.

## Packet-scope parity rule

When required, Developer creates the initial matrix from the approved packet, Tester verifies each row, and Reviewer owns the final disposition. Allowed row status values are:

- `implemented-and-verified`
- `implemented-not-verified`
- `not-implemented`
- `deferred-by-approved-scope`
- `not-applicable-by-approved-scope`

Closeout must block on `implemented-not-verified` or `not-implemented` unless Planner/user explicitly rebaselined the scope before closeout.

## DB-backed runtime rule

Migration/schema evidence proves the database can be created or evolved. It does not prove the running application uses the database. DB-backed closeout requires both:

- `DB migration/schema status: pass`
- `DB-backed runtime persistence status: pass`

## Dashboard caveat

`npm run harness:codex-ready` and `npm run harness:v28` are dashboards. They are not approval substitutes for closeout.
