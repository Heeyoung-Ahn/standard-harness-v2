# Packet Artifacts

Use packet folders for fresh-start validation reports, friction notes, implementation summaries, and review evidence.

- Keep canonical current state in `.agents/artifacts/*`, generated state in `.agents/runtime/*`, and validation output in `.agents/artifacts/VALIDATION_REPORT.*`.
- Put packet-specific artifacts under `reference/packets/<packet-id>/<phase>/`.
- Do not treat an artifact as product acceptance evidence unless the active packet manifest cites it under Tester or Reviewer evidence.

## E2E Effort / Token Reporting Contract

- `Telemetry status: measured | estimated | unavailable`
- `measured`: use only when the report cites a concrete runtime, tool, log, trace, or accounting source for the value.
- `estimated`: use when the report infers the value; include the estimation method and do not present it as exact telemetry.
- `unavailable`: use when telemetry is absent; include the unavailable rationale and the non-metric evidence used instead.
- `Measured product implementation tokens`: record only measured product-work tokens with an evidence source.
- `Measured harness compliance tokens`: record only measured harness/planning/validation tokens with an evidence source.
- `Estimated product / harness split`: record the estimated split only with an estimation method.
- `Estimation method`: describe the sampling, transcript review, time-box, or other method used for an estimate.
- `Evidence source`: cite the concrete source for measured values or the source material used for estimates.
- `Unavailable rationale`: explain why token/cost telemetry is not available.
- Do not invent exact token/cost metrics when runtime telemetry does not expose them.
- Reviewer holds reports that present exact token/cost numbers without measured evidence.

No reusable fresh-start E2E packet evidence template is currently shipped.

## Sandbox / Pilot Evidence Bundle

- `Production readiness`: use `not-claimed`.
- `Payload separation`: confirm reusable starter payloads did not receive pilot-only files.
- Pilot evidence does not weaken strict/high production gates.
- Harness validation proves harness structure and state consistency; product acceptance still needs product-specific Tester/Reviewer evidence in the active packet.
